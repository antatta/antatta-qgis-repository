# -*- coding: utf-8 -*-
"""
Attachments module for AUTOMATE plugin v2.0
Contains attachment and trash management.
"""
