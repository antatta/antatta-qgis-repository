# -*- coding: utf-8 -*-
"""
/***************************************************************************
 AttachManager
                                 A QGIS plugin
 The AUTOMATE plug-in
                             -------------------
        begin                : 2024-09-23
        copyright            : (C) 2024 by Ing. Antonio Attadia
        email                : info.antatta@gmail.com
        git sha              : $Format:%H$
 ***************************************************************************/
for attachment management
"""
import subprocess
import sys
import re
from pathlib import Path
from PyQt5.QtWidgets import QFileDialog, QMessageBox
from qgis.core import QgsProject, Qgis, QgsVectorLayer, QgsFeature, edit
from qgis.PyQt.QtCore import QVariant

from ...database.database_connect import DatabaseConnect

class AttachManager:
    def __init__(self, iface):
        self.iface = iface  # riferimento all'interfaccia QGIS
                
        # campo univoco feature
        self.UNIVOCO_FEATURE:str = "RG_COD"
        # cartella allegati
        self.attached_dir:str = "allegati"
        # limite elementi lotto
        self.cifre_max_elementi_lotto = 4
        self.cifre_max_nome_lotto = 4
        
        self.project = QgsProject.instance()
        self.project_home = Path(self.project.homePath())
        self.lotto = self.project.baseName()[:self.cifre_max_nome_lotto]
        
        self.selected_feature = None  # per memorizzare la feature selezionata
        self.layer = None # per memorizzare il layer selezionato

        self.attached_field:str = None
        self.attached_subdir:str = None
        self.attached_type:str = None
        self.attached_name:str = None
        
        return

    def run(self):
        if not self.perform_checks():  # Esegue i controlli
            return
        
        # verifica se nella feature è memorizzato un file
        attached_value = self.selected_feature[self.attached_field]
        if not isinstance(attached_value, QVariant):
            save_dir = self.project_home / self.lotto / self.attached_dir / self.attached_subdir
            file_path = save_dir / attached_value
            if not file_path.exists():
                msg = f"Errore: non esiste il file {file_path}"
                self.iface.messageBar().pushMessage("Warning", msg, level=Qgis.Warning)
                print(msg)
                return
            self.open_with_system_viewer(file_path)
            msg = f"Successo: Aperto file {file_path}"
            self.iface.messageBar().pushMessage("Successo", msg, level=Qgis.Success)
            print(msg)
            return
        
        file_path = self.open_file_dialog()
        if not file_path:
            return
        
        self.open_with_system_viewer(file_path)
        
        # Dopo la chiusura del visualizzatore, mostra il messaggio per salvare il file
        self.prompt_to_save(file_path)
        
        return

    def perform_checks(self):
        # Eseguire i controlli necessari
        self.layer:QgsVectorLayer = self.iface.activeLayer()
        if not self.layer:
            msg = "Errore: Nessun layer attivo."
            self.iface.messageBar().pushMessage("Errore", msg, level=Qgis.Warning)
            print(msg)
            return False
        
        selection = self.layer.selectedFeatures()
        if not selection:
            msg = "Errore: Nessuna feature selezionata."
            self.iface.messageBar().pushMessage("Errore", msg, level=Qgis.Warning)
            print(msg)
            return False
        
        self.selected_feature = selection[0]
        
        # check valore NULL
        valore_univoco = self.selected_feature[self.UNIVOCO_FEATURE]
        if isinstance(valore_univoco, QVariant):
            msg = f"La feature selezionata non ha {self.UNIVOCO_FEATURE} valido"
            self.iface.messageBar().pushMessage("Info", msg, level=Qgis.Info)
            print(msg)
            return False

        # verifico che il layer selezionato sia un layer con allegati
        # ottengo un field con associata una directory per gli allegati
        
        # path del db generale
        connect_db:DatabaseConnect = DatabaseConnect()
        if not connect_db:
            msg = f"DB non trovato"
            return False
        
        # recupero il nome del layer dal lotto.gpkg    
        layer_source_name:str = self.get_layer_source_name(self.layer)
        print(layer_source_name)
        
        # field dove è memorizzato l'allegato sul layer
        result = connect_db.get_layer_field_with_attach('',layer_source_name)
        if not result:
            msg = f"Il layer {self.layer.name()} non prevede allegati"
            self.iface.messageBar().pushMessage("Info", msg, level=Qgis.Info)
            print(msg)
            return False

        # nome field ove memorizzare il nome dell'allegato
        # e directory ove memorizzare il file allegato
        self.attached_field, self.attached_subdir, self.attached_type = result


        return True

    def open_file_dialog(self):
        # Apertura dialog per scegliere un file
        file_dialog = QFileDialog()
        file_path, _ = file_dialog.getOpenFileName(None, "Seleziona allegato", self.project_home.as_posix(), f"File (*.{self.attached_type})")
        return Path(file_path) if file_path else None

    def open_with_system_viewer(self, file_path: Path):
        # Apertura del file con il visualizzatore predefinito del sistema
        try:
            if sys.platform == 'win32':  # Windows
                process = subprocess.Popen(['start', str(file_path)], shell=True)
            elif sys.platform == 'darwin':  # macOS
                process = subprocess.Popen(['open', str(file_path)])
            else:  # Linux/Unix
                process = subprocess.Popen(['xdg-open', str(file_path)])

        except Exception as e:
            msg = f"Errore: Impossibile aprire il file: {str(e)}"
            self.iface.messageBar().pushMessage("Errore", msg, level=Qgis.Critical)
            print(msg)

    def prompt_to_save(self, file_path: Path):
        # Messaggio per chiedere se salvare il file
        reply = QMessageBox.question(None, 'Salva allegato', 'Vuoi salvare il file?',
                                     QMessageBox.Yes | QMessageBox.No, QMessageBox.No)

        if reply == QMessageBox.Yes:
            self.attached_name = self.save_file(file_path)
            self.setAttributValue(self.layer, self.selected_feature, self.attached_field, self.attached_name)

    def save_file(self, file_path: Path):
        # Salva il file nella cartella specificata
        save_dir = self.project_home / self.lotto / self.attached_dir / self.attached_subdir
        
        try:
            save_dir.mkdir(parents=True, exist_ok=True)

            # Prende il nome dal campo RG_COD della feature selezionata
            rg_cod = self.selected_feature[self.UNIVOCO_FEATURE]
            file_name = f"{rg_cod}{file_path.suffix}"
            save_path = save_dir / file_name

            # Copia del file
            save_path.write_bytes(file_path.read_bytes())

            msg = f"Successo: File salvato in: {save_path}"
            self.iface.messageBar().pushMessage("Successo", msg, level=Qgis.Info)
            print(msg)
            
            return file_name

        except Exception as e:
            msg = f"Errore: Impossibile salvare il file: {str(e)}"
            self.iface.messageBar().pushMessage("Errore", msg, level=Qgis.Critical)
            print(msg)
    
    def setAttributValue(self, layer:QgsVectorLayer, feature:QgsFeature, field:str, value:str) -> None:
        
        # Inizia una transazione per modificare la feature
        with edit(layer):
            # Supponiamo di voler modificare l'attributo chiamato "nome_attributo"
            feature.setAttribute(field, value)

            # Aggiorna la feature nel layer
            updated = layer.updateFeature(feature)
            
        if not updated:
            msg = f"Feature NON aggiornata"
            print(msg)
            return
        
        msg = f"Salvato allegato {layer.name()=} {feature.id()=} {field=} {value=}"
        self.iface.messageBar().pushMessage("Successo", msg, level=Qgis.Info)
        print(msg)
        
        return
    
    def get_layer_source_name(self, layer:QgsVectorLayer):
        # Verifica se il layer è un vettore
        if not(layer and isinstance(layer, QgsVectorLayer)):
            # msg = f"Nessun layer vettoriale attivo o layer non valido. layer_name: {layer.name()} layer_id: {layer.id()}."
            # print(msg)
            # iface.messageBar().pushMessage(u'get_layer_source_name', msg, level=Qgis.Critical)
            return
        
        # Ottieni la sorgente del provider del layer (es: "dbname='path_to_file.gpkg' table=\"table_name\" (geometry_column) sql=")
        provider_source = layer.source()
        # Usa una regex per estrarre il nome della tabella
        match = re.search(r'(?<=layername=)[^|]+', provider_source)
        if not match:
            # msg = f"Non è stato possibile determinare il nome originale del layer. layer_name: {layer.name()} layer_id: {layer.id()} in {provider_source}."
            # print(msg)
            # iface.messageBar().pushMessage(u'get_layer_source_name', msg, level=Qgis.Critical)
            return
        
        layer_name = match[0]
        # msg = f"get_layer_source_name -> layer_name: {layer.name()} layer_id: {layer.id()} layer_source_name: {layer_name}"
        # print(msg)
        
        return layer_name
    

