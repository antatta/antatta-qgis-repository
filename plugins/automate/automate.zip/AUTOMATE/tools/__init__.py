# -*- coding: utf-8 -*-
"""
Tools module for AUTOMATE plugin v2.0
Contains all functional tools: rg_cod, photo, attachments, controller, zip.
"""
