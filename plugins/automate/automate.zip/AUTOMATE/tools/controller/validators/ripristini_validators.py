# -*- coding: utf-8 -*-
"""
Ripristini Validators - Validators per controlli su layer ripristini.
Contiene validators per verifiche specifiche sui ripristini e allaciamenti.
"""
# # 1. FUTURE IMPORTS
from __future__ import annotations

# # 2. STANDARD LIBRARY
from abc import ABC, abstractmethod

# # 3. THIRD-PARTY LIBRARIES
from osgeo import ogr

# # 5. LOCAL IMPORTS
from ..error_types import ErrorSeverity
from . import ControllerContext, ValidatorRegistry
from .base_validator import BaseValidator
from .overlap_detector import OverlapDetector


class BaseRipristiniValidator(BaseValidator, ABC, OverlapDetector):
    """
    Classe base astratta per i validator dei ripristini.

    Implementa la logica comune del metodo _check_rete_ripristini originale,
    lasciando solo i parametri dei layer come differenza tra le implementazioni.
    """

    def __init__(self, context: ControllerContext):
        """
        Inizializza il validator dei ripristini.
        
        Args:
            context: Context del controller.
        """
        super().__init__(context)

    @property
    @abstractmethod
    def ly_tubazione(self) -> str:
        """Nome del layer tubazione/allacciamenti da utilizzare."""
        pass

    @property
    @abstractmethod
    def ly_ripristini(self) -> str:
        """Nome del layer ripristini da utilizzare."""
        pass

    def _controllo_sottocopertura(
        self, tubazioni_filtered: dict, ripristini_filtered: dict, crs: str
    ) -> bool:
        """
        Controllo sottocopertura per tutte le tubazioni.

        Per ogni tubazione, individua se ha porzioni non coperte da poligoni di ripristini dello stesso livello.
        Se uncovered_length > soglia, genera gli errori corrispondenti.

        Args:
            tubazioni_filtered: dict {fid: {univoco, livello, length, geometry}} di tutte le tubazioni
            ripristini_filtered: dict con {fid: {univoco, livello, geometry}} di tutti i ripristini
            crs: sistema di coordinate (formato EPSG:xxxx)

        Returns:
            bool: True se nessun errore di sottocopertura, False se ci sono errori
        """
        has_errors = False

        # Processa ogni tubazione
        for fid_tub, tub_data in tubazioni_filtered.items():
            univoco_tub = tub_data["univoco"]
            length = tub_data["length"]
            tubazione_geometry = tub_data["geometry"]
            tubazione_livello = tub_data["level"]

            # STEP 1: Individua tutti i poligoni di ripristini che hanno lo stesso livello E che intersecano l'elemento analizzato
            ripristini_intersecting = [] # lista delle geometrie dei poligoni di ripristino con stesso livello E che intersecano l'elemento di tubazione
            ripristini_involved_fid = [] # lista dei FIDs dei poligoni di ripristino con stesso livello E che intersecano l'elemento di tubazione
            ripristini_involved = [] # lista dei codici univoci dei poligoni di ripristino con stesso livello E che intersecano l'elemento di tubazione

            for fid_rip, rip_data in ripristini_filtered.items():
                if rip_data["level"] == tubazione_livello:
                    intersection_test = tubazione_geometry.Intersection(
                        rip_data["geometry"]
                    )
                    if intersection_test and not intersection_test.IsEmpty():
                        ripristini_intersecting.append(rip_data["geometry"])
                        ripristini_involved_fid.append(rip_data["fid"])
                        ripristini_involved.append(rip_data["univoco"])

            # STEP 2: Crea l'unione di tutti i poligoni ripristini che intersecano
            union_ripristini = None
            if ripristini_intersecting:
                union_ripristini = ripristini_intersecting[0].Clone()
                for i in range(1, len(ripristini_intersecting)):
                    union_ripristini = union_ripristini.Union(ripristini_intersecting[i])

            # STEP 3: Calcola la porzione NON coperta (geometria)
            uncovered_geometry = None
            uncovered_length = 0.0

            if union_ripristini is not None:
                # Calcola la porzione NON coperta (geometria)
                uncovered_geometry = tubazione_geometry.Difference(union_ripristini)
                # Calcola la lunghezza NON coperta
                if uncovered_geometry and not uncovered_geometry.IsEmpty():
                    # Calcola la lunghezza NON coperta
                    uncovered_length = uncovered_geometry.Length()
                else:
                    # Nessuna porzione NON coperta
                    uncovered_length = 0.0
            else:
                # Nessuna copertura: tutta la tubazione è scoperta
                uncovered_geometry = tubazione_geometry
                uncovered_length = length
            
            covered_length = length - uncovered_length

            # Se la lunghezza non coperta supera la soglia, genera l'errore
            if uncovered_length > self.context.CONST["max_lunghezza_senza_ripristino"]:
                has_errors = True

                ripristini_involved_fid_str = ", ".join([str(fid) for fid in ripristini_involved_fid]) if ripristini_involved_fid else "Nessuno"
                ripristini_involved_str = ", ".join(ripristini_involved) if ripristini_involved else "Nessuno"
                n_ripristini = len(ripristini_involved)
                
                error_msg = f"Tubazione {univoco_tub} coperta per - {uncovered_length:.02f}m (su {length:.02f}m totali)."
                error_msg += f" La tubazione è attualmente coperta da {n_ripristini} geometrie: "
                error_msg += f"FIDs {ripristini_involved_fid_str}" if ripristini_involved_fid else ""
                error_msg += f" ovvero " if ripristini_involved else ""
                error_msg += f"UNIVOCI {ripristini_involved_str}" if ripristini_involved else ""
                error_msg += f"."

                # Aggiungi l'errore al sistema di reporting
                self.add_error(
                    layer_name=self.ly_ripristini,
                    fid=str(fid_tub),
                    field_name="geometry",
                    message=error_msg,
                    severity=ErrorSeverity.CRITICAL,
                    geometry=uncovered_geometry,  # Geometria della porzione scoperta
                    crs=crs,
                    metadata={
                        "tubazione_length": round(length, 4),
                        "uncovered_length": round(uncovered_length, 4),
                        "covered_length": round(covered_length, 4),
                        "validation_type": "sottocopertura_analysis",
                        "tolerance": self.context.CONST["max_lunghezza_senza_ripristino"],
                        "univoco_tubazione": univoco_tub,
                        "geometry_type": "uncovered_part",  # Tipo geometria per chiarezza
                    },
                )

        return not has_errors

    def _controllo_sovracopertura(
        self, tubazioni_filtered: dict, ly_ripristini_obj: ogr.Layer, crs: str, error_strategy: str = "linestring"
    ) -> bool:
        """
        Controllo sovracopertura per tutte le tubazioni.

        Per ogni tubazione, individua se ha porzioni coperte da zone di sovrapposizione 
        tra ripristini dello stesso livello. Delega la generazione degli errori ai metodi specializzati.

        Args:
            tubazioni_filtered: dict {fid: {univoco, livello, length, geometry}} di tutte le tubazioni
            ly_ripristini_obj: ogr.Layer, oggetto del layer dei ripristini
            crs: sistema di coordinate (formato EPSG:xxxx)
            error_strategy: str, "linestring" (default) o "multiline" per il tipo di errori generati

        Returns:
            bool: True se nessun errore di sovracopertura, False se ci sono errori
        """
        has_errors = False
        
        # Usa la nuova interfaccia _detect_overlap_zones che raggruppa automaticamente per livello
        overlap_zones_by_level = self._detect_overlap_zones(ly_ripristini_obj, self.context)

        # Se non ci sono zone di overlap, nessun errore
        if not overlap_zones_by_level:
            return not has_errors

        # STEP 2: Processa ogni tubazione usando le zone di overlap pre-calcolate
        for fid_tub, tub_data in tubazioni_filtered.items():
            univoco_tub = tub_data["univoco"]
            length = tub_data["length"]
            tubazione_geometry = tub_data["geometry"]
            tubazione_livello = tub_data["level"]

            # Trova le zone di overlap per il livello della tubazione corrente
            relevant_overlap_zones = {}
            for _, zone_data in overlap_zones_by_level.items():
                # Le zone sono già raggruppate per livello, filtriamo quelle del livello corrente
                if zone_data.get("level") == tubazione_livello:
                    zone_id = zone_data['zone_id']
                    relevant_overlap_zones[zone_id] = zone_data
            
            # Se non ci sono zone di overlap per questo livello, passa alla tubazione successiva
            if not relevant_overlap_zones:
                continue

            # STEP 3: Calcola le intersezioni tra tubazione e zone di overlap
            intersections_data = []
            
            for _, zone_data in relevant_overlap_zones.items():
                zone_id = zone_data['zone_id']
                zone_geometry_ogr = zone_data["geometry"]  # Geometria OGR della zona
                zone_fids = zone_data["fids"]
                zone_univoci = zone_data["univoco"]
                
                # Calcola intersezione tra tubazione e zona di sovrapposizione
                intersection = tubazione_geometry.Intersection(zone_geometry_ogr)
                
                if intersection and not intersection.IsEmpty():
                    intersection_length = intersection.Length()
                    if intersection_length > 0:
                        # Salva i dati dell'intersezione per i metodi di generazione errori
                        intersections_data.append({
                            "zone_id": zone_id,
                            "zone_fids": zone_fids,
                            "zone_univoci": zone_univoci,
                            "intersection_geometry": intersection,
                            "intersection_length": intersection_length,
                            "overlap_count": zone_data.get("overlap_count", 2)
                        })

            # STEP 4: Se ci sono intersezioni significative, delega la generazione degli errori
            if intersections_data:
                # Calcola la lunghezza totale di sovracopertura per controllare la soglia
                total_length = sum(data["intersection_length"] for data in intersections_data)
                
                if total_length > self.context.CONST["max_lunghezza_senza_ripristino"]:
                    # Delega la generazione degli errori al metodo appropriato
                    tubazione_data = {
                        "fid": fid_tub,
                        "univoco": univoco_tub,
                        "length": length,
                        "geometry": tubazione_geometry,
                        "level": tubazione_livello
                    }
                    
                    if error_strategy == "multiline":
                        errors_generated = self._generate_multiline_overcoverage_errors(
                            tubazione_data, intersections_data, crs
                        )
                    elif error_strategy == "linestring":
                        errors_generated = self._generate_linestring_overcoverage_errors(
                            tubazione_data, intersections_data, crs
                        )
                    else:
                        raise ValueError(f"Strategia di errore non supportata: {error_strategy}")
                    
                    if errors_generated:
                        has_errors = True

        return not has_errors

    def _generate_multiline_overcoverage_errors(
        self, tubazione_data: dict, intersections_data: list, crs: str
    ) -> bool:
        """
        Genera un singolo errore per tubazione con geometria MultiLineString.
        
        Accumula tutte le intersezioni in una geometria union e genera un errore
        con descrizione di tutte le zone coinvolte (comportamento originale).
        
        Args:
            tubazione_data: dict con dati della tubazione {fid, univoco, length, geometry, level}
            intersections_data: list di dict con dati delle intersezioni
            crs: sistema di coordinate
            
        Returns:
            bool: True se sono stati generati errori, False altrimenti
        """
        # Accumula tutte le geometrie di intersezione
        total_overcovered_geometry = None
        total_overcovered_length = 0.0
        
        for intersection_info in intersections_data:
            intersection_geom = intersection_info["intersection_geometry"]
            
            if total_overcovered_geometry is None:
                total_overcovered_geometry = intersection_geom.Clone()
            else:
                total_overcovered_geometry = total_overcovered_geometry.Union(intersection_geom)
        
        # Calcola lunghezza totale
        if total_overcovered_geometry and not total_overcovered_geometry.IsEmpty():
            total_overcovered_length = total_overcovered_geometry.Length()
        
        # Crea stringa descrittiva delle zone coinvolte
        zones_description = []
        for intersection_info in intersections_data:
            zone_id = intersection_info["zone_id"]
            zone_univoci_str = ", ".join(str(u) for u in intersection_info["zone_univoci"])
            zone_fids_str = ", ".join(str(f) for f in intersection_info["zone_fids"])
            zone_overlap_count = intersection_info["overlap_count"]
            
            zones_description.append(
                f"{zone_id} ({zone_overlap_count} geometrie con: "
                f"FIDs {zone_fids_str} ovvero Univoci {zone_univoci_str})"
            )

        zones_description_str = "; ".join(zones_description)
        error_msg = (
            f"Tubazione {tubazione_data['univoco']} coperta per + "
            f"{total_overcovered_length:.02f}m. Eliminare le zone di overlap: "
            f"Zona {zones_description_str}."
        )

        # Aggiungi l'errore al sistema di reporting
        self.add_error(
            layer_name=self.ly_ripristini,
            fid=str(tubazione_data['fid']),
            field_name="geometry",
            message=error_msg,
            severity=ErrorSeverity.CRITICAL,
            geometry=total_overcovered_geometry,  # MultiLineString con tutte le intersezioni
            crs=crs,
            metadata={
                "tubazione_length": round(tubazione_data['length'], 4),
                "overcovered_length": round(total_overcovered_length, 4),
                "validation_type": "sovracopertura_analysis_multiline",
                "tolerance": self.context.CONST["max_lunghezza_senza_ripristino"],
                "univoco_tubazione": tubazione_data['univoco'],
                "geometry_type": "overcovered_part_multiline",
                "overlap_zones_count": len(intersections_data),
                "overlap_zones_details": [
                    {
                        "zone_id": intersection["zone_id"],
                        "overlap_count": intersection["overlap_count"],
                        "intersection_length": round(intersection["intersection_length"], 4),
                        "involved_univoci": intersection["zone_univoci"]
                    }
                    for intersection in intersections_data
                ]
            },
        )
        
        return True

    def _generate_linestring_overcoverage_errors(
        self, tubazione_data: dict, intersections_data: list, crs: str
    ) -> bool:
        """
        Genera un errore separato per ogni intersezione con geometria LineString.
        
        Per ogni zona di overlap che interseca la tubazione, genera un errore
        specifico con geometria semplice LineString.
        
        Args:
            tubazione_data: dict con dati della tubazione {fid, univoco, length, geometry, level}
            intersections_data: list di dict con dati delle intersezioni
            crs: sistema di coordinate
            
        Returns:
            bool: True se sono stati generati errori, False altrimenti
        """
        errors_generated = False
        
        for intersection_info in intersections_data:
            zone_id = intersection_info["zone_id"]
            zone_univoci_str = ", ".join(str(u) for u in intersection_info["zone_univoci"])
            zone_fids_str = ", ".join(str(f) for f in intersection_info["zone_fids"])
            zone_overlap_count = intersection_info["overlap_count"]
            intersection_length = intersection_info["intersection_length"]
            intersection_geometry = intersection_info["intersection_geometry"]
            
            zones_description_str = f"{zone_id} ({zone_overlap_count} geometrie con: FIDs {zone_fids_str} ovvero Univoci {zone_univoci_str})"
            
            error_msg = (
                f"Tubazione {tubazione_data['univoco']} + coperta per "
                f"{intersection_length:.02f}m. Eliminare la zona di overlap: "
                f"Zona {zones_description_str}."
            )

            # Genera un errore specifico per questa intersezione
            self.add_error(
                layer_name=self.ly_ripristini,
                fid=str(tubazione_data['fid']),
                field_name="geometry",
                message=error_msg,
                severity=ErrorSeverity.CRITICAL,
                geometry=intersection_geometry,  # LineString semplice per questa intersezione
                crs=crs,
                metadata={
                    "tubazione_length": round(tubazione_data['length'], 4),
                    "intersection_length": round(intersection_length, 4),
                    "validation_type": "sovracopertura_analysis_linestring",
                    "tolerance": self.context.CONST["max_lunghezza_senza_ripristino"],
                    "univoco_tubazione": tubazione_data['univoco'],
                    "geometry_type": "overcovered_part_linestring",
                    "zone_id": zone_id,
                    "overlap_count": zone_overlap_count,
                    "involved_fids": intersection_info["zone_fids"],
                    "involved_univoci": intersection_info["zone_univoci"]
                },
            )
            
            errors_generated = True
        
        return errors_generated

    def _load_filtered_tubazioni(self, layer_tubazione: ogr.Layer) -> tuple[dict, set]:
        """
        Carica e filtra le tubazioni dal layer secondo i criteri di business.
        
        Filtra solo tubazioni con:
        - Tecnologia scavo tradizionale
        - Tipo intervento: nuova posa o rimozione
        
        Args:
            layer_tubazione: Layer OGR delle tubazioni/allacciamenti
            
        Returns:
            tuple[dict, set]: (tubazioni_filtered, livelli_set)
                tubazioni_filtered: dict {fid: {univoco, livello, length, geometry}}
                livelli_set: set di tutti i livelli presenti
        """
        tubazioni_filtered = {}  # {fid: {'univoco', 'livello', 'length', 'geometry'}}
        livelli = set()  # Set ove memorizzare tutti i valori di livello distinti
        
        # Carica e filtra le tubazioni (solo scavo tradizionale + nuove pose/rimozioni)
        layer_tubazione.ResetReading()
        tubazione_feature: ogr.Feature
        while (tubazione_feature := layer_tubazione.GetNextFeature()) is not None:
            fid = tubazione_feature.GetFID()

            # Applica il filtro: scavo tradizionale e nuove pose o rimozioni
            tecnologia_scavo = tubazione_feature.GetField(
                self.context.CONST["field_tecnologia_scavo"]
            )
            tipo_interv = tubazione_feature.GetField(
                self.context.CONST["field_tipo_interv"]
            )

            if tecnologia_scavo == self.context.CONST[
                "value_tecnologia_scavo_tradizionale"
            ] and tipo_interv in [
                self.context.CONST["value_tipo_intervento_nuova_posa"],
                self.context.CONST["value_tipo_intervento_rimozione"],
            ]:

                univoco = tubazione_feature.GetFieldAsString(
                    self.context.CONST["UNIVOCO_FEATURE"]
                )
                level = tubazione_feature.GetField(
                    self.context.CONST["field_livello"]
                )
                if level is None:
                    level = self.context.CONST["value_livello_standard"]

                geom = tubazione_feature.GetGeometryRef()
                if geom:
                    length = geom.Length()
                    tubazioni_filtered[fid] = {
                        "fid": fid,
                        "univoco": univoco,
                        "level": level,
                        "length": length,
                        "geometry": geom.Clone(),
                    }

                # aggiungi il livello all'insieme dei livelli
                livelli.add(level)
        
        return tubazioni_filtered, livelli

    def _load_ripristini(self, layer_ripristini: ogr.Layer) -> dict:
        """
        Carica tutti i ripristini dal layer.
        
        Args:
            layer_ripristini: Layer OGR dei ripristini
            
        Returns:
            dict: ripristini_filtered {fid: {univoco, livello, geometry}}
        """
        ripristini_filtered = {}  # {fid: {'univoco', 'livello', 'geometry'}}
        
        layer_ripristini.ResetReading()
        ripristino_feature: ogr.Feature
        while (ripristino_feature := layer_ripristini.GetNextFeature()) is not None:
            fid = ripristino_feature.GetFID()

            univoco = ripristino_feature.GetFieldAsString(
                self.context.CONST["UNIVOCO_FEATURE"]
            )
            livello = ripristino_feature.GetField(self.context.CONST["field_livello"])
            if livello is None:
                livello = self.context.CONST["value_livello_standard"]

            geom = ripristino_feature.GetGeometryRef()
            if geom:
                ripristini_filtered[fid] = {
                    "fid": fid,
                    "univoco": univoco,
                    "level": livello,
                    "geometry": geom.Clone(),
                }
        
        return ripristini_filtered

    def validate(self) -> bool:
        """
        Template method che implementa la logica _check_rete_ripristini originale.

        Controlla che la tubazione/allacciamenti abbia la corretta copertura di ripristini.

        Returns:
            bool: True se i controlli passano, False altrimenti
        """

        check: bool = True

        # Ottieni i layer con OGR
        layer_ripristini: ogr.Layer = self.context.src_ds.GetLayerByName(
            self.ly_ripristini
        )
        layer_tubazione: ogr.Layer = self.context.src_ds.GetLayerByName(
            self.ly_tubazione
        )

        # Verifica presenza dei layer con messaggi di errore critici specifici
        if layer_ripristini is None:
            self.add_error(
                layer_name=self.ly_ripristini,
                fid="*",
                field_name="*",
                message=f"Layer '{self.ly_ripristini}' non trovato nel database GPKG",
                severity=ErrorSeverity.CRITICAL,
                metadata={
                    "validation_type": "layer_availability",
                    "gpkg_path": str(self.context.lotto_gpkg_path),
                },
            )

        if layer_tubazione is None:
            self.add_error(
                layer_name=self.ly_tubazione,
                fid="*",
                field_name="*",
                message=f"Layer '{self.ly_tubazione}' non trovato nel database GPKG",
                severity=ErrorSeverity.CRITICAL,
                metadata={
                    "validation_type": "layer_availability",
                    "gpkg_path": str(self.context.lotto_gpkg_path),
                },
            )

        # Se uno dei layer non esiste, termina con errore
        if layer_ripristini is None or layer_tubazione is None:
            return False

        # Carica e filtra le tubazioni tramite metodo dedicato
        tubazioni_filtered, livelli = self._load_filtered_tubazioni(layer_tubazione)
        
        # Ottieni il CRS dal layer tramite metodo dedicato
        crs_tubazione = self.get_layer_crs(layer_tubazione)

        # Carica tutti i ripristini
        ripristini_filtered = self._load_ripristini(layer_ripristini)

        # Esegui controlli di copertura
        check_sottocopertura = self._controllo_sottocopertura(
            tubazioni_filtered, ripristini_filtered, crs_tubazione
        )

        check_sovracopertura = self._controllo_sovracopertura(
            tubazioni_filtered, layer_ripristini, crs_tubazione,
            'linestring'
        )
        
        # Restituisci True solo se entrambi i controlli passano
        check = check_sottocopertura and check_sovracopertura

        return check


@ValidatorRegistry.register
class AllacciamentiRipristiniValidator(BaseRipristiniValidator):
    """
    Validator per verificare coerenza tra allacciamenti e ripristini.

    Utilizza la logica comune _check_rete_ripristini con i layer
    ly_allacciamenti e ly_ripristini_allacciamenti.
    """

    # Class variables per metadata (nuovo sistema)
    name: str = "copertura_allacci"
    description: str = "Verifica coerenza tra allacciamenti e ripristini"
    display_name: str = "tubazione +/- ripristinata (allacci)"

    @property
    def ly_tubazione(self) -> str:
        """Layer allacciamenti da verificare."""
        return self.context.CONST["ly_allacciamenti"]

    @property
    def ly_ripristini(self) -> str:
        """Layer ripristini allacciamenti da verificare."""
        return self.context.CONST["ly_ripristini_allacciamenti"]


@ValidatorRegistry.register
class ReteRipristiniValidator(BaseRipristiniValidator):
    """
    Validator per verificare coerenza tra rete e ripristini.

    Utilizza la logica comune _check_rete_ripristini con i layer
    ly_tubazione e ly_ripristini.
    """

    # Class variables per metadata (nuovo sistema)
    name: str = "copertura_rete"
    description: str = "Verifica coerenza tra rete e ripristini"
    display_name: str = "tubazione +/- ripristinata (rete)"

    @property
    def ly_tubazione(self) -> str:
        """Layer tubazione da verificare."""
        return self.context.CONST["ly_tubazione"]

    @property
    def ly_ripristini(self) -> str:
        """Layer ripristini da verificare."""
        return self.context.CONST["ly_ripristini"]
