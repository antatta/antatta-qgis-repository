# -*- coding: utf-8 -*-
"""
Linked Layer Validator - Validator per controlli di integrità dei layer collegati.
Verifica che i valori nei campi di foreign key esistano nei layer collegati.
"""
# # 1. FUTURE IMPORTS
from __future__ import annotations

# # 2. STANDARD LIBRARY
from typing import Set

# # 3. THIRD-PARTY LIBRARIES
from osgeo import ogr

# # 5. LOCAL IMPORTS
from ..error_types import ErrorSeverity
from . import ControllerContext, ValidatorRegistry
from .base_validator import BaseValidator


@ValidatorRegistry.register
class LinkedLayerValidator(BaseValidator):
    """
    Validator per verificare l'integrità dei layer collegati.

    Controlla che i valori nei campi di foreign key esistano nei layer collegati
    secondo le relazioni definite nel database di configurazione.
    """
    
    # Class variables per metadata (nuovo sistema)
    name: str = "linked_layer"
    description: str = "Verifica l'integrità dei layer collegati"
    display_name: str = "linked_layer"
    
    def __init__(self, context: ControllerContext):
        super().__init__(context)

    def validate(self) -> bool:
        """
        Verifica i layer collegati nei layer SDI.

        Args:
            layers_sdi: Lista custom di layer da verificare.
                       Se None, usa la lista dal context

        Returns:
            bool: True se tutte le relazioni sono valide, False altrimenti
        """
        check = True

        # Cicla su tutti i layer del file gpkg
        for layer in self.get_sdi_layers():
            if not self.layer_exists(layer):
                continue

            layer_result = self._validate_layer_relations(layer)
            if not layer_result:
                check = False

        return check

    def _validate_layer_relations(self, layer: str) -> bool:
        """
        Valida le relazioni per un singolo layer.

        Args:
            layer: Nome del layer da validare

        Returns:
            bool: True se tutte le relazioni sono valide, False altrimenti
        """
        check = True

        # Ottieni le informazioni di collegamento per il layer corrente
        try:
            results = self.context.db.get_linked_layer("", layer)
        except Exception as e:
            self.add_error(
                layer_name=layer,
                fid="*",
                field_name="*",
                message=f"Errore ottenimento relazioni layer: {e}",
                severity=ErrorSeverity.ERROR,
            )
            return False

        if not results:
            return True  # Nessuna relazione configurata

        for result in results:
            relation_result = self._validate_relation(layer, result)
            if not relation_result:
                check = False

        return check

    def _validate_relation(self, layer: str, relation: tuple) -> bool:
        """
        Valida una singola relazione.

        Args:
            layer: Nome del layer sorgente
            relation: Tupla (fk_field, linked_layer, linked_field)

        Returns:
            bool: True se la relazione è valida, False altrimenti
        """
        fk_field, linked_layer, linked_field = relation
        check = True

        # Ottieni il layer oggetto
        layer_obj = self.get_lotto_layer(layer)
        if layer_obj is None:
            return True

        # Controlla se il campo FK_FIELD esiste nel layer corrente
        layer_fields = []
        layer_defn = layer_obj.GetLayerDefn()
        for i in range(layer_defn.GetFieldCount()):
            layer_fields.append(layer_defn.GetFieldDefn(i).GetName())

        if fk_field not in layer_fields:
            return True  # Campo non presente, skip

        # Ottieni il layer collegato
        linked_layer_obj = self.get_lotto_layer(linked_layer)
        if linked_layer_obj is None:
            self.add_error(
                layer_name=layer,
                fid="*",
                field_name=fk_field,
                message=f"Layer collegato '{linked_layer}' non trovato",
                severity=ErrorSeverity.ERROR,
                metadata={
                    "linked_layer": linked_layer,
                    "linked_field": linked_field,
                    "relation_type": "missing_target_layer",
                },
            )
            return False

        # Ottieni tutti i valori LINKED_FIELD dal layer collegato
        linked_values = self._get_linked_values(linked_layer_obj, linked_field)

        # Controlla ogni feature nel layer corrente
        layer_obj.ResetReading()
        while (feature := layer_obj.GetNextFeature()) is not None:
            feature_result = self._validate_feature_relation(
                layer, feature, fk_field, linked_layer, linked_field, linked_values
            )
            if not feature_result:
                check = False

        return check

    def _get_linked_values(
        self, linked_layer_obj: ogr.Layer, linked_field: str
    ) -> Set[str]:
        """
        Ottiene tutti i valori unici dal campo collegato.

        Args:
            linked_layer_obj: Layer oggetto collegato
            linked_field: Nome del campo collegato

        Returns:
            Set di valori unici
        """
        linked_values = set()

        linked_layer_obj.ResetReading()
        while (linked_feature := linked_layer_obj.GetNextFeature()) is not None:
            linked_value = linked_feature.GetFieldAsString(linked_field)
            linked_values.add(linked_value)

        return linked_values

    def _validate_feature_relation(
        self,
        layer: str,
        feature: ogr.Feature,
        fk_field: str,
        linked_layer: str,
        linked_field: str,
        linked_values: Set[str],
    ) -> bool:
        """
        Valida la relazione per una singola feature.

        Args:
            layer: Nome del layer sorgente
            feature: Feature da validare
            fk_field: Nome del campo foreign key
            linked_layer: Nome del layer collegato
            linked_field: Nome del campo collegato
            linked_values: Set dei valori validi

        Returns:
            bool: True se la relazione è valida, False altrimenti
        """
        fid = feature.GetFID()
        fk_value = feature.GetFieldAsString(fk_field)

        # Skip valori vuoti
        if fk_value == "":
            return True

        # Verifica che il valore in FK_FIELD esista nel campo LINKED_FIELD del layer collegato
        if fk_value not in linked_values:
            self.add_error(
                layer_name=layer,
                fid=str(fid),
                field_name=fk_field,
                message=f"Valore '{fk_value}' non trovato nel campo '{linked_field}' del layer '{linked_layer}'",
                severity=ErrorSeverity.ERROR,
                metadata={
                    "fk_value": fk_value,
                    "linked_layer": linked_layer,
                    "linked_field": linked_field,
                    "available_values": list(linked_values)[:10],  # Primi 10 valori
                    "validation_type": "foreign_key_check",
                },
            )
            return False

        return True
