# -*- coding: utf-8 -*-
"""
Distance Validator - Validator unificato per controlli di distanza.
Gestisce i controlli di distanza per diversi tipi di feature (valvole, sfiati, ecc.)
"""

# # 1. FUTURE IMPORTS
from __future__ import annotations  # SEMPRE in cima!

# # 2. STANDARD LIBRARY
from abc import ABC, abstractmethod
from typing import Optional

# # 3. THIRD-PARTY LIBRARIES
from osgeo import ogr

# # 5. LOCAL IMPORTS
from ..error_types import ErrorSeverity
from . import ControllerContext, ValidatorRegistry
from .base_validator import BaseValidator


class BaseDistanceValidator(BaseValidator, ABC): 
    """
    Classe base astratta per i validator di distanza.

    Contiene la logica comune per verificare distanze tra feature
    e un layer di riferimento (tipicamente tubazioni).
    """

    def __init__(self, context: ControllerContext):
        super().__init__(context)

    @property
    @abstractmethod
    def source_layer_key(self) -> str:
        """Chiave CONST per il layer da controllare."""
        pass

    @property
    @abstractmethod
    def target_layer_keys(self) -> list[str]:
        """Lista chiavi CONST per i layer di riferimento (es. tubazioni, allacciamenti)."""
        pass

    @property
    @abstractmethod
    def max_distance_key(self) -> str:
        """Chiave CONST per la distanza massima."""
        pass

    @property
    @abstractmethod
    def feature_type_name(self) -> str:
        """Nome del tipo di feature per i messaggi di errore."""
        pass

    def validate(self) -> bool:
        """
        Verifica le distanze del layer sorgente dai layer target.

        Returns:
            bool: True se tutte le distanze sono corrette, False altrimenti
        """
        # Type narrowing per Pylance - attributi garantiti dal BaseValidator
        assert self.context.CONST is not None
        
        # Ottieni il layer sorgente
        source_layer = self.get_lotto_layer(self.context.CONST[self.source_layer_key])
        if not source_layer:
            return True  # Se non c'è layer sorgente, skip

        # Ottieni tutti i layer target disponibili
        target_layers = []
        for target_key in self.target_layer_keys:
            target_layer = self.get_lotto_layer(self.context.CONST[target_key])
            if target_layer:
                target_layers.append(target_layer)

        if not target_layers:
            return True  # Se non ci sono layer target, skip

        check = True
        max_distance = self.context.CONST[self.max_distance_key]

        # Verifica ogni feature
        source_layer.ResetReading()
        while (feature := source_layer.GetNextFeature()) is not None:
            if not self._validate_feature_distance(feature, target_layers, max_distance):
                check = False

        return check

    def _validate_feature_distance(
        self, feature: ogr.Feature, target_layers: list[ogr.Layer], max_distance: float
    ) -> bool:
        """
        Valida la distanza di una singola feature dai layer target (logica OR).

        Args:
            feature: Feature da validare
            target_layers: Lista dei layer di riferimento
            max_distance: Distanza massima ammessa

        Returns:
            bool: True se la distanza è corretta da almeno un target, False altrimenti
        """
        # Type narrowing per Pylance - CONST è garantito valido dal BaseValidator
        assert self.context.CONST is not None
        
        source_layer_name = self.context.CONST[self.source_layer_key]
        target_layer_names = [self.context.CONST[key] for key in self.target_layer_keys]
        
        fid = feature.GetFID()
        geom_to_check: ogr.Geometry = feature.GetGeometryRef()

        if not geom_to_check:
            self.add_error(
                layer_name=source_layer_name,
                fid=str(fid),
                field_name="geometry",
                message="Geometria non presente",
                severity=ErrorSeverity.CRITICAL,
            )
            return False

        # Ottieni il primo punto (per LineString o Point)
        point_geom = self._extract_point_geometry(geom_to_check, fid, source_layer_name)
        if not point_geom:
            return False

        # Trova la distanza minima da tutti i layer target (logica OR)
        min_distance = float("inf")
        closest_target_name = ""
        
        for target_layer, target_name in zip(target_layers, target_layer_names):
            layer_min_distance = self._calculate_minimum_distance(point_geom, target_layer)
            if layer_min_distance < min_distance:
                min_distance = layer_min_distance
                closest_target_name = target_name

        # Verifica che sia entro la distanza massima
        if min_distance <= max_distance:
            return True # Distanza valida
        
        # Aggiungi errore per distanza non valida (usa geometria OGR direttamente)
        target_names_str = " o ".join(target_layer_names)
        print(f"DEBUG: 🔍 Distanza non valida - {self.feature_type_name}: {min_distance:.2f} m da {closest_target_name} (max: {max_distance} m)")
        self.add_error(
            layer_name=source_layer_name,
            fid=str(fid),
            field_name="geometry",
            message=f"{self.feature_type_name} troppo distante da {target_names_str}: {min_distance:.2f} m da {closest_target_name} (max: {max_distance} m)",
            severity=ErrorSeverity.WARNING,
            geometry=point_geom,  # Geometria OGR - l'ErrorReporter la gestisce automaticamente
            crs=self.get_layer_crs(target_layers[0]) if target_layers else "",
            metadata={
                "measured_distance": round(min_distance, 4),
                "max_allowed_distance": max_distance,
                "validation_type": "spatial_distance",
                "target_layers": target_layer_names,
                "closest_target": closest_target_name,
                "geometry_type": "start_vertex",
                },
            )
        return False

    def _extract_point_geometry(
        self, geometry: ogr.Geometry, fid: int, layer_name: str
    ) -> Optional[ogr.Geometry]:
        """
        Estrae un punto dalla geometria (primo vertice per LineString, punto per Point).

        Args:
            geometry: Geometria da cui estrarre il punto
            fid: ID della feature per messaggi di errore
            layer_name: Nome del layer per messaggi di errore

        Returns:
            ogr.Geometry: Punto estratto o None se errore
        """
        if geometry.GetGeometryType() == ogr.wkbLineString:
            if geometry.GetPointCount() > 0:
                # Estrai coordinate esplicitamente per debug
                point_coords = geometry.GetPoint_2D(0)
                # print(f"DEBUG: 🔍 Coordinate estratte: {point_coords}")
                
                point_geom = ogr.Geometry(ogr.wkbPoint)
                
                # Gestisci le coordinate in modo esplicito
                if len(point_coords) >= 2:
                    x, y = point_coords[0], point_coords[1]
                    # print(f"DEBUG: 🔍 Coordinate usate - X={x}, Y={y}")
                    point_geom.AddPoint_2D(x, y)
                else:
                    # print(f"DEBUG: ⚠️ Coordinate non valide: {point_coords}")
                    return None
                    
                # Debug: verifica che la geometria creata non sia vuota
                # print(f"DEBUG: 🔍 Geometria creata - IsEmpty: {point_geom.IsEmpty()}")
                # print(f"DEBUG: 🔍 Geometria creata - WKT: {point_geom.ExportToWkt()}")
                return point_geom
            else:
                self.add_error(
                    layer_name=layer_name,
                    fid=str(fid),
                    field_name="geometry",
                    message="LineString senza vertici",
                    severity=ErrorSeverity.CRITICAL,
                )
                return None
        elif geometry.GetGeometryType() == ogr.wkbPoint:
            return geometry.Clone()
        else:
            self.add_error(
                layer_name=layer_name,
                fid=str(fid),
                field_name="geometry",
                message=f"Tipo di geometria non supportato: {geometry.GetGeometryType()}",
                severity=ErrorSeverity.CRITICAL,
            )
            return None

    def _calculate_minimum_distance(
        self, point_geom: ogr.Geometry, target_layer: ogr.Layer
    ) -> float:
        """
        Calcola la distanza minima del punto da tutte le feature del layer target.

        Args:
            point_geom: Punto di riferimento
            target_layer: Layer target per il calcolo delle distanze

        Returns:
            float: Distanza minima trovata
        """
        min_distance = float("inf")
        target_layer.ResetReading()

        while (target_feature := target_layer.GetNextFeature()) is not None:
            target_geom = target_feature.GetGeometryRef()
            if target_geom:
                distance = point_geom.Distance(target_geom)
                min_distance = min(min_distance, distance)

        return min_distance


# Implementazioni concrete per valvole e sfiati


@ValidatorRegistry.register
class ValvoleDistanceValidator(BaseDistanceValidator):
    """Validator per verificare la distanza delle valvole dalle tubazioni e allacciamenti."""

    # Class variables per metadata (nuovo sistema)
    name: str = "valvole_distance"
    description: str = "Verifica la distanza delle valvole dalle tubazioni e allacciamenti"
    display_name: str = "distanza valvole"

    def __init__(self, context: ControllerContext):
        super().__init__(context)

    @property
    def source_layer_key(self) -> str:
        return "ly_valvole"

    @property
    def target_layer_keys(self) -> list[str]:
        return ["ly_tubazione", "ly_allacciamenti"]

    @property
    def max_distance_key(self) -> str:
        return "max_distance_valvola"

    @property
    def feature_type_name(self) -> str:
        return "Valvola"


@ValidatorRegistry.register
class SfiatiDistanceValidator(BaseDistanceValidator):
    """Validator per verificare la distanza degli sfiati dalle tubazioni e allacciamenti."""

    # Class variables per metadata (nuovo sistema)
    name: str = "sfiati_distance"
    description: str = "Verifica la distanza degli sfiati dalle tubazioni e allacciamenti"
    display_name: str = "distanza sfiati"

    def __init__(self, context: ControllerContext):
        super().__init__(context)

    @property
    def source_layer_key(self) -> str:
        return "ly_sfiati"

    @property
    def target_layer_keys(self) -> list[str]:
        return ["ly_tubazione", "ly_allacciamenti"]

    @property
    def max_distance_key(self) -> str:
        return "max_distance_sfiato"

    @property
    def feature_type_name(self) -> str:
        return "Primo vertice dello sfiato"
