# -*- coding: utf-8 -*-
"""
/***************************************************************************
 PhotoManager
                                 A QGIS plugin
 The AUTOMATE plug-in
                             -------------------
        begin                : 2024-09-23
        copyright            : (C) 2024 by Ing. Antonio Attadia
        email                : info.antatta@gmail.com
        git sha              : $Format:%H$
 ***************************************************************************/
 class to manage PhotoDownloader, PhotoEditorWindow, PointTool
"""
import re
from pathlib import Path
from PyQt5.QtCore import pyqtSignal, QObject
from qgis.core import Qgis, QgsProject, QgsVectorLayer, QgsFeature, QgsGeometry, QgsPointXY #, edit
from qgis.PyQt.QtCore import QVariant
from qgis.PyQt.QtGui import (QImage, QPixmap)
from .point_tool import PointTool # Classe che genera il punto di ripresa
from .photo_downloader import PhotoDownloader  # Classe che scarica la foto dalle API
from .photo_editor_window import PhotoEditorWindow # Classe per l'editor delle foto
from ..rg_cod.code_manager import CodeManager
from ...database.database_connect import DatabaseConnect

class PhotoManager(QObject):
    rg_cod_generated = pyqtSignal(str)  # Segnale per l'RG_COD generato
    image_attributes = pyqtSignal(QImage, dict) # Segnale per l'avvenuto download dell'immagine
    featureAdded = pyqtSignal(int) # segnale per emissione fid nuova feature
    def __init__(self, iface, API_KEY):
        # Chiama il costruttore della classe padre (QObject)
        super().__init__()
        # Collegamenti segnali
        self.image_attributes.connect(self.openPhotoEditorWindow)

        self.point:QgsPointXY = None
        self.point_tool:PointTool = None
        self.window:PhotoEditorWindow = None
        self.coder:CodeManager = None
        self.file_path:Path = None
        self.iface = iface  # riferimento all'interfaccia QGIS
        self.API_KEY = API_KEY
        self._mode = None
        self._geometry = None
        # campo univoco feature
        self.UNIVOCO_FEATURE:str = "RG_COD"
        # cartella allegati
        self.attached_dir:str = "allegati"
        # limite elementi lotto
        self.cifre_max_elementi_lotto = 4
        self.cifre_max_nome_lotto = 4
        
        self.project = QgsProject.instance()
        self.project_home = Path(self.project.homePath())
        self.lotto = self.project.baseName()[:self.cifre_max_nome_lotto]
        
        self.selected_feature = None  # per memorizzare la feature selezionata
        self.layer = None # per memorizzare il layer selezionato
        
        self.attached_field:str = None
        self.attached_subdir:str = None
        self.attached_type:str = None
        self.attached_name:str = None
        
        self.attributes:dict = {}
        

    def run(self):
        if not self.perform_checks(): # se superato seleziona una feature o None
            return

        if not self.selected_feature:  # Nessuna feature selezionata
            self._mode = 'add'
            self.add_photo()  # Aggiunge una nuova foto
            return
            
        # verifica se nella feature è memorizzato un file
        attached_value = self.selected_feature[self.attached_field]
        if not isinstance(attached_value, QVariant):
            self.file_path:Path = self.project_home / self.lotto / self.attached_dir / self.attached_subdir / attached_value
            if not self.file_path.exists():
                msg = f"Errore: non esiste il file {self.file_path}"
                self.iface.messageBar().pushMessage("Warning", msg, level=Qgis.Warning)
                print(msg)
                return
            
            self._mode = 'edit'
            image = QImage(self.file_path.as_posix())
            self.fid = self.selected_feature.id()
            self.attributes = self.selected_feature.attributeMap()
            self.openPhotoEditorWindow(image, self.attributes)
            return
        
        return

    def perform_checks(self):
        """Verifica che il layer corretto sia selezionato."""
        self.layer = self.iface.activeLayer()
        if not self.layer or not isinstance(self.layer, QgsVectorLayer):
            msg =  "Nessun layer valido selezionato."
            self.iface.messageBar().pushMessage("Errore", msg, level=Qgis.Warning)
            print(msg)
            return False

        # recupero il nome del layer dal lotto.gpkg    
        layer_source_name:str = self.get_layer_source_name(self.layer)
        if layer_source_name != 'SGA_PUNTO_RIF_FOTO':
            msg =  "Il layer selezionato non è quello atteso."
            self.iface.messageBar().pushMessage("Errore", msg, level=Qgis.Warning)
            print(msg)
            return
        print(layer_source_name)
        
        selection = self.layer.selectedFeatures()
        self.selected_feature = selection[0] if selection else None

        # path del db generale
        connect_db:DatabaseConnect = DatabaseConnect()
        if not connect_db:
            msg = f"DB non trovato"
            return False
        
        # field dove è memorizzato l'allegato sul layer
        result = connect_db.get_layer_field_with_attach('',layer_source_name)
        if not result:
            msg = f"Il layer {self.layer.name()} non prevede allegati"
            self.iface.messageBar().pushMessage("Info", msg, level=Qgis.Info)
            print(msg)
            return False

        # nome field ove memorizzare il nome dell'allegato
        # e directory ove memorizzare il file allegato
        self.attached_field, self.attached_subdir, self.attached_type = result


        return True

    def add_photo(self):
        """Se nessuna feature è selezionata, aggiunge una nuova foto tramite PointTool."""
        # Avvia PointTool per catturare un punto e ottenere parametri
        self.point_tool = PointTool(self.iface.mapCanvas(), self.project, self.layer)
        self.iface.mapCanvas().setMapTool(self.point_tool)
        self.point_tool.point_captured.connect(self.download_and_open_photo)
        
        return

    def download_and_open_photo(self, punto:QgsPointXY, data:dict):
        """Scarica la foto da Google API e emette un segnale con la foto e relativi dati."""
        image = self.download_photo(data)
        self.point = punto
        self.image_attributes.emit(image, data)
        return

    def download_photo(self, data:dict):
        """Scarica la foto da Google API"""
        lat = data['LAT']
        long = data['LONG']
        heading = data['HEADING']  
        
        # Scarica la foto utilizzando la classe PhotoDownloader
        downloader = PhotoDownloader(self.iface, self.API_KEY)
        image = downloader.download_photo(lat, long, heading)
        if not image:
            return None
        
        return image
    
    # apre l'ImageEditor con il file selezionato
    def openPhotoEditorWindow(self, image:QImage, attributes:dict) -> None:
        self.window = PhotoEditorWindow()
        self.window.reload.connect(self.reloadPhotoEditorWindow)
        self.window.saved.connect(self.window_saved)
        self.window.closed.connect(self.reset)
        self.window.setBackground(image)
        self.window.setData(attributes)
        self.window.show()
        return
    
    def reloadPhotoEditorWindow(self, data:dict) -> None:
        image = self.download_photo(data)
        self.window.setBackground(image)
        return
    
    def window_saved(self, pixmap: QPixmap, attributes: dict):
            """Viene chiamato quando l'immagine è salvata dal PhotoEditor."""
            self.attributes = attributes
            
            print(f"Modalità a window_saved: {self._mode}")
            if self._mode == 'add':                
                # Aggiungi la geometria della feature
                result = self.add_feature(self.layer)
                if not result:
                    msg = "Errore nell'aggiunta della feature!"
                    self.iface.messageBar().pushCritical('PhotoEditor says', msg)
                    return
                
            # Genera RG_COD dopo aver emesso il segnale featureAdded
                
            result = self.edit_feature(self.fid)
            if not result:
                msg = 'Errore nell\'aggiornamento della feature!'
                self.iface.messageBar().pushCritical('PhotoEditor says', msg)
                return
                
            # Sovrascrive l'immagine nella directory
            result = self.save_pixmap(pixmap, self.file_path)
            if not result:
                msg = "Errore nel salvataggio della foto!"
                self.iface.messageBar().pushCritical('PhotoEditor says', msg)
                return
                
            self.iface.messageBar().pushSuccess('PhotoEditor says', 'Feature aggiunta!')
            self._mode = "edit"
            return


    def add_feature(self, layer:QgsVectorLayer) -> bool:
        result: bool = False
        
        feature = QgsFeature(layer.fields())
        feature.setGeometry(QgsGeometry.fromPointXY(self.point))

        try:
            layer.blockSignals(True)
            layer.startEditing()
            result = layer.addFeature(feature)
            # print("Photo Editor Prima del commit")
            layer.commitChanges()
            # print("Photo Editor dopo del commit")
        except Exception as e:
            layer.rollBack()
            msg = f"Erorre nell'aggiunta della feature al layer. {e}"
            print(msg)
            self.iface.messageBar().pushMessage("Error", msg, level=Qgis.Critical, duration=3)
        finally:
            layer.blockSignals(False)  # Assicurati di sbloccare i segnali alla fine
            
        last_feature = None
        for f in layer.getFeatures():
            if last_feature is None or f.id() > last_feature.id():
                last_feature = f

        self.coder = CodeManager()
        self.coder.run_on_feature(self.project, layer, last_feature)
        
        self.fid = last_feature.id()
        #layer.featureAdded.emit(last_feature.id())  # Emetti il segnale manualmente con la feature aggiunta
        
        return result
    
    def edit_feature(self, fid:int) -> bool:
        # Inizia una transazione per modificare la feature
        self.layer:QgsVectorLayer
        feature = self.layer.getFeature(fid)
        
        attached_value = f"{feature[self.UNIVOCO_FEATURE]}.{self.attached_type}"
        self.file_path = self.project_home / self.lotto / self.attached_dir / self.attached_subdir / attached_value

        # with edit(self.layer):
        #     for field, value in self.attributes.items():
        #         feature.setAttribute(field, value)
        #     feature.setAttribute(self.attached_field, attached_value)
        
        #     # Aggiorna la feature nel layer
        #     updated = self.layer.updateFeature(feature)
            
        # if not updated:
        #     msg = f"Feature NON aggiornata"
        #     print(msg)
        #     return False
        
        
        try:
            self.layer.blockSignals(True) # blocca i segnali per evitare interazioni con altre funzioni
            self.layer.startEditing()
            for field, value in self.attributes.items():
                feature.setAttribute(field, value)
            feature.setAttribute(self.attached_field, attached_value)
            # Aggiorna la feature nel layer
            self.layer.updateFeature(feature)
            # print("Photo Editor Prima del commit")
            self.layer.commitChanges()
            # print("Photo Editor dopo del commit")
        except Exception as e:
            self.layer.rollBack()
            msg = f"Erorre nell'aggiornamento della feature al layer. {e}"
            print(msg)
            self.iface.messageBar().pushMessage("Error", msg, level=Qgis.Critical, duration=3)
        finally:
            self.layer.blockSignals(False)  # Assicura di sbloccare i segnali alla fine
    
        
        return True
    
    def save_pixmap(self, pixmap: QPixmap, file_path: Path, quality: int = 90):
        """Salva l'immagine nella directory con il nome corretto."""
        if pixmap.isNull():
            print("Errore: La QPixmap è vuota")
            return False

        # Assicurati che la directory esista
        file_path.parent.mkdir(parents=True, exist_ok=True)

        # Salva o sovrascrivi l'immagine
        try:
            result = pixmap.save(str(file_path), "JPEG", quality)
            return result
        except Exception as e:
            print(f"Errore nel salvataggio dell'immagine: {e}")
            return False   # aggiunge una feature al layer
        
    
    
    def reset(self, event=None):
        if self.point_tool:
            self.point_tool.reset()
        
        # Reimposta lo stato di editing
        self._mode = 'edit' 
        self._feature_editing = None
        
        return
    
     
    def get_layer_source_name(self, layer:QgsVectorLayer):
        # Verifica se il layer è un vettore
        if not(layer and isinstance(layer, QgsVectorLayer)):
            # msg = f"Nessun layer vettoriale attivo o layer non valido. layer_name: {layer.name()} layer_id: {layer.id()}."
            # print(msg)
            # iface.messageBar().pushMessage(u'get_layer_source_name', msg, level=Qgis.Critical)
            return
        
        # Ottieni la sorgente del provider del layer (es: "dbname='path_to_file.gpkg' table=\"table_name\" (geometry_column) sql=")
        provider_source = layer.source()
        # Usa una regex per estrarre il nome della tabella
        match = re.search(r'(?<=layername=)[^|]+', provider_source)
        if not match:
            # msg = f"Non è stato possibile determinare il nome originale del layer. layer_name: {layer.name()} layer_id: {layer.id()} in {provider_source}."
            # print(msg)
            # iface.messageBar().pushMessage(u'get_layer_source_name', msg, level=Qgis.Critical)
            return
        
        layer_name = match[0]
        # msg = f"get_layer_source_name -> layer_name: {layer.name()} layer_id: {layer.id()} layer_source_name: {layer_name}"
        # print(msg)
        
        return layer_name
    

    