# -*- coding: utf-8 -*-
"""
/***************************************************************************
 PointTool
                                 A QGIS plugin
 PhotoEditor
                              -------------------
        begin                : 2023-02-27
        copyright            : (C) 2023 by Ing. Antonio Attadia
        email                : antonio.attadia@italgas.it
 ***************************************************************************/
 class to create point of view
"""
# Import the PyQt and QGIS libraries
from qgis.PyQt.QtCore import Qt, pyqtSignal
from qgis.gui import QgsMapCanvas, QgsMapTool, QgsRubberBand, QgsMapMouseEvent
from qgis.core import (QgsProject,
                       QgsCoordinateReferenceSystem,
                       QgsCoordinateTransform,
                       QgsWkbTypes,
                       QgsPointXY,
                       QgsVectorLayer
                       )

import math
from .resources import *

    
class PointTool(QgsMapTool):
    point_captured = pyqtSignal(QgsPointXY, dict)  # Segnale personalizzato
    def __init__(self, canvas:QgsMapCanvas, project:QgsProject, layer:QgsVectorLayer,):
        QgsMapTool.__init__(self, canvas)
        self.canvas:QgsMapCanvas = canvas
        self.project:QgsProject = project
        self.layer:QgsVectorLayer = layer
        
        # sistemi di riferimento EPSG
        self.project_crs = self.canvas.mapSettings().destinationCrs() 
        self.layer_crs = QgsCoordinateReferenceSystem(self.layer.crs().authid()) #self.canvas.mapSettings().destinationCrs()
        self.google_crs = QgsCoordinateReferenceSystem(4326)  # WGS 84 / UTM zone 33N
        
        # convertire coordinate da canvas a
        self.xform_to_google = QgsCoordinateTransform(self.project_crs, self.google_crs, self.project)
        self.xform_to_layer = QgsCoordinateTransform(self.project_crs, self.layer_crs, self.project)
        
        self.premuto = False
        self.linea = False
        self.rb = QgsRubberBand(self.canvas, QgsWkbTypes.PointGeometry)
        self.rl = QgsRubberBand(self.canvas, QgsWkbTypes.LineGeometry)
        self.point0 = self.canvas.getCoordinateTransform().toMapCoordinates(0, 0)
        self.point1 = self.canvas.getCoordinateTransform().toMapCoordinates(0, 0)
        

        return
        
    def canvasPressEvent(self, event:QgsMapMouseEvent):            
        if event.button() == Qt.LeftButton:
            x = event.pos().x()
            y = event.pos().y()

            if not self.premuto: 
                self.premuto=True
                self.rb = QgsRubberBand(self.canvas, QgsWkbTypes.PointGeometry)
                self.rb.setColor(Qt.red)
                self.point0 = self.canvas.getCoordinateTransform().toMapCoordinates(x, y)
                self.rb.addPoint(self.point0)  

    def canvasMoveEvent(self, event:QgsMapMouseEvent):            
        x = event.pos().x()
        y = event.pos().y()        
        if self.premuto:
            if not self.linea:              
                self.rl.setColor (Qt.red)
                self.point1 = self.canvas.getCoordinateTransform().toMapCoordinates(x, y)
                self.rl.addPoint(self.point0)  
                self.rl.addPoint(self.point1)
                self.linea=True
            else:
                self.point1 = self.canvas.getCoordinateTransform().toMapCoordinates(x, y)
                self.rl.reset(QgsWkbTypes.LineGeometry)
                self.rl.addPoint(self.point0)  
                self.rl.addPoint(self.point1)
                        
    def canvasReleaseEvent(self, event:QgsMapMouseEvent):
        if event.button() == Qt.LeftButton:
            # memorizza i parametri per Google Street View
            lat, long, heading = self.calculate_parameters(self.point0, self.point1)
            punto = self.xform_to_layer.transform(self.point0)
            
            data = {
                "LAT": lat,
                "LONG": long,
                "HEADING": heading
            }
            self.point_captured.emit(punto, data)  # Emetti il segnale con i dati
        event.accept()
        return

    # resetta per poter ricominciare
    def reset(self):
        self.premuto = False
        self.linea = False
        self.rl.reset()
        self.rb.reset()
        return
    
    # calcola parametri di lat, long, angle
    def calculate_parameters(self, point0:QgsPointXY, point1:QgsPointXY):
        # calcola lat, long, angle
        pt1 = self.xform_to_google.transform(point0)

        angle = math.atan2(point1.x() - point0.x(), point1.y() - point0.y())
        angle = math.degrees(angle)if angle>0 else (math.degrees(angle) + 180)+180

        self.canvas.unsetMapTool(self)
        return pt1.y(), pt1.x(), angle
    
    
    def activate(self):
        pass

    def deactivate(self):
        pass
        
    def isZoomTool(self):
        return False

    def isTransient(self):
        return False

    def isEditTool(self):
        return True    