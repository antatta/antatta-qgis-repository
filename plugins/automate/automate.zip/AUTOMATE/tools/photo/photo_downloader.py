# -*- coding: utf-8 -*-
"""
/***************************************************************************
 PhotoDownloader
                                 A QGIS plugin
 The AUTOMATE plug-in
                             -------------------
        begin                : 2024-09-23
        copyright            : (C) 2024 by Ing. Antonio Attadia
        email                : info.antatta@gmail.com
        git sha              : $Format:%H$
 ***************************************************************************/
 to download, cut and resize image from Google Street View API
"""
import requests
from qgis.PyQt.QtCore import Qt, QRect
from qgis.PyQt.QtGui import QImage

class PhotoDownloader:
    API_URL = "https://maps.googleapis.com/maps/api/streetview"
    API_KEY = ""
    pitch:float = 0.0
    fov:float = 90.0
    rectangle = QRect(20, 220, 600, 400) # serve a tagliare in basso e di lato di 20 (per i loghi) e in alto di 220 per dare aspetto rettangolare
    width:int = 900
    height:int = 600
    
    def __init__(self, iface, API_KEY):
        self.iface = iface
        self.API_KEY = API_KEY

    def download_photo(self, lat, lon, heading):
        self.lat = lat
        self.lon = lon
        self.heading = heading
        params = {
            "size": "640x640",
            "location": f"{self.lat},{self.lon}",
            "heading": self.heading,
            "pitch":f"{self.pitch}",
            "fov":f"{self.fov}",
            "key": self.API_KEY
        }
        
        try:    
            response = requests.get(self.API_URL, params=params)
        except requests.ConnectionError as e:
            msg = f"Errore di connessione!!!"
            print(msg)
            self.iface.messageBar().pushCritical(u'PhotoDownloader', msg)
            return None
        except Exception as e:
            msg = f"Errore in dw_image: {e}"
            print(msg)
            self.iface.messageBar().pushCritical(u'PhotoDownloader', msg)
            return None
            
        if response.status_code == 200:
            
            image = QImage.fromData(response.content)
            image = image.copy(self.rectangle)
            image = image.scaled(self.width, self.height, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            print(image.width(), image.height())
        else:
            image = None
            print(f"Errore nel download della foto: {response.status_code}")
        
        return image
