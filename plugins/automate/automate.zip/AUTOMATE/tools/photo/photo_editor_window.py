# -*- coding: utf-8 -*-
"""
/***************************************************************************
 PhotoEditor
                                 A QGIS plugin
 PhotoEditor
                              -------------------
        begin                : 2023-02-27
        copyright            : (C) 2023 by Ing. Antonio Attadia
        email                : antonio.attadia@italgas.it
 ***************************************************************************/
 GUI to edit photo
"""

from qgis.PyQt import uic, QtCore, QtGui, QtWidgets
from qgis.PyQt.QtCore import Qt, pyqtSignal, QEvent, QPointF, QLineF, QRectF, QSize, QVariant
from qgis.PyQt.QtGui import (QKeyEvent, QFont, QPen, QColor, QPainter, QPainterPath, 
                             QImage, QPixmap, QIcon, QIntValidator)
from qgis.PyQt.QtWidgets import (QApplication, QMainWindow, QToolBar, QFileDialog, QColorDialog, QLineEdit, QTextEdit,
                             QGraphicsWidget, QGraphicsScene, QGraphicsRectItem,
                             QGraphicsLineItem, QGraphicsTextItem, QGraphicsPixmapItem,
                             QGraphicsSceneMouseEvent, QGraphicsBlurEffect,
                             QPushButton, QFontComboBox, QComboBox, QSlider, QLabel)

import sys
import os
from pathlib import Path
from .resources import *

class Polyline(QGraphicsWidget):
    def __init__(self, points:list[QPointF] =None):
        super().__init__()
        self.points:list[QPointF] = []
        self.closed = False
        self.setFlag(QGraphicsWidget.ItemIsMovable, True)
        self.setFlag(QGraphicsWidget.ItemIsSelectable, True)
        self.setFlag(QGraphicsWidget.ItemSendsGeometryChanges, True)
        if points:
            self.points = points
    
    def boundingRect(self):
        return self.shape().boundingRect()

    def shape(self):
        path = QPainterPath()
        if self.points:
            path.moveTo(self.points[0])
            for point in self.points[1:]:
                path.lineTo(point)
            
            path.closeSubpath()
            #if self.closed:
        return path

    def paint(self, painter, option, widget=None):
        if self.points:
            pen = QPen(QColor(255,0,0,255), 2.5, Qt.DotLine, Qt.RoundCap, Qt.RoundJoin)
            painter.setPen(pen)
            painter.drawPolyline(*self.points)
            
            painter.drawLine(self.points[-1], self.points[0])
            #if self.closed:
            
    def add_point(self, point:QPointF):
        if not self.closed:
            self.points.append(point)
            self.prepareGeometryChange()
        
    def close(self):
        if not self.closed and len(self.points) > 2:
            self.closed = True
            self.prepareGeometryChange()
        
    def move_point(self, point:QPointF):
        if not self.closed:
            self.points[-1] = point
            self.prepareGeometryChange()    

class Testo(QGraphicsTextItem):
    
    def __init__(self, parent=None):
        super(Testo, self).__init__(parent)
        # font e colore
        self.setPlainText("Inserisci qui il testo")
        self.adjustSize()
        self.editabile = True
        self.setFlag(QGraphicsWidget.ItemIsSelectable, True)
        self.setFlag(QGraphicsWidget.ItemIsMovable, True)
        #self.setTextWidth(self.boundingRect().width())
        border_width = 2
        padding = 0
        css = f"<div style='background-color: white; padding: {padding} px margin: {padding+border_width}px;'>{self.toPlainText()}</div>"
        self.setHtml(css)

    def boundingRect(self):
        return super().boundingRect().adjusted(-2, -2, 2, 2)
    
    def paint(self, painter, option, widget):
        painter.fillRect(self.boundingRect(), QColor(Qt.white))
        super().paint(painter, option, widget)
        # Isn't this strange to call update in paint event ?
        #self.update()
        pen = painter.pen()
        pen.setColor(Qt.black)
        pen.setWidth(2)
        painter.setPen(pen)
        painter.drawRect(self.boundingRect())
    
    # def mouseDoubleClickEvent(self, a0: QtGui.QMouseEvent) -> None:
    #     #self.setEnabled(not self.isEnabled())
    #     if self.editabile:
    #         self.setTextInteractionFlags(Qt.NoTextInteraction)
    #     else:
    #         self.setTextInteractionFlags(Qt.TextEditorInteraction)
    #     a0.accept()
        #return super().mouseDoubleClickEvent(a0)
        
    def set_interaction(self) -> bool:
        #self.textInteractionFlags()
        if self.textInteractionFlags() ==  Qt.TextEditorInteraction:
            self.setTextInteractionFlags(Qt.NoTextInteraction)
        else:
            self.setTextInteractionFlags(Qt.TextEditorInteraction)
            
        return True
      
    def keyReleaseEvent(self, a0: QtGui.QKeyEvent) -> None:
        self.adjustSize()
        return super().keyReleaseEvent(a0)
    
    def wheelEvent(self, event):
        # Increment the angle by a certain amount based on the wheel delta
        self.setTransformOriginPoint(self.boundingRect().center())
        delta = event.delta()
        angle = self.rotation() + delta/8
        self.setRotation(angle)
        # msg = f"delta {delta} angolo {self.rotation()}"
        # print(msg)
        
        # Accept the event to prevent it from being passed on to other widgets
        event.accept()
    # Apply the rotation to the widget
    def setRotation(self, angle: float) -> None:
        self.adjustSize()
        self.setTransformOriginPoint(self.boundingRect().center())
        # msg = f"angolo {self.rotation()}"
        # print(msg)
        return super().setRotation(angle)

class GR(QGraphicsPixmapItem):
    def __init__(self, parent=None):
        super(GR, self).__init__(parent)
        self._width = 600
        self._heigth = 600
        self._scale_min = 0.1
        self._scale_max = 2
        self.side = 4
        self._file_name = {
            0:":/gr/gr_L_80.png",
            1:":/gr/gr_L_60.png",
            2:":/gr/gr_L_40.png",
            3:":/gr/gr_L_20.png",
            4:":/gr/gr_F_00.png",
            5:":/gr/gr_R_20.png",
            6:":/gr/gr_R_40.png",
            7:":/gr/gr_R_60.png",
            8:":/gr/gr_R_80.png"
            }
        if self._file_name[self.side]:
            image = QImage(self._file_name[self.side])
            pixmap = QPixmap.fromImage(image)
            scaled_pixmap = pixmap.scaled(self._width, self._heigth,  Qt.KeepAspectRatio)
            self._width = scaled_pixmap.width()
            self._heigth = scaled_pixmap.height()
            self.setPixmap(scaled_pixmap)
        
    def wheelEvent(self, event):
        # Increment the angle by a certain amount based on the wheel delta
        #self.setTransformOriginPoint(self.boundingRect().center())
        delta = event.delta()
        zoom = self.scale() + delta/256
        if zoom > self._scale_max:
            self.setScale(self._scale_max)
        elif zoom < self._scale_min:
            self.setScale(self._scale_min)
        else:
            self.setScale(zoom)
        #print(f"{zoom}")
        # Accept the event to prevent it from being passed on to other widgets
        event.accept()
        
    # Apply the zoom to the widget
    def setScale(self, zoom: float) -> None:
        self.setTransformOriginPoint(self.boundingRect().center())
        return super().setScale(zoom)

    def changeSide(self, add:int = 1) -> None:
        self.side += add 
        
        if self.side > 7:
            self.side = 0
        elif self.side <0:
            self.side = 7
        if self._file_name[self.side]:
            image = QImage(self._file_name[self.side])
            pixmap = QPixmap.fromImage(image)
            scaled_pixmap = pixmap.scaled(self._width, self._heigth,  Qt.KeepAspectRatio)
            self.setPixmap(scaled_pixmap)
        return

class Scena(QGraphicsScene):
    def __init__(self, parent=None):
        super(Scena, self).__init__(parent)
        self.parent = parent
        self.Mode = ["select", "add_text", "add_line", "add_rect","add_gr", "add_polyline", "add_blur"]
        self.sceneMode = "select"
        self.setMode(self.sceneMode)
        #self.setSceneRect(0,0,600,600)
        #self.setSceneRect(0, 0, 1200, 1200)

        self.color = QColor(255,0,0, 255)
        self.pen_width = 3
        self.pen_style = Qt.SolidLine
        self.pen = QPen(self.color, self.pen_width, self.pen_style, Qt.RoundCap, Qt.RoundJoin)
        self.font = QFont("Arial", 15)

        # z value oggetti
        self.z_value = {"sfondo_item":0, "blur":5, "tubo":10, "rettangolo":20, "gr":30,  "patch":45, "text":50, "polyline":60} 
        
        # SFONDO
        self.sfondo = QPixmap(self.sceneRect().size().toSize())
        self.sfondo.fill(Qt.white)
        self.sfondo_item = QGraphicsPixmapItem(self.sfondo)
        self.sfondo_item.setZValue(self.z_value["sfondo_item"])
        self.addItem(self.sfondo_item)
        
        # TUBAZIONE
        self.p1 = QPointF(0,0)
        self.p2 = QPointF(0,0) 
        self.tubo = QGraphicsLineItem()
        self.tubo.setPen(self.pen)
        self.tubo.setZValue(self.z_value["tubo"])
        self.addItem(self.tubo)
        self.setParent(parent)
        self.installEventFilter(self)
        
        # POLILINEA
        self.polilinea = Polyline()
        self.polilinea.setZValue(self.z_value["polyline"])
        self.addItem(self.polilinea)
        
        self.scene_items = [self.sfondo_item, self.tubo, self.polilinea]
        for item in self.scene_items:
            item.setFlag(QGraphicsWidget.ItemIsSelectable, False)
            item.setFlag(QGraphicsWidget.ItemIsMovable, False)
    
    def setBackground(self, image:QImage) -> None:
        pixmap = QPixmap(image)
        self.setSceneRect(QRectF(pixmap.rect()))
        # self.addPixmap(pixmap)  # Aggiungi la nuova immagine
        self.sfondo_item.setPixmap(pixmap)
        # self.graphicsView.fitInView(self.scene.itemsBoundingRect(), Qt.KeepAspectRatio)
            
    def setMode(self, mode:str="select"):
        self.sceneMode = mode
        if self.sceneMode == "select":
            self.makeItemsControllable(True)
        else:
            self.makeItemsControllable(False)
        return

    def makeItemsControllable(self, areControllable:bool):
        for item in filter(lambda i: i not in self.scene_items, self.items()):
            item.setFlag(QGraphicsWidget.ItemIsSelectable, areControllable)
            item.setFlag(QGraphicsWidget.ItemIsMovable, areControllable)

    def makeItemsVisible(self, areVisible:bool):
        for item in self.items():
            if item != self.sfondo_item:
                item.setVisible(areVisible)
        
    def delete_items(self, items:list[QGraphicsWidget]):
        for item in self.selectedItems():
            if item not in self.scene_items:
                self.removeItem(item)
      
    def eventFilter(self, obj: QtCore.QObject, event: QGraphicsSceneMouseEvent) -> None:
        # msg = f"obj {obj} event {event}"
        # print(msg)
        # print(event.type())
        if isinstance(obj, Testo) and event.type() == QEvent.GraphicsSceneMouseDoubleClick:
            #print(f"Il mouse è stato premuto sul widget Testo! {event}")
            obj.set_interaction()
            event.accept()
        # cambio lato del gr
        if event.type() == QEvent.KeyPress:
            selectedObjs = self.selectedItems()
            keyEvent = QKeyEvent(event)
            if selectedObjs:
                selectedObj = selectedObjs[0]
                if isinstance(selectedObj, GR):
                    if keyEvent.key() == Qt.Key_Left:
                        #print(f"Tasto premuto left {event.key()}")
                        selectedObj.changeSide(-1)
                    elif keyEvent.key() == Qt.Key_Right:
                        #print(f"Tasto premuto rigth {event.key()}")
                        selectedObj.changeSide(1)
                if (keyEvent.key()  == Qt.Key_Delete) and (event.modifiers() & Qt.ControlModifier):
                    self.delete_items(selectedObjs)
                
            event.accept()

        # if type(obj) == type(GR() and event.type() == QEvent.KeyPress):
        return super().eventFilter(obj, event) 
  
    def mousePressEvent(self, event: QGraphicsSceneMouseEvent) -> None:
        # msg = f"mp {event.scenePos()}"
        # print(msg)
        
        if event.button() == Qt.LeftButton:
            if self.sceneMode == "add_line":
                self.p1 = event.scenePos()
            
            if self.sceneMode == "add_polyline":
                self.polilinea.add_point(event.scenePos())
                
            if self.sceneMode == "add_blur":
                self.add_blur(event.scenePos())
            
        if event.button() == Qt.RightButton:
            if self.sceneMode == "add_polyline":
                self.add_polyline(self.polilinea.points.copy())
                self.polilinea.points.clear()
                
        event.accept()
        return super().mousePressEvent(event)
    
    def mouseMoveEvent(self, event: QGraphicsSceneMouseEvent) -> None:
        # msg = f"mv {event.scenePos()}"
        # print(msg)
        
        if self.sceneMode == "add_line":
            if self.p1:
                self.p2 = event.scenePos()
                msg = f"mvif x {self.p1.x()} y {self.p1.y()}"
            linea = QLineF(self.p1, self.p2)
            self.pen = QPen(self.color, self.pen_width, self.pen_style, Qt.RoundCap, Qt.RoundJoin)
            self.tubo.setPen(self.pen)
            self.tubo.setLine(linea)
            self.tubo.setZValue(self.z_value["tubo"])
        
        if self.sceneMode == "add_polyline":
            if self.polilinea.points:
                self.polilinea.move_point(event.scenePos())
        
        event.accept()
        return super().mouseMoveEvent(event)
    
    def mouseReleaseEvent(self, event: QGraphicsSceneMouseEvent) -> None:
        # msg = f"rl {event.scenePos()}"
        # print(msg)
        
        if event.button() == Qt.LeftButton:
            if self.sceneMode == "add_line":
                    self.add_Line(self.tubo.line())
                    self.p1 = QPointF(0,0)
                    self.p2 = QPointF(0,0)
                    self.tubo.setLine(QLineF(self.p1, self.p2))
                
            if self.sceneMode == "add_rect":
                self.add_rect(event.scenePos())
                
            if self.sceneMode == "add_gr":
                self.add_gr(event.scenePos())
        
        event.accept()
        return super().mouseReleaseEvent(event)

    def mouseDoubleClickEvent(self, event: QGraphicsSceneMouseEvent) -> None:
        # msg = f"dc {event.scenePos()}"
        # print(msg)
        
        if self.sceneMode == "add_text":
            p = event.scenePos()
            self.add_text(p)            
            
        event.accept()
        return super().mouseDoubleClickEvent(event)
    
    def add_text(self, p:QPointF):
        testo = Testo()
        testo.setFont(self.font)
        testo.setDefaultTextColor(self.color)
        testo.setPos(p)
        testo.installEventFilter(self)
        testo.setZValue(self.z_value["text"])
        self.addItem(testo)
    
    def add_Line(self, line:QLineF):
        tubo = QGraphicsLineItem()
        tubo.setLine(line)
        #self.pen = QPen(self.color, self.pen_width, self.pen_style, Qt.RoundCap, Qt.RoundJoin)
        tubo.setPen(self.pen)
        tubo.setZValue(self.z_value["tubo"])
        self.addItem(tubo)
    
    def add_rect(self, p:QPointF):
        rettangolo = QGraphicsRectItem()
        #rettangolo.setPos(p)
        width = 150
        heigth = 120
        p1 = QPointF(p.x() - width/2, p.y() - heigth/2)
        p2 = QPointF(p.x() + width/2, p.y() + heigth/2)
        rettangolo.setRect(QRectF(p1, p2))
        rettangolo.setPen(self.pen)
        rettangolo.setZValue(self.z_value["rettangolo"])
        self.addItem(rettangolo)
    
    def add_gr(self, p:QPointF):
        gr = GR()
        width = gr._width
        heigth = gr._heigth
        p1 = QPointF(p.x() - width/2, p.y() - heigth/2)
        gr.setPos(p1)
        gr.setZValue(self.z_value["gr"])
        self.addItem(gr)

    def add_polyline(self, points:list[QPointF]):
        poly = Polyline(points)
        poly.close()
        poly.setZValue(self.z_value["polyline"])
        self.addItem(poly)
        self.add_patch([poly])    
        
    def add_patch(self, items:list[QGraphicsWidget]):
        self.makeItemsVisible(False)
        
        for item in filter(lambda i: i not in self.scene_items, items):           
            bounding_rect = item.boundingRect()
            pixmap = QPixmap(bounding_rect.size().toSize())
            
            painter = QPainter(pixmap)
            painter.translate(-bounding_rect.topLeft())
            painter.setRenderHint(QPainter.Antialiasing)
            self.render(painter, target=bounding_rect, source=bounding_rect)        
            painter.end()
            
            #print(f"bounding_rect top_left {bounding_rect.topLeft()}")
            #------------------------------------------------------------------------------
            # maschera di ritaglio
            #------------------------------------------------------------------------------
            # Crea un QPainterPath per la maschera di ritaglio a forma di stella
            
            pixmap_M = QPixmap(bounding_rect.size().toSize())
            pixmap_M.fill(Qt.transparent)
            
            painter2 = QPainter(pixmap_M)
            painter2.translate(-bounding_rect.topLeft())

            painter2.setRenderHint(QPainter.Antialiasing)
            painter2.setBrush(Qt.white)
            painter2.drawPath(item.shape())
            painter2.end()
            #pixmap_M.save("test.png")
            pixmap.setMask(pixmap_M.createHeuristicMask(True))
            #------------------------------------------------------------------------------
            
            patch = QGraphicsPixmapItem(pixmap)
            patch.setPos(bounding_rect.topLeft())
            
            patch.setZValue(self.z_value["patch"])
            self.addItem(patch)
            self.removeItem(item)

        self.makeItemsVisible(True)

    def add_blur(self, point:QPointF, l:int = 25, blur_amount: int = 10):
        
        self.makeItemsVisible(False)
        
        dim_l = int(l/2)
        aTopLeft = QPointF(point.x() - dim_l, point.y() - dim_l)
        bBottomRight = QPointF(point.x() + dim_l, point.y() + dim_l)
        
        bounding_rect = QRectF(aTopLeft, bBottomRight)
        pixmap = QPixmap(bounding_rect.size().toSize())
        
        painter = QPainter(pixmap)
        painter.translate(-bounding_rect.topLeft())
        painter.setRenderHint(QPainter.Antialiasing)
        self.render(painter, target=bounding_rect, source=bounding_rect)        
        painter.end()
                    
        # Crea un effetto di sfocatura
        blur = QGraphicsBlurEffect()
        blur.setBlurRadius(blur_amount)

        # Crea un oggetto QGraphicsPixmapItem e imposta l'effetto di sfocatura su di esso
        patch = QGraphicsPixmapItem(pixmap)
        patch.setGraphicsEffect(blur)

        
        patch.setPos(aTopLeft)
            
        patch.setZValue(self.z_value["blur"])
        self.addItem(patch)

        self.makeItemsVisible(True)      
    
    # cambio proprietà oggetti selezionati
    def change_properties(self, parametro:str, valore):
        for item in self.selectedItems():
            if parametro == "font":
                if isinstance(item, QGraphicsTextItem):
                    font = item.font()
                    font.setFamily(valore)
                    item.setFont(font)
            elif parametro == "dimensione":
                if isinstance(item, QGraphicsTextItem):
                    font = item.font()
                    font.setPointSize(valore)
                    item.setFont(font)
            elif parametro == "colore":
                if isinstance(item, QGraphicsTextItem):
                    item.setDefaultTextColor(valore)
                elif isinstance(item, QGraphicsLineItem) or isinstance(item, QGraphicsRectItem):
                    pen = item.pen()
                    pen.setColor(valore)
                    item.setPen(pen)
            elif parametro == "spessore":
                if isinstance(item, QGraphicsLineItem) or isinstance(item, QGraphicsRectItem):
                    pen = item.pen()
                    pen.setWidth(valore)
                    item.setPen(pen)
            elif parametro == "penstyle":
                if isinstance(item, QGraphicsLineItem) or isinstance(item, QGraphicsRectItem):
                    pen = item.pen()
                    pen.setStyle(valore)
                    item.setPen(pen)
                    
# This loads your .ui file so that PyQt can populate your plugin with the elements from Qt Designer
FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'PhotoEditorWindow.ui'))

#class UploaderWindow(QMainWindow, FORM_CLASS):
class PhotoEditorWindow(QMainWindow, FORM_CLASS):
    saved = pyqtSignal(QPixmap, dict)  # segnale emesso al click del save
    closed = pyqtSignal()  # segnale pdi chiusura
    reload = pyqtSignal(dict)
    
    def __init__(self, parent=None):
        """Constructor."""
        super(PhotoEditorWindow, self).__init__(parent)
        self.setupUi(self)
        self._attributes = {}
        self._field_allegato:str = 'ATTACHED'
        self._field_cod_tipo_foto:str = 'COD_TIPO_RIF_FOTO'
        self._field_num_prog:str = 'NUM_PROG'
        self._field_id_oggetto:str = 'ID_OGGETTO'
        self._field_titolo:str = 'TITOLO'
        self._field_descrizione:str = 'DESCRIZIONE'
        self.image_out:QPixmap = None        
        self.file_path_source:Path = None
        self.elenco_cod_tipo_foto:dict[int,str] = {1:"Progetto", 
                                    3:"Interferenza Infrastrutture", 
                                    12:"Impianto di riduzione", 
                                    # 5:"Pav_Strada sterrata", 
                                    # 6:"Pav_Terreno naturale", 
                                    # 7:"Pav_Strada bitumata", 
                                    # 8:"Pav_S1 Lastricati", 
                                    # 9:"Pav_S2 Cubetti di porfido", 
                                    # 10:"Pav_S3 Acciottolati e selciati", 
                                    # 11:"Pav_S4 Battuto di cemento", 
                                    # 13:"InterfServ_Rete Elettrica", 
                                    # 14:"InterfServ_Tubazione Fognatura", 
                                    # 15:"InterfServ_Tubazione Acqua", 
                                    # 16:"InterfServ_Cavi Telefonici", 
                                    # 17:"InterfServ_Tubazione Gas", 
                                    # 18:"InterfServ_Altro"
                                    }
        
        #self.setGeometry(100, 100, 1220, 640)
        #self.setFixedSize(1220, 640)
        self.initUI()
        self.adjustSize()
        
        return

    # crea l'interfaccia dell'editor di immagini
    def initUI(self):
        # oggetto Scena
        self.scene = Scena(self)
        # Imposto il graphicsview
        self.graphicsView: QtWidgets.QGraphicsView
        self.graphicsView.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.graphicsView.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.graphicsView.setScene(self.scene)
        
        # Crea i pulsanti della toolbar top
        self.bt_reload_image = QPushButton() # Carica immagine
        self.bt_reload_image.setToolTip("Ricarica immagine")
        self.bt_reload_image.clicked.connect(self.reload_image)
        self.bt_reload_image.setIcon(QIcon(':/gui/reload.svg'))
        
        self.bt_load_image = QPushButton() # Carica immagine
        self.bt_load_image.setToolTip("Carica immagine")
        self.bt_load_image.clicked.connect(self.load_image)
        self.bt_load_image.setIcon(QIcon(':/gui/load.svg'))
        
        self.bt_save_image = QPushButton() # salva
        self.bt_save_image.setToolTip("Salva")
        self.bt_save_image.clicked.connect(self.save_image)
        self.bt_save_image.setIcon(QIcon(':/gui/save.svg'))
        
        self.bt_get_font = QFontComboBox() # font
        self.bt_get_font.setToolTip("Font")
        self.bt_get_font.setCurrentFont(QFont("Arial"))
        self.bt_get_font.currentTextChanged.connect(self.get_font)
        
        self.bt_get_font_size = QComboBox() # Dimensione font
        self.bt_get_font_size .setToolTip("Dimensione font")
        dim = [str(i) for i in range(12,33,1)]
        self.bt_get_font_size.addItems(dim)
        self.bt_get_font_size.setCurrentIndex(15-12)
        self.bt_get_font_size.currentTextChanged.connect(self.get_font_size)
        
        self.bt_get_color = QPushButton() # colore
        self.bt_get_color.setToolTip("Colore")
        self.bt_get_color.clicked.connect(self.get_color)
        self.bt_get_color.setIcon(QIcon(':/gui/color.svg'))
        self.bt_get_color.setStyleSheet(f"background-color : rgb{self.scene.color.getRgb()}")
        
        self.bt_slider = QSlider() # spessore linea
        self.bt_slider.setToolTip("Spessore linea")
        self.bt_slider.setOrientation(Qt.Horizontal)
        self.bt_slider.setMinimum(1)
        self.bt_slider.setMaximum(16)
        self.bt_slider.setValue(3)
        self.bt_slider.setFixedWidth(100)
        self.bt_slider.valueChanged.connect(self.sliderChange)
        self.lb_slider = QLabel() # spessore linea label
        self.lb_slider.setToolTip("Spessore linea")
        self.lb_slider.setFixedSize(18,12)
        self.lb_slider.setText(str(self.bt_slider.value()))
        
        self.bt_penstyle = QComboBox() # stile linea
        self.bt_penstyle.setToolTip("Stile linea")
        self.bt_penstyle.addItems(["dashed", "dot-dash", "dot-dot-dash", "dotted", "solid"])
        self.bt_penstyle.setFont(QFont("", 1))
        self.bt_penstyle.setItemIcon(0, QIcon(":/gui/ls_dashed.png"))
        self.bt_penstyle.setItemIcon(1, QIcon(":/gui/ls_dot-dash.png"))
        self.bt_penstyle.setItemIcon(2, QIcon(":/gui/ls_dot-dot-dash.png"))
        self.bt_penstyle.setItemIcon(3, QIcon(":/gui/ls_dotted.png"))
        self.bt_penstyle.setItemIcon(4, QIcon(":/gui/ls_solid.png"))
        self.bt_penstyle.setIconSize(QSize(50, 10))
        self.bt_penstyle.setCurrentIndex(4)
        self.bt_penstyle.currentTextChanged.connect(self.change_penstyle)
        
        # Crea i pulsanti della toolbar left
        self.bt_select = QPushButton() # select
        self.bt_select.setToolTip("Seleziona")
        self.bt_select.clicked.connect(self.select)
        self.bt_select.setIcon(QIcon(':/gui/select.svg'))
        
        self.bt_delete = QPushButton() # delete
        self.bt_delete.setToolTip("Cancella")
        self.bt_delete.clicked.connect(self.delete)
        self.bt_delete.setIcon(QIcon(":/gui/trash.svg"))
        
        self.bt_add_text = QPushButton() # text
        self.bt_add_text.setToolTip("Testo")
        self.bt_add_text.clicked.connect(self.add_text)
        self.bt_add_text.setIcon(QIcon(':/gui/text.svg'))
        
        self.bt_add_line = QPushButton() # line
        self.bt_add_line.setToolTip("Tubazione")
        self.bt_add_line.clicked.connect(self.add_line)
        self.bt_add_line.setIcon(QIcon(':/gui/line.svg'))
        
        self.bt_add_rect = QPushButton() # rettangolo
        self.bt_add_rect.setToolTip("Rettangolo") 
        self.bt_add_rect.clicked.connect(self.add_rect)
        self.bt_add_rect.setIcon(QIcon(':/gui/rectangle.svg'))
        
        self.bt_add_gr = QPushButton() # impianto gr
        self.bt_add_gr.setToolTip("Impianto gr")
        self.bt_add_gr.clicked.connect(self.add_gr)
        self.bt_add_gr.setIcon(QIcon(':/gui/gr.svg'))
        
        # self.bt_add_polyline = QPushButton() # polyline
        # self.bt_add_polyline.setToolTip("Polilinea")
        # self.bt_add_polyline.clicked.connect(self.add_polyline)
        # self.bt_add_polyline.setIcon(QIcon(':/gui/polyline.svg'))
        
        self.bt_add_patch = QPushButton() # polyline
        self.bt_add_patch.setToolTip("Patch")
        self.bt_add_patch.clicked.connect(self.add_polyline)
        self.bt_add_patch.setIcon(QIcon(':/gui/patch.svg'))
        
        self.bt_add_blur = QPushButton() # polyline
        self.bt_add_blur.setToolTip("blur")
        self.bt_add_blur.clicked.connect(self.add_blur)
        self.bt_add_blur.setIcon(QIcon(':/gui/blur.svg'))
        
        # Crea i pulsanti della toolbar right
        self.label_tipo_foto = QLabel("Tipo foto")
        self.bt_tipo_foto = QComboBox()
        for key, value in self.elenco_cod_tipo_foto.items():
            self.bt_tipo_foto.addItem(value, key) 
        #self.bt_tipo_foto.currentIndexChanged.connect(self.get_bt_tipo_foto)
        # self.bt_tipo_foto.setCurrentIndex(self.bt_tipo_foto.findData(self.cod_tipo_foto))
        
        self.bt_num_prog = QLineEdit()
        self.bt_num_prog.setValidator(QIntValidator(0, 9999))
        self.bt_num_prog.setAlignment(Qt.AlignRight)
        # self.bt_num_prog.setText(str(self.num_prog))
        #self.txt_num_prog.textChanged.connect(self.get_num_prog)
        self.bt_id_oggetto = QLineEdit()
        # self.bt_id_oggetto.setText(self.id_oggetto)
        
        self.textEdit_titolo = QTextEdit()
        self.textEdit_titolo.setAcceptRichText(False)
        self.textEdit_titolo.setFixedHeight(50)
        # self.textEdit_titolo.setText(self.titolo)
        
        self.textEdit_descrizione = QTextEdit()
        self.textEdit_descrizione.setAcceptRichText(False)
        self.textEdit_descrizione.setFixedHeight(100)
        # self.textEdit_titolo.setText(self.titolo)
        
        # Aggiungo la toolbar top
        self.toolbar:QToolBar # = QToolBar("Principale")
        self.toolbar.addWidget(self.bt_reload_image)
        self.toolbar.addWidget(self.bt_load_image)
        self.toolbar.addWidget(self.bt_save_image)
        self.toolbar.addWidget(self.bt_get_font)
        self.toolbar.addWidget(self.bt_get_font_size)
        self.toolbar.addWidget(self.bt_get_color)
        self.toolbar.addWidget(self.bt_slider)
        self.toolbar.addWidget(self.lb_slider)
        self.toolbar.addWidget(self.bt_penstyle)
        #self.addToolBar(QtCore.Qt.TopToolBarArea, self.toolbar)
        
        # Aggiungo la toolbar left
        self.toolbar2:QToolBar # = QToolBar("Add")
        self.toolbar2.addWidget(self.bt_select)
        self.toolbar2.addWidget(self.bt_delete)
        self.toolbar2.addWidget(self.bt_add_text)
        self.toolbar2.addWidget(self.bt_add_line)
        self.toolbar2.addWidget(self.bt_add_rect)
        self.toolbar2.addWidget(self.bt_add_gr)
        #self.toolbar2.addWidget(self.bt_add_polyline)
        self.toolbar2.addWidget(self.bt_add_patch)
        self.toolbar2.addWidget(self.bt_add_blur)
        #self.addToolBar(QtCore.Qt.LeftToolBarArea, self.toolbar2)
        
        # Aggiungo la toolbar right
        self.toolbar3:QToolBar # = QToolBar("Altro")
        self.toolbar3.setContentsMargins(5,5,5,5)
        #self.toolbar3.setMovable(False)
        self.toolbar3.addWidget(self.label_tipo_foto)
        self.toolbar3.addWidget(self.bt_tipo_foto)
        self.toolbar3.addWidget(QLabel("Numero Progressivo"))
        self.toolbar3.addWidget(self.bt_num_prog)
        self.toolbar3.addWidget(QLabel("ID Oggetto"))
        self.toolbar3.addWidget(self.bt_id_oggetto)        
        self.toolbar3.addWidget(QLabel("Titolo"))
        self.toolbar3.addWidget(self.textEdit_titolo)
        self.toolbar3.addWidget(QLabel("Descrizione"))
        self.toolbar3.addWidget(self.textEdit_descrizione)
        #self.addToolBar(QtCore.Qt.RightToolBarArea, self.toolbar3)
            
    # Load an image
    def load_image(self):
        # Apri un dialogo per scegliere un file immagine
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Open Image File", "", "Image Files (*.jpeg)"
        )
        self.file_path_source = Path(file_path)
        self.set_image(self.file_path_source)
        
        return
    
    def reload_image(self):
        self.reload.emit(self._attributes)
        return
    
    def set_image_destination(self, file_path:Path):
        self.file_path_destination = file_path
        return
    
    def set_image(self, file_path:Path):
        # verifica che il file esiste
        if not file_path.is_file():
            return
        # Carica l'immagine e visualizzala nella QGraphicsView
        image = QImage(file_path.as_posix())
        if image.isNull():
            return
        
        self.scene.setBackground(image)
        
        return
    
    # imposta il background della scena
    def setBackground(self, image:QImage) -> None:
        self.scene.setBackground(image)

    def setData(self, attributes:dict) -> None:
        self._attributes = attributes               
        id_oggetto = attributes.get(self._field_id_oggetto, QVariant())
        if not isinstance(id_oggetto, QVariant):
            self.bt_id_oggetto.setText(id_oggetto)
            
        titolo = attributes.get(self._field_titolo, QVariant())
        if not isinstance(titolo, QVariant):
            self.textEdit_titolo.setText(titolo)
            
        descrizione = attributes.get(self._field_descrizione, QVariant())
        if not isinstance(descrizione, QVariant):
            self.textEdit_descrizione.setText(descrizione)
        
        self.setWindowTitle(attributes.get(self._field_allegato, ''))
        self.bt_tipo_foto.setCurrentIndex(self.bt_tipo_foto.findData(attributes.get(self._field_cod_tipo_foto, 1)))
        self.bt_num_prog.setText(str(attributes.get(self._field_num_prog, 1)))
                
        return
    
    # salva l'immagine del punto e il fotoinserimento        
    def save_image(self):
        # deseleziona elementi
        self.scene.clearSelection()
        
        # salva l'immagine con tutti gli oggetti
        image_mod_pixmap = QPixmap(self.scene.sceneRect().size().toSize())
        painter = QPainter(image_mod_pixmap)
        painter.setRenderHint(QPainter.Antialiasing)
        self.scene.render(painter)
        painter.end()
        self.image_out = image_mod_pixmap
        
        # salvare i dati ulteriori da memorizzare sul layer
        self._attributes[self._field_cod_tipo_foto] = self.bt_tipo_foto.currentData()
        self._attributes[self._field_num_prog] = int(self.bt_num_prog.text())
        self._attributes[self._field_id_oggetto] = self.bt_id_oggetto.text()
        self._attributes[self._field_titolo] = self.textEdit_titolo.toPlainText()
        self._attributes[self._field_descrizione] = self.textEdit_descrizione.toPlainText()

        
        # Emetti il segnale con il valore desiderato
        self.saved.emit(self.image_out, self._attributes)
        
        return

    
    # evento di chiusura
    def closeEvent(self, event):
        self.closed.emit()  # Emetti il segnale quando la finestra viene chiusa
        super().closeEvent(event)
        return
 
    def get_font(self):
        font_family = self.bt_get_font.currentFont().family()
        self.scene.font.setFamily(font_family)
        
        self.scene.change_properties("font", font_family)
        
        return font_family
        
    def get_font_size(self):
        font_size = int(self.bt_get_font_size.currentText())
        self.scene.font.setPointSize(font_size)
        
        self.scene.change_properties("dimensione", font_size)
        
        return font_size

    def get_color(self):
        sel_color = QColorDialog.getColor()
        #print(sel_color)
        if sel_color:
            self.scene.color = sel_color
            self.scene.pen.setColor(sel_color)
            self.bt_get_color.setStyleSheet(f"background-color : rgb{self.scene.color.getRgb()}")

            self.scene.change_properties("colore", sel_color)

        return
    
    def sliderChange(self):
        self.bt_slider.repaint()
        self.lb_slider.setText(str(self.bt_slider.value()))
        self.scene.pen_width = self.bt_slider.value()
        
        self.scene.change_properties("spessore", self.bt_slider.value())
        
        return
    
    def change_penstyle(self):
        penstyle = {
            "dashed":Qt.DashLine,
            "dot-dash":Qt.DashDotLine,
            "dot-dot-dash":Qt.DashDotDotLine,
            "dotted":Qt.DotLine,
            "solid":Qt.SolidLine
        }
        value = penstyle[self.bt_penstyle.currentText()]
        self.scene.pen_style = value
        
        self.scene.change_properties("penstyle", value)
        
        return
    
    def select(self):
        self.scene.setMode("select")
        return
    
    def delete(self):
        self.scene.delete_items(self.scene.selectedItems())
        return
    
    def add_text(self):
        self.get_font()
        self.scene.setMode("add_text")
        return

    def add_line(self):
        self.scene.setMode("add_line")
        return
    
    def add_rect(self):
        self.scene.setMode("add_rect")
        return
    
    def add_gr(self):
        self.scene.setMode("add_gr")
        return
    
    def add_polyline(self):
        self.scene.setMode("add_polyline")
        return
    
    def add_blur(self):
        self.scene.setMode("add_blur")
        return

    
if __name__ == '__main__':      
    app = QApplication(sys.argv)
    window = PhotoEditorWindow()
    window.show()
    sys.exit(app.exec_())
