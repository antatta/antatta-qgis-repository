# -*- coding: utf-8 -*-
"""
Zip module for AUTOMATE plugin v2.0
Contains project zip functionality.
"""
