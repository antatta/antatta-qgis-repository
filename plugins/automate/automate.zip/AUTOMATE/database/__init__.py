# -*- coding: utf-8 -*-
"""
Database module for AUTOMATE plugin v2.0
Contains database connection and data models.
"""
from .database_connect import DatabaseConnect
__all__ = ["DatabaseConnect"]