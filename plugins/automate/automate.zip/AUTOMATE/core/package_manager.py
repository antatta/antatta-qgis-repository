# -*- coding: utf-8 -*-
"""
Package Manager semplificato per il plugin AUTOMATE
"""
import sys
import subprocess
import importlib
import importlib.util
import shutil
from pathlib import Path
from typing import Dict, List, Tuple, Optional


class PackageManager:
    """Gestisce pacchetti Python esterni per il plugin AUTOMATE."""
    
    def __init__(self, plugin_dir: str):
        """Inizializza PackageManager"""
        self.plugin_dir = Path(plugin_dir)
        self.vendor_dir = self.plugin_dir / "vendor"
        self.requirements_file = self.plugin_dir / "requirements.txt"
        
        # Cache per i mapping package → module già risolti
        self._module_name_cache = {}
        
        # Aggiungi vendor al Python path se esiste
        if self.vendor_dir.exists() and str(self.vendor_dir) not in sys.path:
            sys.path.insert(0, str(self.vendor_dir))
    
    def _discover_module_name_via_metadata(self, package_name: str) -> Optional[str]:
        """
        Usa importlib.metadata per scoprire il nome del modulo dal package name.
        Funziona solo se il package è già installato.
        """
        try:
            # Python 3.8+ ha importlib.metadata nel standard library
            try:
                from importlib.metadata import distribution, PackageNotFoundError
            except ImportError:
                # Fallback per Python < 3.8
                try:
                    from importlib_metadata import distribution, PackageNotFoundError
                except ImportError:
                    return None
            
            dist = distribution(package_name)
            
            # Prima prova a leggere top_level.txt (più affidabile)
            try:
                top_level = dist.read_text('top_level.txt')
                if top_level:
                    modules = [line.strip() for line in top_level.split('\n') if line.strip()]
                    if modules:
                        # Filtra moduli che non sono metadati (più rigoroso)
                        valid_modules = []
                        for m in modules:
                            # Salta tutto ciò che sembra metadati o file di sistema
                            if not any(pattern in m.lower() for pattern in [
                                '.egg-info', '.dist-info', '__pycache__', 
                                '.pth', '.pyc', '.pyo', 'egg_info'
                            ]):
                                # Salta anche moduli che sono chiaramente nomi di package con estensioni
                                if '.' not in m or not m.split('.')[-1] in ['egg', 'info', 'dist']:
                                    valid_modules.append(m)
                        
                        if valid_modules:
                            # Restituisci solo se è effettivamente un modulo importabile
                            candidate = valid_modules[0]
                            print(f"🔍 Metadata top_level candidato: {candidate} per {package_name}")
                            return candidate
            except Exception as e:
                print(f"⚠️ Errore lettura top_level.txt per {package_name}: {e}")
                pass
            
            # Fallback: analizza i files se top_level.txt non disponibile
            if dist.files:
                top_level_modules = set()
                for file in dist.files:
                    file_str = str(file)
                    
                    # Salta file di metadati
                    if any(skip in file_str for skip in ['.egg-info', '.dist-info', '__pycache__']):
                        continue
                        
                    if file.suffix == '.py':
                        # Modulo singolo nella root
                        if '/' not in file_str:
                            module_name = file.stem
                            if not module_name.startswith('_') and module_name != 'setup':
                                top_level_modules.add(module_name)
                    elif '/' in file_str and not file.name.startswith('_'):
                        # Package directory
                        parts = file_str.split('/')
                        if len(parts) > 0:
                            potential_module = parts[0]
                            if not any(skip in potential_module for skip in ['.egg-info', '.dist-info', '__pycache__']):
                                top_level_modules.add(potential_module)
                
                # Restituisce il modulo principale (il più probabile)
                if top_level_modules:
                    # Preferisci moduli che assomigliano al package name
                    package_clean = package_name.lower().replace('-', '').replace('_', '')
                    for module in sorted(top_level_modules):
                        module_clean = module.lower().replace('-', '').replace('_', '')
                        if package_clean in module_clean or module_clean in package_clean:
                            return module
                    # Altrimenti prendi il primo alfabeticamente
                    return sorted(top_level_modules)[0]
                
        except (PackageNotFoundError, Exception) as e:
            # Debug: log l'errore ma non bloccare
            print(f"⚠️ Metadata discovery fallito per '{package_name}': {e}")
        
        return None
    
    def _guess_module_name_by_convention(self, package_name: str) -> List[str]:
        """
        Genera una lista di possibili nomi di modulo basata su convenzioni comuni.
        """
        candidates = []
        
        # 1. Nome del package così com'è
        candidates.append(package_name)
        
        # 2. Lowercase
        if package_name != package_name.lower():
            candidates.append(package_name.lower())
        
        # 3. Sostituzioni comuni
        common_replacements = {
            'pyyaml': 'yaml',
            'pillow': 'PIL',
            'python-dateutil': 'dateutil',
            'beautifulsoup4': 'bs4',
            'msgpack-python': 'msgpack',
            'pyopenssl': 'OpenSSL',
            'pycryptodome': 'Crypto',
            'pytz': 'pytz',
            'six': 'six',
            'setuptools': 'pkg_resources',  # Uno dei moduli di setuptools
        }
        
        if package_name.lower() in common_replacements:
            candidates.append(common_replacements[package_name.lower()])
        
        # 4. Rimozioni/sostituzioni di prefissi/suffissi comuni
        transformations = [
            lambda name: name.replace('python-', ''),      # python-requests → requests
            lambda name: name.replace('py-', ''),          # py-yaml → yaml  
            lambda name: name.replace('-python', ''),      # requests-python → requests
            lambda name: name.replace('-', '_'),           # some-package → some_package
            lambda name: name.replace('_', '-'),           # some_package → some-package
            lambda name: name.replace('-', ''),            # some-package → somepackage
            lambda name: name.replace('_', ''),            # some_package → somepackage
        ]
        
        for transform in transformations:
            transformed = transform(package_name.lower())
            if transformed != package_name.lower() and transformed not in candidates:
                candidates.append(transformed)
        
        # 5. Se contiene numeri, prova senza numeri (beautifulsoup4 → beautifulsoup)
        import re
        no_numbers = re.sub(r'\d+', '', package_name)
        if no_numbers != package_name and no_numbers not in candidates:
            candidates.append(no_numbers)
        
        # Rimuovi duplicati mantenendo l'ordine
        unique_candidates = []
        for candidate in candidates:
            if candidate and candidate not in unique_candidates:
                unique_candidates.append(candidate)
        
        return unique_candidates
    
    def get_module_name(self, package_name: str) -> str:
        """
        Determina il nome del modulo da importare per un dato package name.
        Usa rilevamento automatico + fallback intelligente.
        """
        # Controlla cache
        if package_name in self._module_name_cache:
            return self._module_name_cache[package_name]
        
        print(f"🔍 Cercando modulo per package '{package_name}'...")
        
        # STRATEGIA 1 (PRIORITARIA): Test diretto dei candidati (più affidabile per QGIS)
        candidates = self._guess_module_name_by_convention(package_name)
        print(f"🧪 Candidati da testare: {candidates}")
        
        # Testa ogni candidato provando l'import diretto PRIMA (più robusto per QGIS)
        for candidate in candidates:
            try:
                # Metodo 1: Prova import diretto (più affidabile in QGIS)
                import importlib
                module = importlib.import_module(candidate)
                if module is not None:
                    print(f"✅ Trovato tramite import diretto: {package_name} → {candidate}")
                    self._module_name_cache[package_name] = candidate
                    return candidate
            except (ImportError, ModuleNotFoundError):
                print(f"🔄 Import diretto fallito per '{candidate}'")
                continue
            except Exception as e:
                # Log errori imprevisti ma continua
                print(f"⚠️ Errore test import '{candidate}' per '{package_name}': {e}")
                continue
            
            try:
                # Metodo 2: Prova find_spec come fallback
                spec = importlib.util.find_spec(candidate)
                if spec is not None:
                    print(f"✅ Trovato tramite spec: {package_name} → {candidate}")
                    self._module_name_cache[package_name] = candidate
                    return candidate
            except (ImportError, ModuleNotFoundError, ValueError, AttributeError):
                pass
            except Exception as e:
                # Log errori imprevisti ma continua
                print(f"⚠️ Errore test spec '{candidate}' per '{package_name}': {e}")
        
        # STRATEGIA 2 (SOLO COME ULTIMA RISORSA): metadata discovery (problematico in QGIS)
        print(f"🔍 Nessun candidato diretto funziona, provo metadata discovery...")
        discovered_name = self._discover_module_name_via_metadata(package_name)
        if discovered_name and not discovered_name.endswith('.egg-info') and not discovered_name.endswith('.dist-info'):
            # Verifica che il modulo scoperto funzioni effettivamente
            try:
                import importlib
                importlib.import_module(discovered_name)
                print(f"✅ Rilevato e verificato tramite metadata: {package_name} → {discovered_name}")
                self._module_name_cache[package_name] = discovered_name
                return discovered_name
            except:
                print(f"⚠️ Modulo '{discovered_name}' scoperto ma non importabile")
        elif discovered_name:
            print(f"⚠️ Metadata discovery ha restituito '{discovered_name}' ma sembra metadati, ignorato")
        
        # STRATEGIA 3 (FALLBACK FINALE): usa il primo candidato
        fallback_name = candidates[0] if candidates else package_name
        print(f"⚠️ Nessun mapping trovato per '{package_name}', uso fallback: {fallback_name}")
        self._module_name_cache[package_name] = fallback_name
        return fallback_name
    
    def get_required_packages(self) -> Dict[str, str]:
        """Legge i pacchetti richiesti da requirements.txt"""
        packages = {}
        
        if not self.requirements_file.exists():
            return packages
        
        try:
            with open(self.requirements_file, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith('#'):
                        if '==' in line:
                            package, version = line.split('==', 1)
                            packages[package.strip()] = version.strip()
                        else:
                            packages[line.strip()] = 'latest'
        except Exception as e:
            print(f"❌ Errore lettura requirements.txt: {e}")
        
        return packages
    
    def check_package_availability(self, package_name: str, required_version: Optional[str] = None, force_reload: bool = False) -> Tuple[bool, str, str]:
        """Verifica se un pacchetto è disponibile nel sistema QGIS"""
        # Ottieni il nome del modulo da importare (gestisce mapping come pyyaml → yaml)
        module_name = self.get_module_name(package_name)
        
        try:
            # Se force_reload, rimuovi il modulo dalla cache prima del test
            if force_reload and module_name in sys.modules:
                try:
                    del sys.modules[module_name]
                    # Rimuovi anche i sub-moduli
                    modules_to_remove = [m for m in sys.modules.keys() if m.startswith(module_name + '.')]
                    for mod in modules_to_remove:
                        del sys.modules[mod]
                    importlib.invalidate_caches()
                except:
                    pass  # Ignora errori di pulizia cache
            
            module = importlib.import_module(module_name)
            
            if hasattr(module, '__version__'):
                installed_version = module.__version__
                
                if required_version and required_version != 'latest':
                    if installed_version == required_version:
                        return True, installed_version, "EXACT"
                    else:
                        return True, installed_version, "DIFFERENT"
                else:
                    return True, installed_version, "OK"
            else:
                return True, "unknown", "OK"
                
        except ImportError:
            return False, "not_found", "MISSING"
        except Exception as e:
            return False, "error", f"ERROR: {str(e)}"
            return False, "error", f"ERROR: {str(e)}"

    def debug_pkg_resources_cache(self) -> None:
        """Debug: mostra lo stato della cache pkg_resources"""
        try:
            import pkg_resources
            
            print("🔍 DEBUG: Stato pkg_resources.working_set")
            try:
                total_distributions = len(list(pkg_resources.working_set))
                print(f"   Totale distribuzioni: {total_distributions}")
            except TypeError:
                print("   Totale distribuzioni: N/A (working_set non iterabile)")
            
            # Lista pacchetti dalla vendor directory
            vendor_packages = []
            installed_vendor_packages = self.get_installed_vendor_packages()
            
            if self.vendor_dir.exists() and installed_vendor_packages:
                print(f"   Pacchetti installati in vendor ({len(installed_vendor_packages)}):")
                for pkg_name in installed_vendor_packages:
                    print(f"     📦 {pkg_name}")
                    
                # Trova distribuzioni pkg_resources per pacchetti vendor
                for dist in pkg_resources.working_set:
                    if (str(self.vendor_dir) in dist.location or 
                        dist.project_name.lower() in [p.lower() for p in installed_vendor_packages]):
                        vendor_packages.append(f"{dist.project_name}=={dist.version}")
                
                if vendor_packages:
                    print(f"   Distribuzioni pkg_resources per vendor ({len(vendor_packages)}):")
                    for pkg in vendor_packages:
                        print(f"     🔸 {pkg}")
                else:
                    print("   ⚠️ Pacchetti vendor non trovati in pkg_resources.working_set")
            else:
                print("   ℹ️ Nessun pacchetto installato nella vendor directory")
            
            # Mostra anche requirements
            required = self.get_required_packages()
            if required:
                print(f"   Pacchetti richiesti da requirements.txt ({len(required)}):")
                for name, version in required.items():
                    # Verifica se presente in working_set
                    found_version = None
                    is_in_vendor = name.lower() in [p.lower() for p in installed_vendor_packages]
                    
                    for dist in pkg_resources.working_set:
                        if dist.project_name.lower() == name.lower():
                            found_version = dist.version
                            break
                    
                    status = "✅" if found_version else "❌"
                    vendor_flag = " [VENDOR]" if is_in_vendor else ""
                    if found_version:
                        print(f"     {status} {name}=={found_version} (richiesto: {version}){vendor_flag}")
                    else:
                        print(f"     {status} {name} (richiesto: {version}) - NON TROVATO{vendor_flag}")
            else:
                print("   ℹ️ Nessun requirement trovato")
                
        except ImportError:
            print("🔍 DEBUG: pkg_resources non disponibile in questo ambiente")
        except Exception as e:
            print(f"🔍 DEBUG: Errore durante analisi pkg_resources: {e}")
            import traceback
            print(f"   Traceback: {traceback.format_exc()}")

    def get_installed_vendor_packages(self) -> List[str]:
        """Restituisce la lista dei pacchetti effettivamente installati in vendor"""
        installed_packages = []
        
        if not self.vendor_dir.exists():
            return installed_packages
        
        try:
            # Cerca directory .dist-info e .egg-info per identificare pacchetti installati
            for item in self.vendor_dir.iterdir():
                if item.is_dir() and (item.name.endswith('.dist-info') or item.name.endswith('.egg-info')):
                    # Estrae il nome del pacchetto dalla directory
                    package_name = item.name.split('-')[0].lower()
                    if package_name not in installed_packages:
                        installed_packages.append(package_name)
                elif item.is_dir() and not item.name.startswith('.') and not item.name.startswith('_'):
                    # Controlla se è una directory di pacchetto (contiene __init__.py o moduli .py)
                    if any(child.name == '__init__.py' for child in item.iterdir() if child.is_file()):
                        installed_packages.append(item.name.lower())
                    elif any(child.suffix == '.py' for child in item.iterdir() if child.is_file()):
                        installed_packages.append(item.name.lower())
        except Exception as e:
            print(f"⚠️ Errore lettura vendor directory: {e}")
        
        return installed_packages

    def clear_import_cache(self, packages: Optional[List[str]] = None) -> None:
        """Pulisce la cache di importazione Python per forzare reload"""
        try:
            if packages is None:
                # Se non specificati, usa solo i pacchetti installati in vendor
                packages = self.get_installed_vendor_packages()
            
            if not packages:
                print("ℹ️ Nessun pacchetto da pulire dalla cache")
                return
                
            print(f"🧹 Pulizia cache importazione per {len(packages)} pacchetti installati in vendor...")
            print(f"   📦 Pacchetti: {', '.join(packages)}")
            
            # 1. Rimuovi dai sys.modules
            removed_modules = []
            for package_name in packages:
                modules_to_remove = []
                
                # Cerca tutti i moduli che iniziano con il nome del pacchetto
                for module_name in list(sys.modules.keys()):  # Copia la lista per evitare modifiche durante iterazione
                    if (module_name == package_name or 
                        module_name.startswith(package_name + '.') or
                        module_name.startswith(package_name + '_')):
                        modules_to_remove.append(module_name)
                
                # Rimuovi i moduli trovati
                for module_name in modules_to_remove:
                    try:
                        del sys.modules[module_name]
                        removed_modules.append(module_name)
                        print(f"   🗑️ Rimosso dalla cache sys.modules: {module_name}")
                    except KeyError:
                        pass  # Modulo già rimosso
            
            # 2. Pulisci cache pkg_resources
            removed_distributions = []  # Inizializzazione qui
            try:
                import pkg_resources
                
                # Backup working_set originale - usa len() solo se disponibile
                try:
                    original_ws_size = len(list(pkg_resources.working_set))
                except TypeError:
                    original_ws_size = "N/A"
                
                # Rimuovi i pacchetti disinstallati dal working_set
                distributions_to_remove = []
                
                for dist in list(pkg_resources.working_set):  # Copia per iterazione sicura
                    if dist.project_name.lower() in [p.lower() for p in packages]:
                        distributions_to_remove.append(dist)
                        removed_distributions.append(f"{dist.project_name}=={dist.version}")
                
                # Rimuovi le distribuzioni
                for dist in distributions_to_remove:
                    try:
                        # Metodo più sicuro per rimozione
                        if hasattr(pkg_resources.working_set, 'entries') and dist.location in pkg_resources.working_set.entries:
                            pkg_resources.working_set.entries.remove(dist.location)
                            print(f"   🗑️ Rimosso da pkg_resources: {dist.project_name}=={dist.version}")
                    except (ValueError, AttributeError, TypeError) as remove_error:
                        # Prova metodi alternativi per rimuovere
                        try:
                            if hasattr(pkg_resources.working_set, 'by_key') and dist.key in pkg_resources.working_set.by_key:
                                del pkg_resources.working_set.by_key[dist.key]
                                print(f"   🗑️ Rimosso da pkg_resources.by_key: {dist.project_name}")
                        except (KeyError, AttributeError, TypeError):
                            pass
                
                # Forza ricostruzione del working_set se necessario
                if removed_distributions:
                    try:
                        # Pulisci cache interne
                        if hasattr(pkg_resources.working_set, '_cache'):
                            pkg_resources.working_set._cache.clear()
                        print(f"   🔄 Cache pkg_resources pulita")
                    except (AttributeError, TypeError) as rebuild_error:
                        print(f"   ⚠️ Pulizia cache pkg_resources parziale: {rebuild_error}")
                
                # Calcola nuova dimensione working_set
                try:
                    new_ws_size = len(list(pkg_resources.working_set))
                except TypeError:
                    new_ws_size = "N/A"
                    
                print(f"   📊 pkg_resources: {original_ws_size} → {new_ws_size} distribuzioni")
                
            except ImportError:
                print("   ℹ️ pkg_resources non disponibile")
            except Exception as pkg_error:
                print(f"   ⚠️ Errore pulizia pkg_resources: {pkg_error}")
            
            # 3. Forza invalidazione cache importlib
            try:
                importlib.invalidate_caches()
                print("   🔄 Cache importlib invalidata")
            except:
                pass  # Non tutte le versioni supportano questo metodo
            
            # Riepilogo
            total_removed = len(removed_modules) + len(removed_distributions)
            if total_removed > 0:
                print(f"✅ Cache pulita: {len(removed_modules)} moduli + {len(removed_distributions)} distribuzioni")
                
                # Log anche nella console QGIS se disponibile
                try:
                    from qgis.core import QgsMessageLog, Qgis
                    QgsMessageLog.logMessage(f"AUTOMATE: Cache pulita - {total_removed} elementi rimossi per pacchetti vendor", 'Python', Qgis.Info)
                except ImportError:
                    pass
            else:
                print("ℹ️ Nessun elemento da rimuovere dalla cache")
                
        except Exception as e:
            print(f"❌ Errore pulizia cache: {e}")
            import traceback
            print(f"   Traceback: {traceback.format_exc()}")

    def analyze_dependencies(self, force_reload: bool = False) -> Tuple[Dict[str, Dict], List[str]]:
        """Analizza tutte le dipendenze e identifica quelle mancanti"""
        required_packages = self.get_required_packages()
        report_data = {}
        missing_packages = []
        
        for package_name, required_version in required_packages.items():
            available, installed_version, status = self.check_package_availability(package_name, required_version, force_reload)
            
            report_data[package_name] = {
                'required': required_version,
                'installed': installed_version,
                'status': status,
                'available': available
            }
            
            if not available:
                missing_packages.append(package_name)
        
        return report_data, missing_packages
    
    def print_dependency_report(self, report_data: Dict[str, Dict]) -> None:
        """Stampa un report tabellare delle dipendenze nella console QGIS"""
        if not report_data:
            print("📋 Nessun pacchetto definito in requirements.txt")
            return
        
        print("\n" + "="*80)
        print("🔍 AUTOMATE Dependencies Report")
        print("="*80)
        
        # Header tabella
        print("┌─────────────────┬─────────────┬─────────────┬─────────────────┐")
        print("│ PACCHETTO       │ RICHIESTO   │ INSTALLATO  │ STATUS          │")
        print("├─────────────────┼─────────────┼─────────────┼─────────────────┤")
        
        # Righe dati
        for package_name, info in report_data.items():
            pkg_name = package_name[:15].ljust(15)
            required = info['required'][:11].ljust(11)
            installed = info['installed'][:11].ljust(11)
            
            if info['status'] == 'EXACT':
                status = "✅ VERSIONE OK  "
            elif info['status'] == 'DIFFERENT':
                status = "⚠️  VERS DIVERSA "
            elif info['status'] == 'OK':
                status = "✅ DISPONIBILE  "
            elif info['status'] == 'MISSING':
                status = "❌ MANCANTE     "
                installed = "N/A        "
            else:
                status = "⚠️  ERRORE      "
            
            print(f"│ {pkg_name} │ {required} │ {installed} │ {status} │")
        
        # Footer tabella
        print("└─────────────────┴─────────────┴─────────────┴─────────────────┘")
        
        # Statistiche
        total_packages = len(report_data)
        missing_count = sum(1 for info in report_data.values() if info['status'] == 'MISSING')
        available_count = total_packages - missing_count
        
        print(f"\n📊 RIEPILOGO:")
        print(f"   📦 Totale pacchetti: {total_packages}")
        print(f"   ✅ Disponibili: {available_count}")
        print(f"   ❌ Mancanti: {missing_count}")
        
        if missing_count > 0:
            print(f"   📁 Installazione in: {self.vendor_dir}")
        
        print("="*80 + "\n")

    def ask_user_for_installation(self, missing_packages: List[str]) -> bool:
        """Chiede all'utente se installare i pacchetti mancanti"""
        try:
            # Import QGIS per il dialog
            from qgis.PyQt.QtWidgets import QMessageBox
            
            missing_list = "\n".join([f"• {pkg}" for pkg in missing_packages])
            
            reply = QMessageBox.question(
                None,
                'AUTOMATE - Dipendenze Mancanti',
                f"""Trovati {len(missing_packages)} pacchetti mancanti:

{missing_list}

Vuoi installarli nella cartella vendor/?
(Installazione isolata, nessun conflitto con QGIS)""",
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.Yes
            )
            
            return reply == QMessageBox.Yes
            
        except ImportError:
            # Fallback console se QGIS non disponibile
            print(f"\n❓ Installare {len(missing_packages)} pacchetti mancanti? [s/n]: ", end="")
            try:
                response = input().lower().strip()
                return response in ['s', 'si', 'sì', 'y', 'yes']
            except KeyboardInterrupt:
                print("\n⚠️ Operazione annullata dall'utente")
                return False
            except Exception:
                return False

    def create_vendor_directory(self) -> bool:
        """Crea la directory vendor se non esiste"""
        try:
            self.vendor_dir.mkdir(parents=True, exist_ok=True)
            
            # Crea __init__.py per rendere vendor un package Python
            init_file = self.vendor_dir / "__init__.py"
            if not init_file.exists():
                init_file.write_text("# Vendor packages for AUTOMATE plugin\n")
            
            return True
        except Exception as e:
            print(f"❌ Errore creazione directory vendor: {e}")
            return False

    def install_package(self, package_name: str, version: str = 'latest') -> bool:
        """Installa un singolo pacchetto nella directory vendor usando pip come libreria Python"""
        try:
            if not self.create_vendor_directory():
                return False
            
            # Prepara specificazione pacchetto
            package_spec = package_name if version == 'latest' else f"{package_name}=={version}"
            
            print(f"🔽 Installando {package_spec}...")
            print(f"📁 Target directory: {self.vendor_dir}")
            
            # Log anche nella console QGIS se disponibile
            try:
                from qgis.core import QgsMessageLog, Qgis
                QgsMessageLog.logMessage(f"AUTOMATE: Installando {package_spec} in vendor/", 'Python', Qgis.Info)
            except ImportError:
                pass  # Non in ambiente QGIS
            
            # Usa pip direttamente come libreria Python (senza subprocess)
            try:
                # Sopprimi warning deprecation di pip/packaging
                import warnings
                with warnings.catch_warnings():
                    warnings.filterwarnings("ignore", category=DeprecationWarning, module="pip")
                    warnings.filterwarnings("ignore", message=".*LegacyVersion.*", category=DeprecationWarning)
                    
                    # Metodo più moderno usando runpy per evitare warning
                    try:
                        import runpy
                        import sys
                        
                        # Argomenti per python -m pip install
                        pip_module_args = [
                            'pip', 'install',
                            '--target', str(self.vendor_dir),
                            '--no-deps',
                            '--upgrade',
                            '--quiet',  # Meno output per evitare spam
                            package_spec
                        ]
                        
                        print("📦 Usando python -m pip (metodo raccomandato)...")
                        
                        # Salva sys.argv originale
                        original_argv = sys.argv.copy()
                        try:
                            # Imposta sys.argv per simulare chiamata da command line  
                            sys.argv = pip_module_args
                            
                            # Esegui pip come modulo
                            runpy.run_module('pip', run_name='__main__', alter_sys=False)
                            result_code = 0  # Se arriviamo qui, è andato bene
                            
                        except SystemExit as e:
                            # pip usa SystemExit per restituire codici di errore
                            result_code = e.code if e.code is not None else 0
                        finally:
                            # Ripristina sys.argv originale
                            sys.argv = original_argv
                            
                    except (ImportError, Exception) as runpy_error:
                        print(f"⚠️ Fallback a pip._internal: {runpy_error}")
                        # Fallback al metodo precedente
                        try:
                            from pip._internal.main import main as pip_main
                            print("📦 Usando pip._internal.main (fallback)...")
                        except ImportError:
                            # Fallback a pip.main per versioni vecchie
                            import pip
                            pip_main = pip.main
                            print("📦 Usando pip.main (legacy)...")
                        
                        # Argomenti per pip install (metodo classico)
                        pip_args = [
                            'install',
                            '--target', str(self.vendor_dir),
                            '--no-deps',
                            '--upgrade',
                            '--quiet',  # Meno output per evitare spam
                            package_spec
                        ]
                        
                        # Esegui pip direttamente nell'interprete QGIS
                        result_code = pip_main(pip_args)
                
                if result_code == 0:
                    print(f"✅ {package_name} installato con successo via pip interno!")
                    try:
                        from qgis.core import QgsMessageLog, Qgis
                        QgsMessageLog.logMessage(f"AUTOMATE: ✅ {package_name} installato con successo!", 'Python', Qgis.Success)
                    except ImportError:
                        pass
                    return True
                else:
                    print(f"⚠️ pip interno ha restituito codice {result_code}, provo subprocess...")
                    
            except (ImportError, AttributeError, Exception) as pip_error:
                print(f"📦 pip interno non utilizzabile ({pip_error}), uso subprocess.check_call...")
                
            # Fallback: usa subprocess ma con approccio diverso
            import subprocess
            import os
            try:
                # Determina l'eseguibile Python corretto per QGIS cross-platform
                python_executable = sys.executable
                
                # Fix per macOS: QGIS.app bundle structure
                if 'QGIS.app' in python_executable and python_executable.endswith('/QGIS'):
                    python_executable = python_executable.replace('/MacOS/QGIS', '/MacOS/bin/python3')
                
                # Fix per Windows: qgis-bin.exe o qgis.exe invece di python.exe
                elif os.name == 'nt' and ('qgis' in python_executable.lower()):
                    # Windows: cerca python.exe nella stessa directory o in bin/
                    qgis_dir = os.path.dirname(python_executable)
                    possible_pythons = [
                        os.path.join(qgis_dir, 'python.exe'),                    # Stesso dir
                        os.path.join(qgis_dir, 'bin', 'python.exe'),            # Subdir bin/  
                        os.path.join(os.path.dirname(qgis_dir), 'bin', 'python.exe'),  # Parent/bin/
                        os.path.join(qgis_dir, '..', 'Python39', 'python.exe'), # QGIS standalone
                        'python'  # Fallback sistema
                    ]
                    
                    for py_path in possible_pythons:
                        if os.path.isfile(py_path):
                            python_executable = py_path
                            print(f"🐍 Windows: usando Python {python_executable}")
                            break
                
                # Linux: di solito sys.executable è già corretto, ma verifichiamo
                elif os.name == 'posix' and 'qgis' in python_executable.lower():
                    # Se punta a un binario QGIS, cerca python3 nella stessa dir
                    qgis_dir = os.path.dirname(python_executable)
                    possible_pythons = [
                        os.path.join(qgis_dir, 'python3'),
                        '/usr/bin/python3',
                        'python3'  # Fallback sistema
                    ]
                    
                    for py_path in possible_pythons:
                        if os.path.isfile(py_path) or py_path in ['python3']:  # python3 può essere in PATH
                            python_executable = py_path
                            print(f"🐧 Linux: usando Python {python_executable}")
                            break
                
                # Lista argomenti (non stringa) per evitare parsing problemi
                cmd_args = [
                    python_executable, '-m', 'pip', 'install',
                    '--target', str(self.vendor_dir),
                    '--no-deps',
                    '--upgrade',
                    '--quiet',
                    package_spec
                ]
                
                print(f"🔧 Eseguendo subprocess.check_call con args: {cmd_args}")
                
                # Usa check_call invece di run per semplicità
                subprocess.check_call(
                    cmd_args,
                    stdout=subprocess.DEVNULL,  # Nasconde output per evitare spam
                    stderr=subprocess.PIPE,
                    timeout=300
                )
                
                print(f"✅ {package_name} installato con successo via subprocess.check_call()")
                try:
                    from qgis.core import QgsMessageLog, Qgis
                    QgsMessageLog.logMessage(f"AUTOMATE: ✅ {package_name} installato via subprocess!", 'Python', Qgis.Success)
                except ImportError:
                    pass
                return True
                
            except subprocess.CalledProcessError as e:
                print(f"❌ Errore subprocess per {package_name}:")
                if e.stderr:
                    error_msg = e.stderr.decode('utf-8')
                    print(f"   STDERR: {error_msg}")
                    try:
                        from qgis.core import QgsMessageLog, Qgis
                        QgsMessageLog.logMessage(f"AUTOMATE: ❌ Errore {package_name}: {error_msg}", 'Python', Qgis.Critical)
                    except ImportError:
                        pass
                return False
                
            except subprocess.TimeoutExpired:
                print(f"⏰ Timeout installazione {package_name}")
                try:
                    from qgis.core import QgsMessageLog, Qgis
                    QgsMessageLog.logMessage(f"AUTOMATE: ⏰ Timeout installazione {package_name}", 'Python', Qgis.Warning)
                except ImportError:
                    pass
                return False
                
        except Exception as e:
            print(f"❌ Errore generale installazione {package_name}: {e}")
            import traceback
            print(f"   Traceback: {traceback.format_exc()}")
            try:
                from qgis.core import QgsMessageLog, Qgis
                QgsMessageLog.logMessage(f"AUTOMATE: ❌ Errore generale {package_name}: {e}", 'Python', Qgis.Critical)
            except ImportError:
                pass
            return False

    def uninstall_package(self, package_name: str) -> bool:
        """Disinstalla un pacchetto dalla directory vendor"""
        try:
            if not self.vendor_dir.exists():
                print(f"📁 Directory vendor non trovata: {self.vendor_dir}")
                return True  # Niente da disinstallare
            
            print(f"🗑️ Disinstallando {package_name} da vendor/...")
            
            # Log nella console QGIS se disponibile
            try:
                from qgis.core import QgsMessageLog, Qgis
                QgsMessageLog.logMessage(f"AUTOMATE: Disinstallando {package_name} da vendor/", 'Python', Qgis.Info)
            except ImportError:
                pass
            
            # Cerca le directory/file del pacchetto
            import shutil
            import glob
            
            removed_items = []
            
            # Pattern comuni per i pacchetti Python
            patterns_to_remove = [
                f"{package_name}",              # directory principale
                f"{package_name}.py",           # file singolo
                f"{package_name}-*.dist-info",  # metadata pip
                f"{package_name}-*.egg-info",   # metadata setuptools
                f"{package_name.replace('-', '_')}", # nome normalizzato
                f"{package_name.replace('_', '-')}", # nome con trattini
            ]
            
            # Aggiungi pattern per pacchetti con underscore/trattini
            normalized_name = package_name.replace('-', '_')
            if normalized_name != package_name:
                patterns_to_remove.extend([
                    f"{normalized_name}",
                    f"{normalized_name}.py",
                    f"{normalized_name}-*.dist-info",
                    f"{normalized_name}-*.egg-info",
                ])
            
            # Cerca e rimuovi tutti i file/directory corrispondenti
            for pattern in patterns_to_remove:
                matches = glob.glob(str(self.vendor_dir / pattern))
                for match in matches:
                    match_path = Path(match)
                    
                    try:
                        if match_path.is_file():
                            match_path.unlink()
                            removed_items.append(f"file: {match_path.name}")
                            print(f"   🗑️ Rimosso file: {match_path.name}")
                        elif match_path.is_dir():
                            shutil.rmtree(match_path)
                            removed_items.append(f"dir: {match_path.name}")
                            print(f"   🗑️ Rimossa directory: {match_path.name}")
                    except OSError as e:
                        print(f"   ⚠️ Impossibile rimuovere {match_path.name}: {e}")
            
            # Risultato
            if removed_items:
                print(f"✅ {package_name} disinstallato con successo!")
                print(f"   Rimossi: {', '.join(removed_items)}")
                
                # Pulisci cache importazione per questo pacchetto
                self.clear_import_cache([package_name])
                
                try:
                    from qgis.core import QgsMessageLog, Qgis
                    QgsMessageLog.logMessage(f"AUTOMATE: ✅ {package_name} disinstallato! Rimossi: {len(removed_items)} elementi", 'Python', Qgis.Success)
                except ImportError:
                    pass
                return True
            else:
                print(f"⚠️ Nessun file trovato per {package_name} in vendor/")
                
                try:
                    from qgis.core import QgsMessageLog, Qgis
                    QgsMessageLog.logMessage(f"AUTOMATE: ⚠️ {package_name} non trovato in vendor/", 'Python', Qgis.Warning)
                except ImportError:
                    pass
                return False
                
        except Exception as e:
            print(f"❌ Errore disinstallazione {package_name}: {e}")
            import traceback
            print(f"   Traceback: {traceback.format_exc()}")
            
            try:
                from qgis.core import QgsMessageLog, Qgis
                QgsMessageLog.logMessage(f"AUTOMATE: ❌ Errore disinstallazione {package_name}: {e}", 'Python', Qgis.Critical)
            except ImportError:
                pass
            return False

    def uninstall_all_packages(self) -> Tuple[bool, List[str]]:
        """Disinstalla tutti i pacchetti dalla directory vendor"""
        try:
            if not self.vendor_dir.exists():
                print("📁 Directory vendor non trovata")
                return True, []
            
            print("🗑️ Disinstallazione completa della directory vendor...")
            
            # Log nella console QGIS
            try:
                from qgis.core import QgsMessageLog, Qgis
                QgsMessageLog.logMessage("AUTOMATE: Disinstallazione completa directory vendor/", 'Python', Qgis.Info)
            except ImportError:
                pass
            
            # Lista contenuti prima della rimozione
            contents = []
            if self.vendor_dir.exists():
                for item in self.vendor_dir.iterdir():
                    if item.name != "__init__.py":  # Mantieni __init__.py
                        contents.append(item.name)
            
            # Rimuovi tutto tranne __init__.py
            import shutil
            
            removed_count = 0
            failed_items = []
            
            for item in self.vendor_dir.iterdir():
                if item.name == "__init__.py":
                    continue  # Mantieni __init__.py
                    
                try:
                    if item.is_file():
                        item.unlink()
                        removed_count += 1
                        print(f"   🗑️ Rimosso file: {item.name}")
                    elif item.is_dir():
                        shutil.rmtree(item)
                        removed_count += 1
                        print(f"   🗑️ Rimossa directory: {item.name}")
                except OSError as e:
                    failed_items.append(item.name)
                    print(f"   ⚠️ Impossibile rimuovere {item.name}: {e}")
            
            # Risultato finale
            success = len(failed_items) == 0
            
            # Pulisci cache importazione per tutti i pacchetti noti
            if removed_count > 0:
                print("🧹 Pulizia cache importazione dopo disinstallazione completa...")
                self.clear_import_cache()  # Pulisce tutti i pacchetti da requirements.txt
            
            if success:
                print(f"✅ Directory vendor pulita! Rimossi {removed_count} elementi")
                
                try:
                    from qgis.core import QgsMessageLog, Qgis
                    QgsMessageLog.logMessage(f"AUTOMATE: ✅ Vendor pulita! {removed_count} elementi rimossi", 'Python', Qgis.Success)
                except ImportError:
                    pass
            else:
                print(f"⚠️ Pulizia parziale: {len(failed_items)} errori, {removed_count} successi")
                
                try:
                    from qgis.core import QgsMessageLog, Qgis
                    QgsMessageLog.logMessage(f"AUTOMATE: ⚠️ Pulizia parziale: {len(failed_items)} errori", 'Python', Qgis.Warning)
                except ImportError:
                    pass
            
            return success, failed_items
            
        except Exception as e:
            print(f"❌ Errore pulizia directory vendor: {e}")
            import traceback
            print(f"   Traceback: {traceback.format_exc()}")
            
            try:
                from qgis.core import QgsMessageLog, Qgis
                QgsMessageLog.logMessage(f"AUTOMATE: ❌ Errore pulizia vendor: {e}", 'Python', Qgis.Critical)
            except ImportError:
                pass
            return False, []

    def list_installed_packages(self) -> List[str]:
        """Elenca i pacchetti installati in vendor/"""
        try:
            if not self.vendor_dir.exists():
                return []
            
            installed = []
            
            # Cerca directory e file Python
            for item in self.vendor_dir.iterdir():
                if item.name == "__init__.py":
                    continue
                    
                # Directory di pacchetti
                if item.is_dir() and not item.name.startswith('.'):
                    # Escludi metadata directories
                    if not (item.name.endswith('.dist-info') or item.name.endswith('.egg-info')):
                        installed.append(item.name)
                        
                # File Python singoli
                elif item.is_file() and item.name.endswith('.py'):
                    package_name = item.name[:-3]  # Rimuovi .py
                    if package_name not in installed:
                        installed.append(package_name)
            
            return sorted(installed)
            
        except Exception as e:
            print(f"❌ Errore elenco pacchetti installati: {e}")
            return []

    def show_vendor_status(self) -> None:
        """Mostra lo status della directory vendor"""
        print("\n" + "="*60)
        print("📁 AUTOMATE Vendor Directory Status")
        print("="*60)
        
        if not self.vendor_dir.exists():
            print("❌ Directory vendor non esistente")
            print(f"   Path: {self.vendor_dir}")
            print("="*60 + "\n")
            return
        
        print(f"📂 Path: {self.vendor_dir}")
        
        # Dimensione directory
        try:
            import os
            total_size = 0
            file_count = 0
            
            for dirpath, dirnames, filenames in os.walk(self.vendor_dir):
                for filename in filenames:
                    filepath = os.path.join(dirpath, filename)
                    try:
                        total_size += os.path.getsize(filepath)
                        file_count += 1
                    except OSError:
                        pass
            
            # Converti in MB
            size_mb = total_size / (1024 * 1024)
            print(f"📊 Dimensione: {size_mb:.2f} MB ({file_count} files)")
            
        except Exception:
            print("📊 Dimensione: (non calcolabile)")
        
        # Pacchetti installati
        installed = self.list_installed_packages()
        print(f"📦 Pacchetti installati: {len(installed)}")
        
        if installed:
            for package in installed:
                print(f"   • {package}")
        else:
            print("   (nessun pacchetto)")
        
        print("="*60 + "\n")

    def install_missing_packages(self, missing_packages: List[str], required_packages: Dict[str, str]) -> Tuple[bool, List[str]]:
        """Installa tutti i pacchetti mancanti"""
        if not missing_packages:
            return True, []
        
        print(f"\n🚀 Inizio installazione di {len(missing_packages)} pacchetti...")
        
        failed_packages = []
        success_count = 0
        
        for package_name in missing_packages:
            version = required_packages.get(package_name, 'latest')
            
            if self.install_package(package_name, version):
                success_count += 1
            else:
                failed_packages.append(package_name)
        
        # Aggiorna Python path
        if str(self.vendor_dir) not in sys.path:
            sys.path.insert(0, str(self.vendor_dir))
        
        # Report finale
        all_success = len(failed_packages) == 0
        
        print(f"\n📊 RISULTATO INSTALLAZIONE:")
        print(f"   ✅ Successo: {success_count}/{len(missing_packages)}")
        if failed_packages:
            print(f"   ❌ Errori: {', '.join(failed_packages)}")
        
        return all_success, failed_packages

    def check_dependencies_interactive(self, qgis_interface=None) -> bool:
        """Metodo principale: controlla dipendenze e gestisce installazione interattiva"""
        print("\n🔍 AUTOMATE - Controllo Dipendenze")
        
        # 1. Analizza dipendenze
        report_data, missing_packages = self.analyze_dependencies()
        
        # 2. Mostra report tabellare
        self.print_dependency_report(report_data)
        
        # 3. Se tutto OK, termina qui
        if not missing_packages:
            print("🎉 Tutte le dipendenze sono soddisfatte!")
            
            # Messaggio QGIS se disponibile
            if qgis_interface:
                try:
                    from qgis.core import Qgis
                    qgis_interface.messageBar().pushMessage(
                        'AUTOMATE Dependencies',
                        '✅ Tutte le dipendenze OK!',
                        level=Qgis.Success,
                        duration=3
                    )
                except:
                    pass
            
            return True
        
        # 4. Chiedi all'utente se installare
        if not self.ask_user_for_installation(missing_packages):
            print("⏭️ Installazione rimandata dall'utente")
            
            # Messaggio QGIS se disponibile
            if qgis_interface:
                try:
                    from qgis.core import Qgis
                    qgis_interface.messageBar().pushMessage(
                        'AUTOMATE Dependencies',
                        f'⏭️ {len(missing_packages)} dipendenze rimandate',
                        level=Qgis.Info,
                        duration=4
                    )
                except:
                    pass
            
            return False
        
        # 5. Installa pacchetti mancanti
        required_packages = self.get_required_packages()
        success, failed_packages = self.install_missing_packages(missing_packages, required_packages)
        
        # 6. Messaggio finale
        if success:
            print(f"🎉 Installazione completata! {len(missing_packages)} pacchetti installati in vendor/")
            
            if qgis_interface:
                try:
                    from qgis.core import Qgis
                    qgis_interface.messageBar().pushMessage(
                        'AUTOMATE Dependencies',
                        f'✅ {len(missing_packages)} dipendenze installate!',
                        level=Qgis.Success,
                        duration=5
                    )
                except:
                    pass
        else:
            print(f"⚠️ Installazione parziale: {len(failed_packages)} errori")
            
            if qgis_interface:
                try:
                    from qgis.core import Qgis
                    qgis_interface.messageBar().pushMessage(
                        'AUTOMATE Dependencies',
                        f'⚠️ Problemi installazione: {len(failed_packages)} errori',
                        level=Qgis.Warning,
                        duration=8
                    )
                except:
                    pass
        
        return success

    def uninstall_dependencies_interactive(self, qgis_interface=None) -> bool:
        """Disinstalla pacchetti in modo interattivo"""
        print("\n🗑️ AUTOMATE - Disinstallazione Dipendenze")
        
        # Mostra status corrente
        self.show_vendor_status()
        
        # Lista pacchetti installati
        installed_packages = self.list_installed_packages()
        
        if not installed_packages:
            print("📭 Nessun pacchetto da disinstallare")
            
            if qgis_interface:
                try:
                    from qgis.core import Qgis
                    qgis_interface.messageBar().pushMessage(
                        'AUTOMATE Dependencies',
                        '📭 Directory vendor già vuota',
                        level=Qgis.Info,
                        duration=3
                    )
                except:
                    pass
            
            return True
        
        print(f"\n🗑️ Trovati {len(installed_packages)} pacchetti da disinstallare:")
        for pkg in installed_packages:
            print(f"   • {pkg}")
        
        # Chiedi conferma all'utente
        if not self.ask_user_for_uninstall(installed_packages):
            print("⏭️ Disinstallazione annullata dall'utente")
            
            if qgis_interface:
                try:
                    from qgis.core import Qgis
                    qgis_interface.messageBar().pushMessage(
                        'AUTOMATE Dependencies',
                        '⏭️ Disinstallazione annullata',
                        level=Qgis.Info,
                        duration=3
                    )
                except:
                    pass
            
            return False
        
        # Procedi con disinstallazione completa
        print(f"\n🚀 Inizio disinstallazione di {len(installed_packages)} pacchetti...")
        
        success, failed = self.uninstall_all_packages()
        
        # Messaggio finale
        if success:
            print(f"🎉 Disinstallazione completata! Directory vendor pulita.")
            
            if qgis_interface:
                try:
                    from qgis.core import Qgis
                    qgis_interface.messageBar().pushMessage(
                        'AUTOMATE Dependencies',
                        f'✅ {len(installed_packages)} pacchetti disinstallati!',
                        level=Qgis.Success,
                        duration=5
                    )
                except:
                    pass
        else:
            print(f"⚠️ Disinstallazione parziale: {len(failed)} errori")
            
            if qgis_interface:
                try:
                    from qgis.core import Qgis
                    qgis_interface.messageBar().pushMessage(
                        'AUTOMATE Dependencies',
                        f'⚠️ Disinstallazione parziale: {len(failed)} errori',
                        level=Qgis.Warning,
                        duration=8
                    )
                except:
                    pass
        
        return success

    def ask_user_for_uninstall(self, packages: List[str]) -> bool:
        """Chiede all'utente conferma per disinstallare i pacchetti"""
        try:
            # Import QGIS per il dialog
            from qgis.PyQt.QtWidgets import QMessageBox
            
            package_list = "\n".join([f"• {pkg}" for pkg in packages])
            
            reply = QMessageBox.question(
                None,
                'AUTOMATE - Disinstalla Dipendenze',
                f"""Confermi la disinstallazione di {len(packages)} pacchetti?

{package_list}

⚠️ ATTENZIONE: Questa operazione rimuoverà tutti i pacchetti
dalla directory vendor/ e non può essere annullata.

I pacchetti potranno essere reinstallati in seguito.""",
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.No  # Default a No per sicurezza
            )
            
            return reply == QMessageBox.Yes
            
        except ImportError:
            # Fallback console se QGIS non disponibile
            print(f"\n⚠️ ATTENZIONE: Disinstallare {len(packages)} pacchetti? [s/N]: ", end="")
            try:
                response = input().lower().strip()
                return response in ['s', 'si', 'sì', 'y', 'yes']
            except KeyboardInterrupt:
                print("\n⚠️ Operazione annullata dall'utente")
                return False
            except Exception:
                return False


# Funzioni di utilità aggiornate
def ensure_dependencies(plugin_dir: str, qgis_interface=None) -> bool:
    """Funzione di convenienza per verificare dipendenze"""
    try:
        manager = PackageManager(plugin_dir)
        print("\n🔍 AUTOMATE - Controllo Dipendenze")
        
        # 1. Analizza dipendenze
        report_data, missing_packages = manager.analyze_dependencies()
        
        # 2. Mostra report tabellare
        manager.print_dependency_report(report_data)
        
        # 3. Se tutto OK, termina qui
        if not missing_packages:
            print("🎉 Tutte le dipendenze sono soddisfatte!")
            
            # Messaggio QGIS se disponibile
            if qgis_interface:
                try:
                    from qgis.core import Qgis
                    qgis_interface.messageBar().pushMessage(
                        'AUTOMATE Dependencies',
                        '✅ Tutte le dipendenze OK!',
                        level=Qgis.Success,
                        duration=3
                    )
                except:
                    pass
            
            return True
        
        # 4. Chiedi all'utente se installare
        
        # 5. Installa pacchetti mancanti
        required_packages = manager.get_required_packages()
        success, failed_packages = manager.install_missing_packages(missing_packages, required_packages)
        
        # 6. Messaggio finale
        if success:
            print(f"🎉 Installazione completata! {len(missing_packages)} pacchetti installati in vendor/")
            
            if qgis_interface:
                try:
                    from qgis.core import Qgis
                    qgis_interface.messageBar().pushMessage(
                        'AUTOMATE Dependencies',
                        f'✅ {len(missing_packages)} dipendenze installate!',
                        level=Qgis.Success,
                        duration=5
                    )
                except:
                    pass
        else:
            print(f"⚠️ Installazione parziale: {len(failed_packages)} errori")
            
            if qgis_interface:
                try:
                    from qgis.core import Qgis
                    qgis_interface.messageBar().pushMessage(
                        'AUTOMATE Dependencies',
                        f'⚠️ Problemi installazione: {len(failed_packages)} errori',
                        level=Qgis.Warning,
                        duration=8
                    )
                except:
                    pass
        
        return success
    except Exception as e:
        print(f"❌ Errore controllo dipendenze: {e}")
        return False

def clean_dependencies(plugin_dir: Path, qgis_interface=None) -> bool:
    """Funzione di convenienza per disinstallare dipendenze"""
    try:
        manager = PackageManager(plugin_dir)
        return manager.uninstall_dependencies_interactive(qgis_interface)
    except Exception as e:
        print(f"❌ Errore pulizia dipendenze: {e}")
        return False

def show_dependencies_status(plugin_dir: Path) -> None:
    """Funzione di convenienza per mostrare status dipendenze"""
    try:
        manager = PackageManager(plugin_dir)
        manager.show_vendor_status()
    except Exception as e:
        print(f"❌ Errore status dipendenze: {e}")
