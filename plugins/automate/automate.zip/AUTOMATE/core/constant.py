import logging
from pathlib import Path
from typing import Dict, Any, Iterator, Union

# Configura il logger
logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)


class LazyConfigLoader:
    """
    Caricatore lazy per la configurazione YAML.
    Importa yaml e carica il file solo quando necessario.
    """
    
    def __init__(self):
        self._config: Dict[str, Any] = {}
        self._loaded = False
        self._config_path = Path(__file__).parent / 'constant.yaml'
    
    def _load_config(self) -> None:
        """Carica la configurazione dal file YAML"""
        if self._loaded:
            return
        
        try:
            # Import yaml solo quando necessario
            import yaml
            
            if not self._config_path.exists():
                logger.error(f"File di configurazione non trovato: {self._config_path}")
                self._config = {}
                self._loaded = True
                return
            
            with open(self._config_path, 'r', encoding='utf-8') as file:
                data = yaml.safe_load(file)
                if data and isinstance(data, dict) and 'config' in data:
                    config_data = data['config']
                    if isinstance(config_data, dict):
                        self._config = config_data
                    else:
                        logger.error("La sezione 'config' del file YAML non è un dizionario")
                        self._config = {}
                else:
                    logger.error("Il file YAML non contiene una sezione 'config' valida")
                    self._config = {}
            
            logger.info("Configurazione caricata con successo.")
            
        except ImportError:
            logger.error("PyYAML non disponibile. Utilizzando configurazione vuota.")
            self._config = {}
        except Exception as e:
            logger.error(f"Errore durante il caricamento del file di configurazione: {e}")
            self._config = {}
        
        self._loaded = True
    
    def __getitem__(self, key: str) -> Any:
        """Implementa l'accesso dict-like con lazy loading"""
        self._load_config()
        return self._config[key]
    
    def __setitem__(self, key: str, value: Any) -> None:
        """Implementa l'assegnazione dict-like"""
        self._load_config()
        self._config[key] = value
    
    def __contains__(self, key: str) -> bool:
        """Implementa l'operatore 'in'"""
        self._load_config()
        return key in self._config
    
    def __getattr__(self, name: str) -> Any:
        """Implementa l'accesso tramite dot notation (es: CONST.max_area_sovrapposizione_ripristino_accettabile)"""
        self._load_config()
        if name in self._config:
            return self._config[name]
        raise AttributeError(f"LazyConfigLoader has no attribute '{name}'")

    def __iter__(self) -> Iterator[str]:
        """Implementa l'iterazione"""
        self._load_config()
        return iter(self._config)
    
    def get(self, key: str, default: Any = None) -> Any:
        """Implementa il metodo dict.get()"""
        self._load_config()
        return self._config.get(key, default)
    
    def keys(self):
        """Restituisce le chiavi della configurazione"""
        self._load_config()
        return self._config.keys()
    
    def values(self):
        """Restituisce i valori della configurazione"""
        self._load_config()
        return self._config.values()
    
    def items(self):
        """Restituisce gli items della configurazione"""
        self._load_config()
        return self._config.items()
    
    def is_loaded(self) -> bool:
        """Restituisce True se la configurazione è già stata caricata"""
        return self._loaded


# Istanza globale con lazy loading
CONST = LazyConfigLoader()