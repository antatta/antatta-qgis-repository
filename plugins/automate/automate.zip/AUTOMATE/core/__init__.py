# -*- coding: utf-8 -*-
"""
Core module for AUTOMATE plugin v2.0
Contains core functionality, configuration, and utilities.
"""

from .constant import CONST

__all__ = ['CONST']