from pathlib import Path

# Se non funziona, utilizza pathlib (caso non pacchetto)
PACKAGE_DIR = Path(__file__).parent
DB_DIR_PATH = PACKAGE_DIR.parent / 'resources' / 'db'

# Percorso assoluto al file .gpkg
DB_MASTER_PATH = DB_DIR_PATH / 'db.gpkg'
DB_DM_PATH = DB_DIR_PATH / 'regolamenti_DM-Fracasso.gpkg'

