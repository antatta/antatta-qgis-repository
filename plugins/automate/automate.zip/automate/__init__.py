# -*- coding: utf-8 -*-
"""
/***************************************************************************
 Automate
                                 A QGIS plugin
 The AUTOMATE plug-in
                             -------------------
        begin                : 2024-09-23
        copyright            : (C) 2024 by Ing. Antonio Attadia
        email                : info.antatta@gmail.com
        git sha              : $Format:%H$
 ***************************************************************************/
 This script initializes the plugin, making it known to QGIS.
"""
import sys
from pathlib import Path

script_dir = Path(__file__).parent
sys.path.insert(0, str(script_dir))


# noinspection PyPep8Naming
def classFactory(iface):  # pylint: disable=invalid-name
    """Load Teng class from file Teng.

    :param iface: A QGIS interface instance.
    :type iface: QgsInterface
    """
    #
    from .automate import Automate
    return Automate(iface)
