# -*- coding: utf-8 -*-
"""
/***************************************************************************
 Automate
                                 A QGIS plugin
 The AUTOMATE plug-in
                              -------------------
        begin                : 2024-09-23
        git sha              : $Format:%H$
        copyright            : (C) 2024 by Ing. Antonio Attadia
        email                : antonio.attadia@italgas.it
 ***************************************************************************/
 QGIS toolbar
"""
import os
import configparser
from pathlib import Path
from numpy import require
from qgis.PyQt.QtCore import QSettings, QTranslator, QCoreApplication
from qgis.PyQt.QtGui import QIcon, QColor
from qgis.PyQt.QtWidgets import QAction, QToolBar, QMessageBox
from qgis.core import QgsProject, Qgis
from qgis.utils import iface

# Initialize Qt resources from file resources.py
from .resources import *

from .tools.rg_cod.code_manager import CodeManager
from .tools.rg_cod.switch import Switch
from .tools.controller.controller_dialog import ControllerDialog
from .tools.attachments.attach_manager import AttachManager
from .tools.attachments.trash_manager import TrashManager
from .tools.zip.zip_manager import ZipManager
from .tools.settings.settings_dialog import SettingsDialog
from .tools.photo.photo_manager import PhotoManager

from .core.package_manager import PackageManager
from .core.package_manager import ensure_dependencies, clean_dependencies, show_dependencies_status
from .core.utils import require_project, check_project_exists


class Automate:
    """QGIS Plugin Implementation."""

    def __init__(self, iface):
        """Constructor.

        :param iface: An interface instance that will be passed to this class
            which provides the hook by which you can manipulate the QGIS
            application at run time.
        :type iface: QgsInterface
        """
        # Save reference to the QGIS interface
        self.iface = iface
        # initialize plugin directory
        self.plugin_dir = os.path.dirname(__file__)
        # initialize locale
        locale = QSettings().value('locale/userLocale')[0:2]
        locale_path = os.path.join(
            self.plugin_dir,
            'i18n',
            'Teng_{}.qm'.format(locale))

        if os.path.exists(locale_path):
            self.translator = QTranslator()
            self.translator.load(locale_path)
            QCoreApplication.installTranslator(self.translator)

        # Declare instance attributes
        self.actions = []
        self.toolbar:QToolBar = self.iface.addToolBar('AUTOMATE')
        self.toolbar.setObjectName('AUTOMATE')
        self.menu = self.tr(u'&AUTOMATE')

        self.coder:CodeManager = None 
        self.dlg:ControllerDialog = None
        self.photo_manager:PhotoManager = None
        
        self.package_manager = PackageManager(Path(self.plugin_dir))

        self.settings_file = Path( __file__ ).parent.absolute() / 'settings.ini'

        # Verifica automatica dipendenze all'inizializzazione (usando logica unificata)
        ensure_dependencies(self.plugin_dir, self.iface)

        # Connect to project closing signal
        QgsProject.instance().cleared.connect(self.on_project_closed)
        
        return
    # noinspection PyMethodMayBeStatic
    def tr(self, message):
        """Get the translation for a string using Qt translation API.

        We implement this ourselves since we do not inherit QObject.

        :param message: String for translation.
        :type message: str, QString

        :returns: Translated version of message.
        :rtype: QString
        """
        # noinspection PyTypeChecker,PyArgumentList,PyCallByClass
        return QCoreApplication.translate('Teng', message)

    def add_action(
        self,
        icon_path,
        text,
        callback,
        enabled_flag=True,
        add_to_menu=False,
        add_to_toolbar=True,
        status_tip=None,
        whats_this=None,
        parent=None):
        """Add a toolbar icon to the toolbar.

        :param icon_path: Path to the icon for this action. Can be a resource
            path (e.g. ':/plugins/foo/bar.png') or a normal file system path.
        :type icon_path: str

        :param text: Text that should be shown in menu items for this action.
        :type text: str

        :param callback: Function to be called when the action is triggered.
        :type callback: function

        :param enabled_flag: A flag indicating if the action should be enabled
            by default. Defaults to True.
        :type enabled_flag: bool

        :param add_to_menu: Flag indicating whether the action should also
            be added to the menu. Defaults to True.
        :type add_to_menu: bool

        :param add_to_toolbar: Flag indicating whether the action should also
            be added to the toolbar. Defaults to True.
        :type add_to_toolbar: bool

        :param status_tip: Optional text to show in a popup when mouse pointer
            hovers over the action.
        :type status_tip: str

        :param parent: Parent widget for the new action. Defaults None.
        :type parent: QWidget

        :param whats_this: Optional text to show in the status bar when the
            mouse pointer hovers over the action.

        :returns: The action that was created. Note that the action is also
            added to self.actions list.
        :rtype: QAction
        """

        icon = QIcon(icon_path)
        action = QAction(icon, text, parent)
        action.triggered.connect(callback)
        action.setEnabled(enabled_flag)

        if status_tip is not None:
            action.setStatusTip(status_tip)

        if whats_this is not None:
            action.setWhatsThis(whats_this)

        if add_to_toolbar:
            # Adds plugin icon to Plugins toolbar
            #self.iface.addToolBarIcon(action) # come pulsante singolo
            self.toolbar.addAction(action) # appartenente ad una toolbar

        if add_to_menu:
            self.iface.addPluginToMenu(
                self.menu,
                action)

        self.actions.append(action)

        return action
    
    def initGui(self):
        """Create the menu entries and toolbar icons inside the QGIS GUI."""
        # carica i settings
        self.load_settings()
        # calcola l'rg_cod per tutti gli elementi del layer selezionato
        icon_path = ':/plugins/automate/rg_cod.svg'
        self.add_action(
            icon_path,
            text="RG_COD",
            callback=self.rg_cod,
            parent=self.iface.mainWindow()
        )
        
        # Aggiungi Switch alla toolbar principale per il calcolo automatico dell'rg_cod
        self.toggle = Switch(self.iface.mainWindow())
        self.toggle.set_active_track_color(QColor('red'))  # Imposta il track rosso quando attivo
        self.toggle.setToolTip("Auto RG_COD")
        # Aggiungi Switch alla toolbar principale
        self.toolbar.addWidget(self.toggle)
        self.toggle.toggled.connect(self.auto_rg_cod)

        # Aggiungi/edita foto
        icon_path = ':/plugins/automate/add_edit_foto.svg'
        self.add_action(
            icon_path,
            text=self.tr(u'Add/Edit photo'),
            callback=self.photo,
            parent=self.iface.mainWindow())
        
        # Apri/Salva l'allegato dell'elemento selezionato
        icon_path = ':/plugins/automate/file.svg'
        self.add_action(
            icon_path,
            text=self.tr(u'Open/Save attached file'),
            callback=self.attach_file,
            parent=self.iface.mainWindow())
        
        # cancella l'allegato e/o la feature selezionata
        icon_path = ':/plugins/automate/trash.svg'
        self.add_action(
            icon_path,
            text=self.tr(u'Delete attached file'),
            callback=self.delete_file,
            parent=self.iface.mainWindow())

        # fa partire la dialog per il check dei layer
        icon_path = ':/plugins/automate/check.svg'
        self.add_action(
            icon_path,
            text=self.tr(u'Check'),
            callback=self.checkDialog,
            parent=self.iface.mainWindow())
        
        # zip dei file di progetto
        icon_path = ':/plugins/automate/zip.svg'
        self.add_action(
            icon_path,
            text=self.tr(u'Zip project'),
            callback=self.zip_project,
            parent=self.iface.mainWindow())
        
        icon_path = ":/plugins/automate/setting.svg"
        self.add_action(
            icon_path,
            text=self.tr(u'Settings'),
            callback=self.settingsDialog,
            parent=self.iface.mainWindow())
        
        # # Gestione dipendenze
        # icon_path = os.path.join(self.plugin_dir, 'resources', 'icon', 'dependencies.svg')
        # self.add_action(
        #     icon_path,
        #     text=self.tr(u'Check Dependencies'),
        #     callback=self.check_dependencies,
        #     parent=self.iface.mainWindow())

        # # Disinstallazione dipendenze
        # icon_path = os.path.join(self.plugin_dir, 'resources', 'icon', 'clean_dependencies.svg')
        # self.add_action(
        #     icon_path,
        #     text=self.tr(u'Clean Dependencies'),
        #     callback=self.clean_dependencies,
        #     parent=self.iface.mainWindow(),
        #     status_tip=self.tr(u'Remove all packages from vendor directory'))

        return

    def unload(self):
        """Removes the plugin menu item and icon from QGIS GUI."""
        
        # Cleanup dependencies if needed (uncomment for complete cleanup)
        # try:
        #     plugin_path = Path(self.plugin_dir)
        #     cleanup_dependencies(plugin_path)
        #     print("AUTOMATE: Dependencies cleaned up")
        # except Exception as e:
        #     print(f"AUTOMATE: Error cleaning dependencies: {e}")
        
        # Disconnect from project closing signal
        QgsProject.instance().cleared.disconnect(self.on_project_closed)
        
        if self.toggle and self.toggle.isChecked():
            self.toggle.setChecked(False)
        for action in self.actions:
            self.iface.removePluginMenu(
                self.tr(u'&AUTOMATE'),
                action)
            self.iface.removeToolBarIcon(action)
        
        del self.toolbar
        
        print(f"automate toolbar -> unload")
        return

    @require_project
    def rg_cod(self):
        """Calculate RG_COD for all features in the selected layer."""
        project = QgsProject.instance()
        # coder:Coder = Coder()
        if not self.coder:
            self.coder:CodeManager = CodeManager()
            
        layer = self.iface.activeLayer()
        
        self.coder.run_once(project, layer)
        
        return
    
    def on_project_closed(self):
        """Handler for when the QGIS project is being closed"""
        if self.toggle and self.toggle.isChecked():
            self.toggle.setChecked(False)
            # The auto_rg_cod method will be called automatically due to the toggle signal

    def auto_rg_cod(self, status):
        """Handler for when the QGIS project is being closed"""
        
        project = QgsProject.instance()
        if not check_project_exists(project):
            if status:  # Solo se l'utente sta provando ad attivare
                # Delega il feedback allo Switch stesso
                self.toggle.showRejectionFeedback(duration_ms=450, with_shake=True)
            return
    
        if status:  # If switch is turned on
            if not self.coder:
                self.coder = CodeManager()
                
            self.coder.run(project, project.mapLayers().values())
            #self.project.layersAdded.connect(lambda layers: self.coder.run(self.project, layers))
        else:  # If switch is turned off
            if self.coder:
                self.coder.stop()
                self.coder = None

        return

    @require_project
    def checkDialog(self):
        if self.dlg:
            return
        
        self.dlg = ControllerDialog()

        # show the dialog
        self.dlg.show()
        # Run the dialog event loop
        result = self.dlg.exec_()
        # See if OK was pressed
        print(result)
        if result:
            pass
        
        self.dlg = None

        return
    
    @require_project
    def attach_file(self):        
        attacher:AttachManager = AttachManager(self.iface)
        attacher.run()
        
        return
    
    @require_project
    def delete_file(self):
        trash:TrashManager = TrashManager(self.iface)
        trash.run()
        
        return
    
    @require_project
    def zip_project(self):        
        """Create and run a zip manager for project compression."""
        print("DEBUG: zip_project() chiamato")
        try:
            zip_manager = ZipManager(self.iface)
            print("DEBUG: ZipManager creato")
            project = QgsProject.instance()
            zip_manager.run(project)
            print("DEBUG: zip_manager.run() completato")
        except Exception as e:
            print(f"DEBUG: Errore in zip_project(): {e}")
            import traceback
            print(f"DEBUG: Traceback: {traceback.format_exc()}")
        
        zip_manager = None
        
        return
        
    # Per salvataggio e ricarico settings
    def settingsDialog(self):
        if self.dlg:
            return
        
        self.dlg = SettingsDialog()
        
        # show the dialog
        self.dlg.show()
        # Run the dialog event loop
        result = self.dlg.exec_()
        # See if OK was pressed
        print(result)
        if result:
            self.load_settings()
            print(f"PhotoEditor {self._apikey}")
            
        self.dlg = None
        
        return

    def load_settings(self):
        # Carica le impostazioni dal file settings.ini
        config = configparser.ConfigParser()
        config.read(self.settings_file)

        # Carica  la sezione 'Settings'
        if config.has_option('Settings', 'APIKEY'):
            setting_value = config.get('Settings', 'APIKEY')
            self._apikey = setting_value
        
        return
    
    @require_project
    def photo(self):        
        self.photo_manager:PhotoManager = PhotoManager(self.iface, self._apikey)
        self.photo_manager.run()
        
        return

    def check_dependencies(self):
        """
        Gestione dipendenze tramite pulsante nella toolbar.
        Delega al PackageManager per separazione delle responsabilità.
        """
        try:
            # Delega la gestione completa al PackageManager
            self.package_manager.check_dependencies_interactive(self.iface)
                
        except Exception as e:
            print(f"❌ AUTOMATE Dependencies Error: {e}")
            import traceback
            print(traceback.format_exc())
            iface.messageBar().pushMessage(
                'AUTOMATE Dependencies', 
                f'❌ Errore controllo: {str(e)}',
                level=Qgis.Critical,
                duration=6
            )

    def clean_dependencies(self):
        """
        Disinstallazione dipendenze tramite pulsante nella toolbar.
        Delega al PackageManager per la pulizia della directory vendor.
        """
        try:
            # Delega la gestione completa al PackageManager
            result = self.package_manager.uninstall_dependencies_interactive(self.iface)
            
            if result:
                print("✅ AUTOMATE Dependencies: Pulizia completata")
            else:
                print("ℹ️ AUTOMATE Dependencies: Pulizia annullata o parziale")
                
        except Exception as e:
            print(f"❌ AUTOMATE Dependencies Clean Error: {e}")
            import traceback
            print(traceback.format_exc())
            self.iface.messageBar().pushMessage(
                'AUTOMATE Dependencies', 
                f'❌ Errore pulizia: {str(e)}',
                level=Qgis.Critical,
                duration=6
            )
