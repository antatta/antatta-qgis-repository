# -*- coding: utf-8 -*-
"""
/***************************************************************************
 TrashManager
                                 A QGIS plugin
 The AUTOMATE plug-in
                             -------------------
        begin                : 2024-09-23
        copyright            : (C) 2024 by Ing. Antonio Attadia
        email                : antonio.attadia@italgas.it
        git sha              : $Format:%H$
 ***************************************************************************/
 to delete attached and feature
"""
import re
from pathlib import Path
from PyQt5.QtWidgets import QMessageBox
from qgis.core import QgsProject, QgsVectorLayer, QgsFeature, edit, Qgis
from qgis.PyQt.QtCore import QVariant

from ...database.database_connect import DatabaseConnect

class TrashManager:
    def __init__(self, iface):
        self.iface = iface  # riferimento all'interfaccia QGIS
        # campo univoco feature
        self.UNIVOCO_FEATURE:str = "RG_COD"
        # cartella allegati
        self.attached_dir:str = "allegati"
        # limite elementi lotto
        self.cifre_max_elementi_lotto = 4
        self.cifre_max_nome_lotto = 4

        self.project = QgsProject.instance()
        self.project_home = Path(self.project.homePath())
        self.lotto = self.project.baseName()[:self.cifre_max_nome_lotto]

        self.selected_features = []
        self.layer = None

        self.attached_field:str = None
        self.attached_subdir:str = None
        self.attached_type:str = None
        self.attached_name:str = None

    def run(self):
        if not self.perform_checks():  # Esegue i controlli
            return

        reply = QMessageBox.question(
            None, 'Cestino',
            'Vuoi eliminare l\'allegato e anche la feature?\n'
            'Sì -> elimina entrambi\n'
            'No -> elimina solo l\'allegato.\n'
            'Cancel -> per annullare',
            QMessageBox.Yes | QMessageBox.No | QMessageBox.Cancel,
            QMessageBox.Cancel
        )

        if reply == QMessageBox.Cancel:
            return

        delete_feature = (reply == QMessageBox.Yes)

        for feature in self.selected_features:
            self.delete_attachment(feature)
            if delete_feature:
                self.delete_feature(feature)

    def perform_checks(self):
        self.layer: QgsVectorLayer = self.iface.activeLayer()
        if not self.layer:
            msg = "Errore: Nessun layer attivo."
            self.iface.messageBar().pushMessage("Errore", msg, level=Qgis.Warning)
            print(msg)
            return False

        self.selected_features = self.layer.selectedFeatures()
        if not self.selected_features:
            msg = "Errore: Nessuna feature selezionata."
            self.iface.messageBar().pushMessage("Errore", msg, level=Qgis.Warning)
            print(msg)
            return False
        
        # path del db generale
        connect_db:DatabaseConnect = DatabaseConnect()
        if not connect_db:
            msg = f"DB non trovato"
            return False
        
        # recupero il nome del layer dal lotto.gpkg    
        layer_source_name:str = self.get_layer_source_name(self.layer)
        print(layer_source_name)
        
        # field dove è memorizzato l'allegato sul layer
        result = connect_db.get_layer_field_with_attach('',layer_source_name)
        if not result:
            msg = f"Il layer {self.layer.name()} non prevede allegati"
            self.iface.messageBar().pushMessage("Info", msg, level=Qgis.Info)
            print(msg)
            return False

        # nome field ove memorizzare il nome dell'allegato
        # e directory ove memorizzare il file allegato
        self.attached_field, self.attached_subdir, self.attached_type = result


        return True

    def delete_attachment(self, feature: QgsFeature):
        # Verifica che la feature abbia un allegato
        attachment_value = feature[self.attached_field]
        if isinstance(attachment_value, QVariant) or not attachment_value:
            msg = "Nessun allegato da eliminare."
            self.iface.messageBar().pushMessage("Info", msg, level=Qgis.Info)
            print(msg)
            return

        # Path dell'allegato
        save_dir = self.project_home / self.lotto / self.attached_dir / self.attached_subdir
        file_path = save_dir / attachment_value

        if file_path.exists():
            try:
                file_path.unlink()  # elimina il file
                msg = f"Allegato {file_path} eliminato con successo."
                self.iface.messageBar().pushMessage("Successo", msg, level=Qgis.Success)
                print(msg)

                # Elimina il riferimento all'allegato nel campo del layer
                self.clear_attachment_field(feature)

            except Exception as e:
                msg = f"Errore durante l'eliminazione dell'allegato: {str(e)}"
                self.iface.messageBar().pushMessage("Errore", msg, level=Qgis.Critical)
                print(msg)
        else:
            msg = f"Errore: Il file {file_path} non esiste."
            self.iface.messageBar().pushMessage("Errore", msg, level=Qgis.Warning)
            print(msg)

    def clear_attachment_field(self, feature: QgsFeature):
        with edit(self.layer):
            feature.setAttribute(self.attached_field, None)
            self.layer.updateFeature(feature)
            msg = f"Campo allegato della feature {feature.id()} svuotato."
            self.iface.messageBar().pushMessage("Successo", msg, level=Qgis.Info)
            print(msg)

    def delete_feature(self, feature: QgsFeature):
        with edit(self.layer):
            self.layer.deleteFeature(feature.id())
            msg = f"Feature {feature.id()} eliminata con successo."
            self.iface.messageBar().pushMessage("Successo", msg, level=Qgis.Info)
            print(msg)

    
    def get_layer_source_name(self, layer:QgsVectorLayer):
        # Verifica se il layer è un vettore
        if not(layer and isinstance(layer, QgsVectorLayer)):
            # msg = f"Nessun layer vettoriale attivo o layer non valido. layer_name: {layer.name()} layer_id: {layer.id()}."
            # print(msg)
            # iface.messageBar().pushMessage(u'get_layer_source_name', msg, level=Qgis.Critical)
            return
        
        # Ottieni la sorgente del provider del layer (es: "dbname='path_to_file.gpkg' table=\"table_name\" (geometry_column) sql=")
        provider_source = layer.source()
        # Usa una regex per estrarre il nome della tabella
        match = re.search(r'(?<=layername=)[^|]+', provider_source)
        if not match:
            # msg = f"Non è stato possibile determinare il nome originale del layer. layer_name: {layer.name()} layer_id: {layer.id()} in {provider_source}."
            # print(msg)
            # iface.messageBar().pushMessage(u'get_layer_source_name', msg, level=Qgis.Critical)
            return
        
        layer_name = match[0]
        # msg = f"get_layer_source_name -> layer_name: {layer.name()} layer_id: {layer.id()} layer_source_name: {layer_name}"
        # print(msg)
        
        return layer_name
    

