# -*- coding: utf-8 -*-
"""
/***************************************************************************
 TrashManager
                                 A QGIS plugin
 The AUTOMATE plug-in
                             -------------------
        begin                : 2024-09-23
        copyright            : (C) 2024 by Ing. Antonio Attadia
        email                : info.antatta@gmail.com
        git sha              : $Format:%H$
 ***************************************************************************/
Enhanced trash management for attachments and features
"""
# # 1. FUTURE IMPORTS
from __future__ import annotations

# # 2. STANDARD LIBRARY
from pathlib import Path
from typing import List, Optional

# # 3. THIRD-PARTY LIBRARIES
from PyQt5.QtWidgets import QMessageBox
from qgis.core import Qgis, QgsFeature, QgsVectorLayer, edit
from qgis.PyQt.QtCore import QVariant
from qgis.utils import iface

# # 5. LOCAL IMPORTS
from ...core import AutomateContext
from .base_attachment_manager import BaseAttachmentManager


class TrashManager(BaseAttachmentManager):
    """
    Gestisce l'eliminazione di allegati e feature.
    Eredita da BaseAttachmentManager per funzionalità comuni.
    
    Funzionalità:
    - Eliminazione allegati dal filesystem
    - Eliminazione feature dal layer (opzionale)
    - Pulizia campi attachment
    - Gestione selezioni multiple
    """
    
    def __init__(self, context: AutomateContext) -> None:
        super().__init__(context)
        self.selected_features: List[QgsFeature] = []
        self.layer: Optional[QgsVectorLayer] = None

    def run(self) -> None:
        """Esegue il workflow principale del trash manager."""
        if not self.perform_checks():
            return

        # Chiedi all'utente cosa eliminare
        reply = QMessageBox.question(
            None, 
            'Cestino',
            'Vuoi eliminare l\'allegato e anche la feature?\n'
            'Sì -> elimina entrambi\n'
            'No -> elimina solo l\'allegato.\n'
            'Cancel -> per annullare',
            QMessageBox.Yes | QMessageBox.No | QMessageBox.Cancel,
            QMessageBox.Cancel
        )

        if reply == QMessageBox.Cancel:
            return

        delete_feature = (reply == QMessageBox.Yes)

        # Processa tutte le feature selezionate
        for feature in self.selected_features:
            self._process_feature_deletion(feature, delete_feature)

    def perform_checks(self) -> bool:
        """Esegue tutti i controlli necessari per il trash manager."""
        # Ottieni layer attivo
        self.layer = iface.activeLayer()
        if self.layer is None:
            self._show_error("Nessun layer attivo")
            return False

        # Verifica selezione feature
        self.selected_features = self.layer.selectedFeatures()
        if not self.selected_features:
            self._show_error("Nessuna feature selezionata")
            return False

        # Verifica supporto allegati per il layer
        if not self.validate_layer_for_attachments(self.layer):
            return False

        return True
    
    def _process_feature_deletion(self, feature: QgsFeature, delete_feature: bool) -> None:
        """Processa l'eliminazione per una singola feature."""
        # Elimina allegato se presente
        self._delete_attachment(feature)
        
        # Elimina feature se richiesto
        if delete_feature:
            self._delete_feature(feature)

    def _delete_attachment(self, feature: QgsFeature) -> None:
        """Elimina l'allegato associato alla feature."""
        # Verifica presenza allegato
        attachment_value = feature[self.attached_field]
        if isinstance(attachment_value, QVariant) or not attachment_value:
            self._show_info(f"Feature {feature.id()}: nessun allegato da eliminare")
            return

        # Path dell'allegato
        file_path = self.get_attachment_save_dir() / attachment_value

        if not file_path.exists():
            self._show_warning(f"File allegato non trovato: {file_path}")
            return

        try:
            file_path.unlink()  # Elimina il file
            self._show_success(f"Allegato eliminato: {file_path}")

            # Pulisci il campo attachment nella feature
            self._clear_attachment_field(feature)

        except Exception as e:
            self._show_error(f"Errore eliminazione allegato {file_path}: {e}")

    def _clear_attachment_field(self, feature: QgsFeature) -> None:
        """Svuota il campo allegato della feature."""
        assert self.layer is not None  # Garantito da perform_checks
        
        try:
            with edit(self.layer):
                feature.setAttribute(self.attached_field, None)
                success = self.layer.updateFeature(feature)
                
            if success:
                self._show_info(f"Campo allegato svuotato per feature {feature.id()}")
            else:
                self._show_error(f"Impossibile aggiornare feature {feature.id()}")
                
        except Exception as e:
            self._show_error(f"Errore aggiornamento feature {feature.id()}: {e}")

    def _delete_feature(self, feature: QgsFeature) -> None:
        """Elimina la feature dal layer."""
        assert self.layer is not None  # Garantito da perform_checks
        
        try:
            with edit(self.layer):
                success = self.layer.deleteFeature(feature.id())
                
            if success:
                self._show_success(f"Feature {feature.id()} eliminata")
            else:
                self._show_error(f"Impossibile eliminare feature {feature.id()}")
                
        except Exception as e:
            self._show_error(f"Errore eliminazione feature {feature.id()}: {e}")