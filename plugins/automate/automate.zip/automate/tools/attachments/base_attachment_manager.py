# -*- coding: utf-8 -*-
"""
/***************************************************************************
 BaseAttachmentManager
                                 A QGIS plugin
 The AUTOMATE plug-in
                             -------------------
        begin                : 2025-09-20
        copyright            : (C) 2024 by Ing. Antonio Attadia
        email                : info.antatta@gmail.com
        git sha              : $Format:%H$
 ***************************************************************************/
Base class for attachment management with common functionality
"""
# # 1. FUTURE IMPORTS
from __future__ import annotations

# # 2. STANDARD LIBRARY
import re
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Optional, Tuple

# # 3. THIRD-PARTY LIBRARIES
from qgis.core import Qgis, QgsVectorLayer
from qgis.utils import iface

# # 5. LOCAL IMPORTS
from ...core import AutomateContext


class BaseAttachmentManager(ABC):
    """
    Classe base per la gestione degli allegati che centralizza funzionalità comuni.
    
    Fornisce:
    - Validazione layer e database
    - Estrazione nome layer source
    - Gestione errori standardizzata
    - Accesso sicuro alle costanti
    """
    
    def __init__(self, context: AutomateContext) -> None:
        """
        Inizializza il manager con validazione del context.
        
        Args:
            context: Context dell'applicazione con database e costanti
            
        Raises:
            ValueError: Se il context non è valido
        """
        if not context:
            raise ValueError("Context non può essere None")
        if not context.db:
            raise ValueError("Database connection non disponibile nel context")
        
        self.context = context
        
        # Inizializza campi per attachment info
        self.attached_field: str = ""
        self.attached_dir: str = ""
        self.attached_subdir: str = ""
        self.attached_type: str = ""
        
    def get_layer_source_name(self, layer: QgsVectorLayer) -> Optional[str]:
        """
        Estrae il nome della sorgente del layer dal GPKG.
        
        Args:
            layer: Layer QGIS vettoriale
            
        Returns:
            Nome del layer source o None se non trovato
        """
        if layer is None or not isinstance(layer, QgsVectorLayer):
            return None
        
        provider_source = layer.source()
        match = re.search(r'(?<=layername=)[^|]+', provider_source)
        return match[0] if match else None
    
    def get_attachment_info(self, layer_source_name: str) -> Optional[Tuple[str, str, str]]:
        """
        Recupera informazioni attachment per un layer dal database.
        
        Args:
            layer_source_name: Nome del layer source
            
        Returns:
            Tupla (field, subdir, type) o None se layer non supporta attachments
        """
        try:
            result = self.context.db.get_layer_field_with_attach('', layer_source_name)
            if result:
                self.attached_field, self.attached_subdir, self.attached_type = result
                # Ottieni directory base dalle costanti esistenti
                self.attached_dir = self.context.c.dir_allegati
                return result
            return None
        except Exception as e:
            self._show_error(f"Errore accesso database per attachment info: {e}")
            return None
    
    def validate_layer_for_attachments(self, layer: QgsVectorLayer) -> bool:
        """
        Valida che il layer supporti gli allegati.
        
        Args:
            layer: Layer da validare
            
        Returns:
            True se il layer supporta allegati, False altrimenti
        """
        layer_source_name = self.get_layer_source_name(layer)
        if not layer_source_name:
            self._show_error(f"Impossibile determinare il nome source per layer {layer.name()}")
            return False
        
        if not self.get_attachment_info(layer_source_name):
            self._show_info(f"Il layer {layer.name()} non prevede allegati")
            return False
            
        return True
    
    def get_attachment_save_dir(self) -> Path:
        """
        Costruisce il path della directory per salvare gli allegati.
        
        Returns:
            Path alla directory degli allegati
        """
        return self.context.lotto_dir_path / self.attached_dir / self.attached_subdir
    
    def _show_message(self, title: str, message: str, level: Qgis.MessageLevel) -> None:
        """Mostra messaggio standardizzato."""
        print(f"{title}: {message}")
        iface.messageBar().pushMessage(title, message, level=level)
    
    def _show_error(self, message: str) -> None:
        """Mostra messaggio di errore."""
        self._show_message("Errore", message, Qgis.Critical)
    
    def _show_warning(self, message: str) -> None:
        """Mostra messaggio di warning."""
        self._show_message("Warning", message, Qgis.Warning)
    
    def _show_info(self, message: str) -> None:
        """Mostra messaggio informativo."""
        self._show_message("Info", message, Qgis.Info)
    
    def _show_success(self, message: str) -> None:
        """Mostra messaggio di successo."""
        self._show_message("Successo", message, Qgis.Success)
    
    @abstractmethod
    def run(self) -> None:
        """Metodo principale da implementare nelle classi figlie."""
        pass
    
    @abstractmethod 
    def perform_checks(self) -> bool:
        """Validazioni specifiche da implementare nelle classi figlie."""
        pass