# -*- coding: utf-8 -*-
"""
Attachments module for AUTOMATE plugin v2.0
Contains attachment and trash management.
"""
from .attach_manager import AttachManager
from .trash_manager import TrashManager

__all__ = ['AttachManager', 'TrashManager']
