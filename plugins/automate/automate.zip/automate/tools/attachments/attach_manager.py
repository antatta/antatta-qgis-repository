# -*- coding: utf-8 -*-
"""
/***************************************************************************
 AttachManager
                                 A QGIS plugin
 The AUTOMATE plug-in
                             -------------------
        begin                : 2024-09-23
        copyright            : (C) 2024 by Ing. Antonio Attadia
        email                : info.antatta@gmail.com
        git sha              : $Format:%H$
 ***************************************************************************/
Enhanced attachment management with improved error handling and type safety
"""
# # 1. FUTURE IMPORTS
from __future__ import annotations

# # 2. STANDARD LIBRARY
import subprocess
import sys
from pathlib import Path
from typing import Optional

# # 3. THIRD-PARTY LIBRARIES
from PyQt5.QtWidgets import QFileDialog, QMessageBox
from qgis.core import Qgis, QgsFeature, QgsVectorLayer, edit
from qgis.PyQt.QtCore import QVariant
from qgis.utils import iface

# # 5. LOCAL IMPORTS
from ...core import AutomateContext
from .base_attachment_manager import BaseAttachmentManager


class AttachManager(BaseAttachmentManager):
    """
    Gestisce l'apertura, visualizzazione e salvataggio di allegati per le feature.
    Eredita da BaseAttachmentManager per funzionalità comuni.
    """
    
    def __init__(self, context: AutomateContext) -> None:
        super().__init__(context)
        self.selected_feature: Optional[QgsFeature] = None
        self.layer: Optional[QgsVectorLayer] = None

    def run(self) -> None:
        """Esegue il workflow principale dell'attachment manager."""
        if not self.perform_checks():
            return
        
        # Type assertion - dopo perform_checks questi non sono None
        assert self.selected_feature is not None
        
        # Verifica se la feature ha già un allegato
        attached_value = self.selected_feature[self.attached_field]
        if not isinstance(attached_value, QVariant) and attached_value:
            # Apre allegato esistente
            self._open_existing_attachment(attached_value)
        else:
            # Workflow per nuovo allegato
            self._handle_new_attachment()
    
    def perform_checks(self) -> bool:
        """Esegue tutti i controlli necessari per l'attachment manager."""
        # Ottieni layer attivo
        self.layer = iface.activeLayer()
        if self.layer is None:
            self._show_error("Nessun layer attivo")
            return False
        
        # Verifica selezione feature
        selection = self.layer.selectedFeatures()
        if not selection:
            self._show_error("Nessuna feature selezionata")
            return False
        
        self.selected_feature = selection[0]
        
        # Verifica campo univoco feature
        field_univoco_feature = self.context.c.UNIVOCO_FEATURE
        valore_univoco = self.selected_feature[field_univoco_feature]
        
        if isinstance(valore_univoco, QVariant) or not valore_univoco:
            self._show_info(f"La feature selezionata non ha {field_univoco_feature} valido")
            return False

        # Verifica supporto allegati per il layer
        if not self.validate_layer_for_attachments(self.layer):
            return False

        return True
    
    def _open_existing_attachment(self, attached_value: str) -> None:
        """Apre un allegato esistente."""
        file_path = self.get_attachment_save_dir() / attached_value
        if not file_path.exists():
            self._show_warning(f"File allegato non trovato: {file_path}")
            return
        
        self._open_with_system_viewer(file_path)
        self._show_success(f"Aperto allegato: {file_path}")
    
    def _handle_new_attachment(self) -> None:
        """Gestisce il workflow per un nuovo allegato."""
        file_path = self._open_file_dialog()
        if not file_path:
            return
        
        self._open_with_system_viewer(file_path)
        self._prompt_to_save(file_path)
    
    def _open_file_dialog(self) -> Optional[Path]:
        """Apre il dialog per selezionare un file."""
        file_dialog = QFileDialog()
        file_path, _ = file_dialog.getOpenFileName(
            None, 
            "Seleziona allegato", 
            str(self.context.project_home_path), 
            f"File (*.{self.attached_type})"
        )
        return Path(file_path) if file_path else None

    def _open_with_system_viewer(self, file_path: Path) -> None:
        """Apre il file con il visualizzatore predefinito del sistema."""
        try:
            if sys.platform == 'win32':  # Windows
                subprocess.Popen(['start', str(file_path)], shell=True)
            elif sys.platform == 'darwin':  # macOS
                subprocess.Popen(['open', str(file_path)])
            else:  # Linux/Unix
                subprocess.Popen(['xdg-open', str(file_path)])
        except Exception as e:
            self._show_error(f"Impossibile aprire il file: {e}")

    def _prompt_to_save(self, file_path: Path) -> None:
        """Chiede se salvare il file come allegato."""
        reply = QMessageBox.question(
            None, 
            'Salva allegato', 
            'Vuoi salvare il file?',
            QMessageBox.Yes | QMessageBox.No, 
            QMessageBox.No
        )

        if reply == QMessageBox.Yes:
            saved_name = self._save_file(file_path)
            if saved_name:
                self._update_feature_attachment(saved_name)

    def _save_file(self, file_path: Path) -> Optional[str]:
        """Salva il file nella directory degli allegati."""
        assert self.selected_feature is not None  # Garantito da perform_checks
        
        save_dir = self.get_attachment_save_dir()
        
        try:
            save_dir.mkdir(parents=True, exist_ok=True)

            # Nome basato sul campo univoco della feature
            rg_cod = self.selected_feature[self.context.c.UNIVOCO_FEATURE]
            file_name = f"{rg_cod}{file_path.suffix}"
            save_path = save_dir / file_name

            # Copia del file
            save_path.write_bytes(file_path.read_bytes())

            self._show_success(f"File salvato in: {save_path}")
            return file_name

        except Exception as e:
            self._show_error(f"Impossibile salvare il file: {e}")
            return None
    
    def _update_feature_attachment(self, file_name: str) -> None:
        """Aggiorna il campo allegato della feature."""
        assert self.layer is not None and self.selected_feature is not None
        
        try:
            with edit(self.layer):
                self.selected_feature.setAttribute(self.attached_field, file_name)
                success = self.layer.updateFeature(self.selected_feature)
                
            if success:
                self._show_success(f"Campo allegato aggiornato: {file_name}")
            else:
                self._show_error("Impossibile aggiornare la feature")
                
        except Exception as e:
            self._show_error(f"Errore aggiornamento feature: {e}")