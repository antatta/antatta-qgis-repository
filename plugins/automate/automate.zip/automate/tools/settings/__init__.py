# -*- coding: utf-8 -*-
"""
Generic dialogs for AUTOMATE plugin v2.0
"""
