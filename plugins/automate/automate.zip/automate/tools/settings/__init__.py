# -*- coding: utf-8 -*-
"""
Generic dialogs for AUTOMATE plugin v2.0
"""
from .settings_dialog import SettingsDialog

__alla__ = ['SettingsDialog']