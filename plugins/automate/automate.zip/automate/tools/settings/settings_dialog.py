# -*- coding: utf-8 -*-
"""
/***************************************************************************
 SettingsDialog
                                 A QGIS plugin
 PhotoEditor
                              -------------------
        begin                : 2023-02-27
        copyright            : (C) 2023 by Ing. Antonio Attadia
        email                : info.antatta@gmail.com
 ***************************************************************************/
 dialog to set (save and reload) APIKEY code
"""

from qgis.PyQt import uic
from qgis.PyQt import QtWidgets

import os
import configparser


# This loads your .ui file so that PyQt can populate your plugin with the elements from Qt Designer
FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'settings.ui'))


class SettingsDialog(QtWidgets.QDialog, FORM_CLASS):
    def __init__(self, parent=None):
        """Constructor."""
        super(SettingsDialog, self).__init__(parent)
        # Set up the user interface from Designer through FORM_CLASS.
        # After self.setupUi() you can access any designer object by doing
        # self.<objectname>, and you can use autoconnect slots - see
        # http://qt-project.org/doc/qt-4.8/designer-using-a-ui-file.html
        # #widgets-and-dialogs-with-auto-connect
        self.setupUi(self)
        #self.plugin_dir = os.path.dirname(__file__)
        # self.plugin_dir = Path( __file__ ).parent.absolute()
        self.settings_file = os.path.abspath(os.path.join(os.path.dirname(__file__), '../..', 'settings.ini'))
        print(f"SettingsDialog -> settings_file: {self.settings_file}")
        
        self.buttonBox: QtWidgets.QDialogButtonBox
        self.buttonBox.button(QtWidgets.QDialogButtonBox.Ok).clicked.connect(self.save_settings)
        self.load_settings()

        return
    
    def save_settings(self):     
        # Salva il contenuto della variabile self._apikey in un file di impostazioni
        config = configparser.ConfigParser()
        config.read(self.settings_file)

        # Inizializza  la sezione 'Settings'
        if not config.has_section('Settings'):
            config.add_section('Settings')

        config.set('Settings', 'APIKEY',  self.lineEdit.text())
        
        with open(self.settings_file, 'w') as configfile:
            config.write(configfile)
        
        return
    
    def load_settings(self):
        # Carica le impostazioni dal file settings.ini
        config = configparser.ConfigParser()
        config.read(self.settings_file)

        # Carica  la sezione 'Settings'
        if config.has_option('Settings', 'APIKEY'):
            setting_value = config.get('Settings', 'APIKEY')
            self.lineEdit:QtWidgets.QLineEdit
            self.lineEdit.setText(setting_value)
        
        return