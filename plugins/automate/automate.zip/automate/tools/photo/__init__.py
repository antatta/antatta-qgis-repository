# -*- coding: utf-8 -*-
"""
Photo module for AUTOMATE plugin v2.0
Contains photo management, downloading, editing, and tools.
"""
