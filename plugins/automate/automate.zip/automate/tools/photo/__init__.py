# -*- coding: utf-8 -*-
"""
Photo module for AUTOMATE plugin v2.0
Contains photo management, downloading, editing, and tools.
"""
# # 5. LOCAL IMPORTS
from .photo_manager import PhotoManager

__alla__ = ['PhotoManager']
