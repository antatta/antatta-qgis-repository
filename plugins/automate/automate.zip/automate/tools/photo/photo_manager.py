# -*- coding: utf-8 -*-
"""
/***************************************************************************
 PhotoManager
                                 A QGIS plugin
 The AUTOMATE plug-in
                             -------------------
        begin                : 2024-09-23
        copyright            : (C) 2024 by Ing. Antonio Attadia
        email                : info.antatta@gmail.com
        git sha              : $Format:%H$
 ***************************************************************************/
 class to manage PhotoDownloader, PhotoEditorWindow, PointTool
"""
# # 2. STANDARD LIBRARY
import re
# from enum import Enum
from pathlib import Path

# # 3. THIRD-PARTY LIBRARIES
from PyQt5.QtCore import QObject, pyqtSignal
from qgis.core import (  # , edit
    Qgis,
    QgsFeature,
    QgsGeometry,
    QgsPointXY,
    QgsProject,
    QgsVectorLayer,
)
from qgis.PyQt.QtCore import QVariant
from qgis.PyQt.QtGui import QImage, QPixmap
from qgis.utils import iface

# # 5. LOCAL IMPORTS
from ...core import AutomateContext, refresh_qgis_layer_safely
from ..rg_cod import CoderManager
from .photo_downloader import PhotoDownloader  # Classe che scarica la foto dalle API
from .photo_editor_window import PhotoEditorWindow  # Classe per l'editor delle foto
from .point_tool import PointTool  # Classe che genera il punto di ripresa


class PhotoManager(QObject):
    rg_cod_generated = pyqtSignal(str)  # Segnale per l'RG_COD generato
    image_attributes = pyqtSignal(QImage, dict) # Segnale per l'avvenuto download dell'immagine
    featureAdded = pyqtSignal(int) # segnale per emissione fid nuova feature
    def __init__(self, context:AutomateContext):
        # Chiama il costruttore della classe padre (QObject)
        super().__init__()

        self.context = context
        # Collegamenti segnali

        self.point:QgsPointXY = None
        self.point_tool:PointTool = None
        self.window:PhotoEditorWindow = None
        self.coder = CoderManager(self.context)
        self.file_path:Path = None

        self._mode = None
        self._geometry = None

        self.project = QgsProject.instance()
        
        self.selected_feature = None  # per memorizzare la feature selezionata
        self.layer:QgsVectorLayer = None # per memorizzare il layer selezionato
        
        self.attached_field:str = None
        self.attached_subdir:str = None
        self.attached_type:str = None
        self.attached_name:str = None
        
        self.attributes:dict = {}
        

    def run(self):
        if not self.perform_checks(): # se superato seleziona una feature o None
            return
        
        selection = self.layer.selectedFeatures()
        self.selected_feature = selection[0] if selection else None

        if not self.selected_feature:  # Nessuna feature selezionata
            """Se nessuna feature è selezionata, aggiunge una nuova foto tramite PointTool."""
            self._mode = 'add'
            # Avvia PointTool per catturare un punto e ottenere parametri
            self.point_tool = PointTool(self.layer)
            iface.mapCanvas().setMapTool(self.point_tool)
            self.point_tool.point_captured.connect(self.download_and_open_photo)
            return
            
        # verifica se nella feature è memorizzato un file
        attached_value = self.selected_feature[self.attached_field]
        if not isinstance(attached_value, QVariant):
            self.file_path:Path = self.context.project_home_path/ self.context.lotto_name / self.context.c.dir_allegati / self.attached_subdir / attached_value
            if not self.file_path.exists():
                msg = f"Errore: non esiste il file {self.file_path}"
                iface.messageBar().pushMessage("Warning", msg, level=Qgis.Warning)
                print(msg)
                return
            
            self._mode = 'edit'
            image = QImage(self.file_path.as_posix())
            self.fid = self.selected_feature.id()
            self.attributes = self.selected_feature.attributeMap()
            self.openPhotoEditorWindow(image, self.attributes)
            return
        
        return
    
    def perform_checks(self):
        """Verifica che il layer corretto sia selezionato."""
        self.layer = iface.activeLayer()
        if not isinstance(self.layer, QgsVectorLayer):
            self.layer = None
            msg =  "Nessun layer valido selezionato."
            iface.messageBar().pushMessage("Errore", msg, level=Qgis.Warning)
            print(msg)
            return False


        # recupero il nome del layer dal lotto.gpkg    
        layer_source_name:str = self.get_layer_source_name(self.layer)
        if layer_source_name != 'SGA_PUNTO_RIF_FOTO':
            self.layer = None
            msg =  "Il layer selezionato non è quello atteso."
            iface.messageBar().pushMessage("Errore", msg, level=Qgis.Warning)
            print(msg)
            return False
        
        
        # field dove è memorizzato l'allegato sul layer
        result = self.context.db.get_layer_field_with_attach('',layer_source_name)
        if not result:
            self.layer = None
            msg = f"Il layer {self.layer.name()} non prevede allegati"
            iface.messageBar().pushMessage("Info", msg, level=Qgis.Info)
            print(msg)
            return False

        # nome field ove memorizzare il nome dell'allegato
        # e directory ove memorizzare il file allegato
        self.attached_field, self.attached_subdir, self.attached_type = result
        
        return True

    def download_and_open_photo(self, punto:QgsPointXY, data:dict):
        """Scarica la foto da Google API e emette un segnale con la foto e relativi dati."""
        image = self.download_photo(data)
        if not image:
            msg = "Errore nel download della foto!"
            print(msg)
            iface.messageBar().pushCritical('PhotoManager says', msg)
            return
        
        self.point = punto
        print(f"Foto scaricata con successo: {self.point}")
        self.openPhotoEditorWindow(image, data)

        return

    def download_photo(self, data:dict):
        """Scarica la foto da Google API"""
        lat = data['LAT']
        long = data['LONG']
        heading = data['HEADING']  
        
        # Scarica la foto utilizzando la classe PhotoDownloader
        downloader = PhotoDownloader(self.context.apikey)
        image = downloader.download_photo(lat, long, heading)
        
        return image
    
    # apre l'ImageEditor con il file selezionato
    def openPhotoEditorWindow(self, image:QImage, attributes:dict) -> None:
        self.window = PhotoEditorWindow()
        self.window.reload.connect(self.reloadPhotoEditorWindow)
        self.window.saved.connect(self.window_saved)
        self.window.closed.connect(self.reset)
        self.window.setBackground(image)
        self.window.setData(attributes)
        self.window.show()
        return
    
    def reloadPhotoEditorWindow(self, data:dict) -> None:
        image = self.download_photo(data)
        if not image:
            msg = "Errore nel download della foto!"
            iface.messageBar().pushCritical('PhotoManager says', msg)
            return
        self.window.setBackground(image)
        print(f"Foto ricaricata con successo")
        return
    
    def window_saved(self, pixmap: QPixmap, attributes: dict):
        """Viene chiamato quando l'immagine è salvata dal PhotoEditor."""
        self.attributes = attributes
        
        if self._mode == 'add':           
            result = self.add_feature(self.layer, self.point)
            if not result:
                msg = "Errore nell'aggiunta della feature!"
                iface.messageBar().pushCritical('PhotoEditor says', msg)
                return False

            print(f"Feature aggiunta con FID: {self.fid}")
            
        result = self.edit_feature(self.fid, self.attributes)
        if not result:
            msg = "Errore nell'aggiornamento della feature!"
            iface.messageBar().pushCritical('PhotoEditor says', msg)
            return False
        # Ricarica il layer in QGIS per riflettere le modifiche
        refresh_qgis_layer_safely(self.layer)
        print(f"Feature aggiornata con FID: {self.fid}")
            
        # Sovrascrive l'immagine nella directory
        result = self.save_pixmap(pixmap, self.file_path)
        if not result:
            msg = "Errore nel salvataggio della foto!"
            iface.messageBar().pushCritical('PhotoEditor says', msg)
            return False
        print(f"Foto salvata con successo in: {self.file_path}")
            
        iface.messageBar().pushSuccess('PhotoEditor says', 'Feature aggiunta!')
        self._mode = "edit"
        return True


    def add_feature(self, layer:QgsVectorLayer, point:QgsPointXY) -> bool:
        """ Aggiunge una feature al layer """
        
        # Inizia una transazione per aggiungere la feature
        feature = QgsFeature(layer.fields())
        feature.setGeometry(QgsGeometry.fromPointXY(point))
                    
        try:
            layer.blockSignals(True)
            layer.startEditing()
            result = layer.addFeature(feature)
            
            # print("Photo Editor Prima del commit")
            layer.commitChanges()
            # print("Photo Editor dopo del commit")
        except Exception as e:
            layer.rollBack()
            msg = f"Erorre nell'aggiunta della feature al layer. {e}"
            print(msg)
            iface.messageBar().pushMessage("Error", msg, level=Qgis.Critical, duration=3)
            return False
        finally:
            layer.blockSignals(False)  # Assicurati di sbloccare i segnali alla fine
            
        last_feature = None
        for f in layer.getFeatures():
            if last_feature is None or f.id() > last_feature.id():
                last_feature = f

        self.fid = last_feature.id()
        
        # Genera l'RG_COD per la feature appena aggiunta
        self.coder = CoderManager(self.context)
        result, rg_cod = self.coder.run_on_feature_by_fid(layer, self.fid)
        self.coder = None
        
        if not result:
            msg = f"Errore nella generazione dell'RG_COD per la feature {self.fid}"
            print(msg)
            iface.messageBar().pushMessage("Error", msg, level=Qgis.Critical, duration=3)
            return False
        
        return True
    
    def edit_feature(self, fid:int, attributes:dict) -> bool:
        # Inizia una transazione per modificare la feature
        self.layer:QgsVectorLayer
        feature = self.layer.getFeature(fid)
        
        attached_value = f"{feature[self.context.c.UNIVOCO_FEATURE]}.{self.attached_type}"
        self.file_path = self.context.project_home_path/ self.context.lotto_name / self.context.c.dir_allegati / self.attached_subdir / attached_value        
        attributes[self.attached_field] = attached_value
        
        try:
            self.layer.blockSignals(True) # blocca i segnali per evitare interazioni con altre funzioni
            self.layer.startEditing()
            for field, value in self.attributes.items():
                feature.setAttribute(field, value)
            feature.setAttribute(self.attached_field, attached_value)
            # Aggiorna la feature nel layer
            self.layer.updateFeature(feature)
            # print("Photo Editor Prima del commit")
            self.layer.commitChanges()
            # print("Photo Editor dopo del commit")
        except Exception as e:
            self.layer.rollBack()
            msg = f"Erorre nell'aggiornamento della feature al layer. {e}"
            print(msg)
            iface.messageBar().pushMessage("Error", msg, level=Qgis.Critical, duration=3)
        finally:
            self.layer.blockSignals(False)  # Assicura di sbloccare i segnali alla fine
    
        return True
    
    def save_pixmap(self, pixmap: QPixmap, file_path: Path, quality: int = 90):
        """Salva l'immagine nella directory con il nome corretto."""
        if pixmap.isNull():
            print("Errore: La QPixmap è vuota")
            return False

        # Assicurati che la directory esista
        file_path.parent.mkdir(parents=True, exist_ok=True)

        # Salva o sovrascrivi l'immagine
        try:
            result = pixmap.save(str(file_path), "JPEG", quality)
            return result
        except Exception as e:
            print(f"Errore nel salvataggio dell'immagine: {e}")
            return False   # aggiunge una feature al layer
        
    
    
    def reset(self, event=None):
        if self.point_tool:
            self.point_tool.reset()
        
        # Reimposta lo stato di editing
        self._mode = 'edit' 
        self._feature_editing = None
        
        return
    
     
    def get_layer_source_name(self, layer:QgsVectorLayer):
        # Verifica se il layer è un vettore
        if not(layer and isinstance(layer, QgsVectorLayer)):
            # msg = f"Nessun layer vettoriale attivo o layer non valido. layer_name: {layer.name()} layer_id: {layer.id()}."
            # print(msg)
            # iface.messageBar().pushMessage(u'get_layer_source_name', msg, level=Qgis.Critical)
            return
        
        # Ottieni la sorgente del provider del layer (es: "dbname='path_to_file.gpkg' table=\"table_name\" (geometry_column) sql=")
        provider_source = layer.source()
        # Usa una regex per estrarre il nome della tabella
        match = re.search(r'(?<=layername=)[^|]+', provider_source)
        if not match:
            # msg = f"Non è stato possibile determinare il nome originale del layer. layer_name: {layer.name()} layer_id: {layer.id()} in {provider_source}."
            # print(msg)
            # iface.messageBar().pushMessage(u'get_layer_source_name', msg, level=Qgis.Critical)
            return
        
        layer_name = match[0]
        # msg = f"get_layer_source_name -> layer_name: {layer.name()} layer_id: {layer.id()} layer_source_name: {layer_name}"
        # print(msg)
        
        return layer_name
    
# class PhotoManagerModeEnum(Enum):
#     EDIT = "edit"
#     ADD = "add"

# class PhotoManagerContext:
#     """Classe che gestisce il contesto per i workflow di aggiunta o modifica delle foto."""
    
#     def __init__(self, mode: PhotoManagerModeEnum, layer: QgsVectorLayer = None, feature: QgsFeature = None):
#         self.mode = mode
#         self.layer = layer
#         self.feature = feature
#         self.point = None
#         self.fid = None
#         self.file_path = None
#         self.attributes = {}
#         self.attached_field = None
#         self.attached_subdir = None
#         self.attached_type = None
#         self.image = None
        
#     def is_add_mode(self) -> bool:
#         """Verifica se il contesto è in modalità aggiunta."""
#         return self.mode == PhotoManagerModeEnum.ADD
    
#     def is_edit_mode(self) -> bool:
#         """Verifica se il contesto è in modalità modifica."""
#         return self.mode == PhotoManagerModeEnum.EDIT
    
#     def set_point(self, point: QgsPointXY):
#         """Imposta il punto per la modalità aggiunta."""
#         self.point = point
    
#     def set_feature_data(self, fid: int, attributes: dict):
#         """Imposta i dati della feature per entrambe le modalità."""
#         self.fid = fid
#         self.attributes = attributes
    
#     def set_attachment_info(self, field: str, subdir: str, file_type: str):
#         """Imposta le informazioni per gli allegati."""
#         self.attached_field = field
#         self.attached_subdir = subdir
#         self.attached_type = file_type
    
#     def set_file_path(self, file_path: Path):
#         """Imposta il percorso del file."""
#         self.file_path = file_path
    
#     def set_image(self, image: QImage):
#         """Imposta l'immagine corrente."""
#         self.image = image
    
#     def validate(self) -> bool:
#         """Valida che il contesto abbia tutti i dati necessari per la modalità corrente."""
#         if self.is_add_mode():
#             return self.point is not None and self.layer is not None
#         elif self.is_edit_mode():
#             return self.feature is not None and self.layer is not None
#         return False
    
#     def reset(self):
#         """Resetta il contesto."""
#         self.point = None
#         self.fid = None
#         self.file_path = None
#         self.attributes = {}
#         self.image = None