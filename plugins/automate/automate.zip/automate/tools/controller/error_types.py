"""
Tipi di errore strutturati per il sistema di validazione Controller.
Sostituisce l'utilizzo di dizionari generici con tipi strutturati e type-safe.
"""

# # 2. STANDARD LIBRARY
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Dict, Optional


class ErrorSeverity(Enum):
    """Livelli di severità per gli errori di validazione."""

    WARNING = "WARNING"
    ERROR = "ERROR"
    CRITICAL = "CRITICAL"


@dataclass
class ValidationError:
    """
    Rappresenta un errore di validazione strutturato.
    Sostituisce l'utilizzo di dizionari separati per tracciare errori.
    Supporta errori con geometrie associate per validazioni spaziali.
    """

    check_name: str
    layer_name: str
    feature_id: str
    field_name: str
    error_message: str
    severity: ErrorSeverity
    timestamp: datetime = field(default_factory=datetime.now)
    metadata: Dict[str, Any] = field(default_factory=dict)

    # Supporto geometrie per errori spaziali
    geometry: Optional[Any] = None  # Shapely geometry o None
    crs: Optional[str] = None  # EPSG code (es. "EPSG:3857") per la geometria

    def has_geometry(self) -> bool:
        """Verifica se l'errore ha una geometria associata."""
        return self.geometry is not None

    def is_spatial_error(self) -> bool:
        """Alias per has_geometry() per chiarezza semantica."""
        return self.has_geometry()

    def to_pipe_format(self) -> str:
        """
        Converte l'errore nel formato pipe-separated legacy per compatibilità.
        Formato: check_name|layer_name|feature_id|field_name|error_message
        """
        return f"{self.check_name}|{self.layer_name}|{self.feature_id}|{self.field_name}|{self.error_message}"

    def to_dict(self) -> Dict[str, Any]:
        """Converte l'errore in un dizionario per serializzazione."""
        return {
            "check_name": self.check_name,
            "layer_name": self.layer_name,
            "feature_id": self.feature_id,
            "field_name": self.field_name,
            "error_message": self.error_message,
            "severity": self.severity.value,
            "timestamp": self.timestamp.isoformat(),
            "metadata": self.metadata,
        }

    def get_geometry_library(self) -> Optional[str]:
        """Restituisce il nome della libreria geometrica rilevato automaticamente."""
        if self.geometry is None:
            return None
        
        # Rileva automaticamente dalla classe dell'oggetto geometry
        geometry_type = type(self.geometry).__name__
        module_name = type(self.geometry).__module__
        
        if "shapely" in module_name.lower():
            return "Shapely"
        elif "osgeo" in module_name.lower() or "ogr" in module_name.lower():
            return "OGR"
        elif "qgs" in geometry_type.lower():
            return "QGIS"
        else:
            return f"Unknown ({geometry_type})"

@dataclass
class ValidationContext:
    """Contesto per una sessione di validazione."""

    lotto_name: str
    gpkg_path: str
    validation_start: datetime = field(default_factory=datetime.now)
    validation_end: Optional[datetime] = None

    def mark_completed(self):
        """Segna la validazione come completata."""
        self.validation_end = datetime.now()

    @property
    def duration(self) -> Optional[float]:
        """Durata della validazione in secondi."""
        if self.validation_end:
            return (self.validation_end - self.validation_start).total_seconds()
        return None
