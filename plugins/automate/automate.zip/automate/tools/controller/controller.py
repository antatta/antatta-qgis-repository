# -*- coding: utf-8 -*-
"""
/***************************************************************************
 Controller
                                 A QGIS plugin
 The AUTOMATE plug-in
        begin                : 2024-09-23
        copyright            : (C) 2024 by Ing. Antonio Attadia
        email                : info.antatta@gmail.com
        git sha              : $Format:%H$
 ***************************************************************************/

Controller moderno per la validazione di dati geospaziali con architettura modulare.

Caratteristiche principali:
- Sistema di validatori auto-discovering con ValidatorRegistry
- Architettura modulare basata su BaseValidator e mixin patterns
- Delegatori automatici per compatibilità interfaccia legacy (check_*)
- ControllerContext condiviso per tutti i validators
- Sistema di reporting errori strutturato con ErrorReporter
- Supporto CLI/QGIS con import dinamici per compatibilità

Il Controller utilizza OGR per operazioni geometriche efficienti e supporta
validazioni su layers, fields, features, values, combinations geometriche, e controlli di qualità.

Aggiungere un nuovo validator richiede solo:
1. Creare un file in validators/ che eredita da BaseValidator
2. Decorare con @ValidatorRegistry.register("nome_validator")
3. Il sistema auto-discovery lo renderà disponibile come controller.check_nome_validator()
"""
# # 1. FUTURE IMPORTS
from __future__ import annotations

# # 3. THIRD-PARTY LIBRARIES
from PyQt5.QtCore import QThread, pyqtSignal
from osgeo import ogr

# # 4. PROJECT LIBRARIES
from core import AutomateContext

# # 5. LOCAL IMPORTS
from .error_reporter import ErrorReporter


class Controller(QThread):
    """
    Controller per la gestione dei processi di validazione.
    """

    msg_signal: pyqtSignal = pyqtSignal(str)

    def __init__(self, context: AutomateContext, parent=None):
        super(Controller, self).__init__(parent)
        
        self.context: AutomateContext = context
        
        # Sistema di reporting errori strutturato
        self.error_reporter = ErrorReporter(parent=self)
        self.error_reporter.set_context(context.lotto_name, str(context.lotto_gpkg_path))
        
        # Apri il file GPKG in modalità di sola lettura
        self.src_ds: ogr.DataSource = ogr.Open(context.lotto_gpkg_path.as_posix(), 0)
        
        # 🚀 SISTEMA VALIDATORS MODULARIZZATO
        self._initialize_validators()

        return

    def _initialize_validators(self):
        """
        Inizializza il sistema di validators modularizzato con auto-discovery.

        Importa automaticamente tutti i moduli validator nella directory validators/
        per triggare la registrazione automatica tramite i decorator @ValidatorRegistry.register.

        🎯 ZERO MAINTENANCE: Aggiungere un nuovo validator richiede solo creare il file!
        """
        try:

            # Import delle classi del sistema validator
            # L'import del package validators attiva automaticamente l'autodiscovery
            # tramite il sistema implementato in validators/__init__.py
            # # 5. LOCAL IMPORTS
            from .validators import (
                ControllerContext,
                ValidatorRegistry,
            )

            # Crea il context condiviso per tutti i validators
            print("🚀 Creazione context condiviso per i validators...")
            self.validator_context = ControllerContext(
                lotto_name=self.context.lotto_name,
                lotto_gpkg_path=self.context.lotto_gpkg_path,
                lotto_dir_path=self.context.lotto_dir_path,
                src_ds = self.src_ds,
                db=self.context.db,
                c=self.context.c,
                error_reporter=self.error_reporter,
                controller=self,  # Riferimento per permettere emissione segnali
            )

            # Carica tutti i validators registrati (auto-discovered)
            print("🚀 Creazione istanze dei validators...")
            self.validators = ValidatorRegistry.create_all_validators(
                self.validator_context
            )

            # 🎯 GENERA AUTOMATICAMENTE metodi delegatori check_*
            print("🚀 Generazione metodi delegatori check_* per i validators...")
            self._generate_validator_delegators()

            # Log validators disponibili (per debug)
            print(f"🚀 Validators auto-discovered: {len(self.validators)} disponibili")
            # 🎯
            for name in self.validators.keys():
                print(f"  ✅ {name}")

        except ImportError as e:
            print(f"⚠️ Validators non disponibili: {e}")
            self.validators = {}
        except Exception as e:
            print(f"❌ Errore inizializzazione validators: {e}")
            self.validators = {}
            # # 2. STANDARD LIBRARY
            import traceback

            traceback.print_exc()

    def _generate_validator_delegators(self):
        """
        Genera automaticamente metodi delegatori check_* per tutti i validators.

        Questo permette di chiamare controller.check_layer_sdi() che internamente
        chiama controller.validators["layer_sdi"].validate().

        Mantiene l'interfaccia tradizionale per CLI e compatibilità.
        """
        if not hasattr(self, "validators") or not self.validators:
            return

        for validator_name, validator_instance in self.validators.items():
            method_name = f"check_{validator_name}"

            # Crea il delegator dinamico
            def create_delegator(validator, name):
                def delegator_method(*args, **kwargs):
                    """Metodo delegator automatico per validator."""
                    try:
                        return validator.validate(*args, **kwargs)
                    except Exception as e:
                        print(f"❌ Errore in {name}: {e}")
                        return False

                return delegator_method

            # Genera il delegator con metadati appropriati
            delegator = create_delegator(validator_instance, method_name)
            delegator.__name__ = method_name
            
            # Genera docstring descrittivo dal validator
            validator_class_name = validator_instance.__class__.__name__
            validator_doc = getattr(validator_instance.__class__, '__doc__', '') or ''
            description = getattr(validator_instance, 'description', f'Controllo {validator_name}')
            
            delegator.__doc__ = f"""
            {description}
            
            Delegator automatico per: {validator_class_name}
            {validator_doc.strip() if validator_doc else ''}
            
            Returns:
                bool: True se la validazione passa, False altrimenti
            """.strip()

            # Imposta il metodo dinamico
            setattr(self, method_name, delegator)

    @property
    def validator_display_names(self) -> dict[str, str]:
        """
        Property che restituisce mapping validator_name -> display_name.
        
        Utilizzata da ControllerDialog per creare checkbox con nomi user-friendly.
        Calcolo on-demand per garantire sincronizzazione con ValidatorRegistry.
        
        Returns:
            dict[str, str]: Dizionario {validator_name: display_name}
                           Es: {"mandatory_fields": "Campi obbligatori", "rg_cod": "rg_cod"}
        """
        if not hasattr(self, "validators") or not self.validators:
            return {}
            
        from .validators import ValidatorRegistry
        
        display_names = {}
        for validator_name in self.validators.keys():
            display_name = ValidatorRegistry.get_validator_display_name(validator_name)
            display_names[validator_name] = display_name or validator_name
            
        return display_names

    @property
    def validator_descriptions(self) -> dict[str, str]:
        """
        Property che restituisce mapping validator_name -> description.
        
        Utilizzata per tooltip e descrizioni estese.
        
        Returns:
            dict[str, str]: Dizionario {validator_name: description}
        """
        if not hasattr(self, "validators") or not self.validators:
            return {}
            
        from .validators import ValidatorRegistry
        
        descriptions = {}
        for validator_name in self.validators.keys():
            validator_class = ValidatorRegistry.get_validator_class(validator_name)
            if validator_class:
                description = getattr(validator_class, 'description', f'Controllo {validator_name}')
                descriptions[validator_name] = description
            else:
                descriptions[validator_name] = f'Controllo {validator_name}'
                
        return descriptions

    def clear(self):
        """
        Pulisce i dati e chiude le connessioni.
        Enhanced per includere pulizia ErrorReporter.
        """
        # Pulisci ErrorReporter strutturato
        if hasattr(self, "error_reporter"):
            self.error_reporter.clear()

        # Chiudi la connessione GDAL se aperta
        if hasattr(self, "src_ds") and self.src_ds is not None:
            # Nota: GDAL gestisce automaticamente la chiusura quando l'oggetto va out of scope
            del self.src_ds

        # Chiudi la connessione al database se presente
        if hasattr(self, "db") and self.db is not None:
            try:
                # DatabaseConnect potrebbe non avere metodi di chiusura espliciti
                # Lascia che Python gestisca automaticamente la pulizia
                pass
            except Exception:
                pass  # Ignora errori di chiusura

        return


def main():
    """
    Funzione main per test semplici del Controller.
    Per l'interfaccia CLI completa, utilizzare controller_cli.py
    """
    print("Controller caricato correttamente.")
    print("Per l'utilizzo da linea di comando, usa: python controller_cli.py --help")


if __name__ == "__main__":
    main()
