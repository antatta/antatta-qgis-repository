# -*- coding: utf-8 -*-
"""
Controller module for AUTOMATE plugin v2.0
Contains quality control, validation, and controller dialog.
"""
from .controller import Controller
from .controller_dialog import ControllerDialog
from .validators import ValidatorRegistry


# Export main classes for external use
__all__ = ['Controller', 'ControllerDialog', 'ValidatorRegistry']