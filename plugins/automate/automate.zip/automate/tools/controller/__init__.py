# -*- coding: utf-8 -*-
"""
Controller module for AUTOMATE plugin v2.0
Contains quality control, validation, and controller dialog.
"""
from .controller import Controller


# Export main classes for external use
__all__ = ['Controller']