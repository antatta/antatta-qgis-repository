"""
Sistema di reporting centralizzato per errori di validazione.
Gestisce la collezione, il filtraggio e l'export degli errori in formato strutturato.
"""

# # 2. STANDARD LIBRARY
import csv
from pathlib import Path
from typing import Any, Dict, List, Optional

# # 3. THIRD-PARTY LIBRARIES
from osgeo import ogr, osr
from PyQt5.QtCore import QObject, pyqtSignal

# # 5. LOCAL IMPORTS
from .error_types import ErrorSeverity, ValidationContext, ValidationError


class ErrorReporter(QObject):
    """
    Gestore centralizzato per errori di validazione con supporto segnali Qt.
    Sostituisce la manipolazione diretta del dizionario self.errori.
    """

    # Segnale emesso quando viene aggiunto un nuovo errore
    error_added = pyqtSignal(ValidationError)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.errors: List[ValidationError] = []
        self.context: Optional[ValidationContext] = None

    def set_context(self, lotto_name: str, gpkg_path: str):
        """Imposta il contesto di validazione."""
        self.context = ValidationContext(lotto_name=lotto_name, gpkg_path=gpkg_path)

    def add_error(self, error: ValidationError):
        """
        Aggiunge un nuovo errore alla collezione.

        Gestisce automaticamente sia errori tabellari che geometrici
        in base alla presenza della geometria nell'oggetto ValidationError.
        """
        self.errors.append(error)
        self.error_added.emit(error)

    def get_errors_by_severity(self, severity: ErrorSeverity) -> List[ValidationError]:
        """Filtra errori per livello di severità."""
        return [error for error in self.errors if error.severity == severity]

    def get_errors_by_check(self, check_name: str) -> List[ValidationError]:
        """Filtra errori per nome del check."""
        return [error for error in self.errors if error.check_name == check_name]

    def get_errors_by_layer(self, layer_name: str) -> List[ValidationError]:
        """Filtra errori per layer."""
        return [error for error in self.errors if error.layer_name == layer_name]

    def get_all_errors(self) -> List[ValidationError]:
        """Restituisce tutti gli errori."""
        return self.errors.copy()

    def get_geometric_errors(self) -> List[ValidationError]:
        """Filtra e restituisce solo errori con geometrie associate."""
        return [error for error in self.errors if error.has_geometry()]

    def get_non_geometric_errors(self) -> List[ValidationError]:
        """Filtra e restituisce solo errori senza geometrie."""
        return [error for error in self.errors if not error.has_geometry()]

    def get_error_summary(self) -> Dict[str, int]:
        """Restituisce un riepilogo degli errori per severità."""
        summary = {severity.value: 0 for severity in ErrorSeverity}
        for error in self.errors:
            summary[error.severity.value] += 1
        return summary

    def export_to_csv(self, output_path: Path):
        """Esporta tutti gli errori in formato CSV."""
        with open(output_path, "w", newline="", encoding="utf-8") as csvfile:
            fieldnames = [
                "check_name",
                "layer_name",
                "feature_id",
                "field_name",
                "error_message",
                "severity",
                "timestamp",
            ]
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)

            writer.writeheader()
            for error in self.errors:
                writer.writerow(
                    {
                        "check_name": error.check_name,
                        "layer_name": error.layer_name,
                        "feature_id": error.feature_id,
                        "field_name": error.field_name,
                        "error_message": error.error_message,
                        "severity": error.severity.value,
                        "timestamp": error.timestamp.isoformat(),
                    }
                )

    def export_to_gpkg(
        self, output_path: Path, base_layer_name: str = "validation_errors"
    ):
        """
        Esporta errori in formato GPKG con layer separati per errori tabulari e spaziali.

        Crea:
        - {base_layer_name}_tabular: Errori senza geometria (tabella)
        - {base_layer_name}_points: Errori con geometrie punto
        - {base_layer_name}_lines: Errori con geometrie lineari
        - {base_layer_name}_polygons: Errori con geometrie poligonali

        Args:
            output_path: Percorso del file GPKG di output
            base_layer_name: Nome base per i layer (default: 'validation_errors')
        """
        if not self.errors:
            return

        # Separazione errori per tipo
        tabular_errors = self.get_non_geometric_errors()
        geometric_errors = self.get_geometric_errors()

        # Ottieni il dataset GPKG usando l'helper
        ds = self._get_or_create_gpkg_dataset(output_path)

        try:
            # Export errori tabulari
            if tabular_errors:
                self._export_tabular_errors_to_gpkg(
                    ds, f"{base_layer_name}_tabular", tabular_errors
                )

            # Export errori geometrici raggruppati per tipo
            if geometric_errors:
                self._export_geometric_errors_to_gpkg(
                    ds, base_layer_name, geometric_errors
                )

        finally:
            ds = None

    def _export_tabular_errors_to_gpkg(
        self, ds: ogr.DataSource, layer_name: str, errors: List[ValidationError]
    ):
        """Esporta errori tabulari (senza geometria) in un layer GPKG."""
        # Rimuovi il layer se esiste già
        for i in range(ds.GetLayerCount()):
            if ds.GetLayerByIndex(i).GetName() == layer_name:
                ds.DeleteLayer(i)
                break

        # Crea il layer tabellare (senza geometria)
        layer = ds.CreateLayer(layer_name, geom_type=ogr.wkbNone)
        if layer is None:
            raise RuntimeError(f"Impossibile creare il layer: {layer_name}")

        # Definisci i campi standard
        self._create_standard_fields(layer)

        # Ottieni la definizione del layer per creare le feature
        layer_defn = layer.GetLayerDefn()

        # Inserisci gli errori come feature
        for error in errors:
            feature = ogr.Feature(layer_defn)
            self._populate_feature_fields(feature, error)

            if layer.CreateFeature(feature) != ogr.OGRERR_NONE:
                raise RuntimeError("Errore nella creazione della feature")

            feature = None

    def _export_geometric_errors_to_gpkg(
        self, ds: ogr.DataSource, base_name: str, errors: List[ValidationError]
    ):
        """Esporta errori geometrici raggruppati per check_name in layer separati."""
        # # 2. STANDARD LIBRARY
        from collections import defaultdict

        # Raggruppa errori per check_name
        errors_by_check = defaultdict(list)
        for error in errors:
            if error.geometry:
                errors_by_check[error.check_name].append(error)

        # Per ogni check, crea un singolo layer (senza separare per tipo geometria)
        for check_name, check_errors in errors_by_check.items():
            # Determina il tipo di geometria prevalente o usa Mixed se ci sono tipi diversi
            geom_types = set()
            for error in check_errors:
                geom = error.geometry
                if geom:
                    # Converti la geometria in OGR per determinare il tipo
                    ogr_geom = self._convert_geometry_to_ogr(geom, error.get_geometry_library())
                    if ogr_geom:
                        geom_type = ogr_geom.GetGeometryType()
                        if geom_type in [ogr.wkbPoint, ogr.wkbMultiPoint, ogr.wkbPoint25D, ogr.wkbMultiPoint25D]:
                            geom_types.add("Point")
                        elif geom_type in [ogr.wkbLineString, ogr.wkbMultiLineString, ogr.wkbLineString25D, ogr.wkbMultiLineString25D]:
                            geom_types.add("LineString")
                        elif geom_type in [ogr.wkbPolygon, ogr.wkbMultiPolygon, ogr.wkbPolygon25D, ogr.wkbMultiPolygon25D]:
                            geom_types.add("Polygon")

            # Scegli il tipo di geometria OGR in base al contenuto
            if len(geom_types) == 1:
                # Un solo tipo di geometria
                geom_type_str = list(geom_types)[0]
                if geom_type_str == "Point":
                    ogr_geom_type = ogr.wkbPoint
                elif geom_type_str == "LineString":
                    ogr_geom_type = ogr.wkbLineString
                else:  # Polygon
                    ogr_geom_type = ogr.wkbPolygon
            else:
                # Tipi misti, usa geometria generica
                ogr_geom_type = ogr.wkbUnknown

            # Crea un singolo layer per il check
            self._create_geometric_layer(ds, check_name, ogr_geom_type, check_errors)

    def _create_geometric_layer(
        self,
        ds: ogr.DataSource,
        layer_name: str,
        geom_type: int,
        errors: List[ValidationError],
    ):
        """Crea un layer geometrico specifico."""
        # Rimuovi il layer se esiste già
        for i in range(ds.GetLayerCount()):
            if ds.GetLayerByIndex(i).GetName() == layer_name:
                ds.DeleteLayer(i)
                break

        # Determina il CRS dal primo errore che ne ha uno
        spatial_ref = None
        for error in errors:
            if error.crs:
                spatial_ref = osr.SpatialReference()
                if error.crs.startswith("EPSG:"):
                    epsg_code = int(error.crs.split(":")[1])
                    spatial_ref.ImportFromEPSG(epsg_code)
                break

        # Crea il layer con geometria
        layer = ds.CreateLayer(layer_name, srs=spatial_ref, geom_type=geom_type)
        if layer is None:
            raise RuntimeError(f"Impossibile creare il layer geometrico: {layer_name}")

        # Definisci i campi standard
        self._create_standard_fields(layer)

        # Ottieni la definizione del layer
        layer_defn = layer.GetLayerDefn()

        # Inserisci gli errori con geometria
        for error in errors:
            feature = ogr.Feature(layer_defn)
            self._populate_feature_fields(feature, error)
            
            # Aggiungi geometria convertita in base alla libreria
            if error.geometry:
                geometry_library = error.get_geometry_library()
                ogr_geom = self._convert_geometry_to_ogr(error.geometry, geometry_library)
                if ogr_geom:
                    feature.SetGeometry(ogr_geom)

            if layer.CreateFeature(feature) != ogr.OGRERR_NONE:
                raise RuntimeError("Errore nella creazione della feature geometrica")

            feature = None

    def _convert_geometry_to_ogr(self, geometry, geometry_library: Optional[str]) -> Optional[ogr.Geometry]:
        """
        Converte una geometria in oggetto OGR in base alla libreria di origine.
        
        Args:
            geometry: L'oggetto geometria (QGIS, OGR, etc.) - Shapely non più supportato
            geometry_library: Nome della libreria ("QGIS", "OGR", etc.)
            
        Returns:
            ogr.Geometry o None se la conversione fallisce
        """
        if not geometry:
            return None
            
        try:
            # Strategia unificata: estrai WKT da qualsiasi libreria, poi crea OGR
            wkt = self._extract_wkt_from_geometry(geometry, geometry_library)
            if wkt:
                return ogr.CreateGeometryFromWkt(wkt)
            else:
                return None
                    
        except Exception as e:
            print(f"⚠️ Errore conversione geometria {geometry_library}: {e}")
            return None

    def _extract_wkt_from_geometry(self, geometry, geometry_library: Optional[str]) -> Optional[str]:
        """Estrae WKT da una geometria di qualsiasi libreria."""
        # Shapely non è più supportato - usiamo solo QGIS e OGR
        if geometry_library == "QGIS":
            # QGIS: prova asWkt() poi wkt
            if hasattr(geometry, 'asWkt'):
                return geometry.asWkt()
            elif hasattr(geometry, 'wkt'):
                return geometry.wkt
                
        elif geometry_library == "OGR":
            # OGR: usa ExportToWkt()
            if hasattr(geometry, 'ExportToWkt'):
                return geometry.ExportToWkt()
                
        # Fallback generico per qualsiasi geometria
        if hasattr(geometry, 'wkt'):
            return geometry.wkt
        elif hasattr(geometry, 'asWkt'):
            return geometry.asWkt()
        elif hasattr(geometry, 'ExportToWkt'):
            return geometry.ExportToWkt()
            
        return None

    def _get_or_create_gpkg_dataset(self, output_path: Path) -> ogr.DataSource:
        """Helper method per creare o aprire un dataset GPKG."""
        driver = ogr.GetDriverByName("GPKG")
        if driver is None:
            raise RuntimeError("Driver GPKG non disponibile")

        # Crea o apre il dataset GPKG
        if output_path.exists():
            ds = driver.Open(str(output_path), 1)
        else:
            ds = driver.CreateDataSource(str(output_path))

        if ds is None:
            raise RuntimeError(f"Impossibile creare/aprire il file GPKG: {output_path}")

        return ds

    def _create_standard_fields(self, layer: ogr.Layer):
        """Crea i campi standard per tutti i layer di errori."""
        fields = [
            ("check_name", ogr.OFTString, 255),
            ("layer_name", ogr.OFTString, 255),
            ("feature_id", ogr.OFTString, 50),
            ("field_name", ogr.OFTString, 255),
            ("error_message", ogr.OFTString, 1000),
            ("severity", ogr.OFTString, 20),
            ("timestamp", ogr.OFTString, 30),
            ("lotto_name", ogr.OFTString, 255),
            ("gpkg_path", ogr.OFTString, 1000),
        ]

        for field_name, field_type, width in fields:
            field_defn = ogr.FieldDefn(field_name, field_type)
            if width > 0:
                field_defn.SetWidth(width)
            if layer.CreateField(field_defn) != ogr.OGRERR_NONE:
                raise RuntimeError(f"Impossibile creare il campo: {field_name}")

    def _populate_feature_fields(self, feature: ogr.Feature, error: ValidationError):
        """Popola i campi standard di una feature con i dati dell'errore."""
        feature.SetField("check_name", error.check_name)
        feature.SetField("layer_name", error.layer_name)
        feature.SetField("feature_id", error.feature_id)
        feature.SetField("field_name", error.field_name)
        feature.SetField("error_message", error.error_message)
        feature.SetField("severity", error.severity.value)
        feature.SetField("timestamp", error.timestamp.isoformat())

        # Aggiungi informazioni di contesto se disponibili
        if self.context:
            feature.SetField("lotto_name", self.context.lotto_name)
            feature.SetField("gpkg_path", self.context.gpkg_path)

    def export_errors(self, output_path: Path, format_type: str = "gpkg"):
        """
        Metodo di utilità per esportare gli errori nel formato desiderato.

        Args:
            output_path: Percorso del file di output
            format_type: Formato di export ('gpkg' o 'csv')
        """
        if format_type.lower() == "gpkg":
            self.export_to_gpkg(output_path)
        elif format_type.lower() == "csv":
            self.export_to_csv(output_path)
        else:
            raise ValueError(
                f"Formato non supportato: {format_type}. Usare 'gpkg' o 'csv'"
            )

    def clear(self):
        """Pulisce tutti gli errori e il contesto."""
        self.errors.clear()
        if self.context:
            self.context.mark_completed()
        self.context = None

    def has_errors(self) -> bool:
        """Verifica se ci sono errori registrati."""
        return len(self.errors) > 0

    def has_critical_errors(self) -> bool:
        """Verifica se ci sono errori critici."""
        return any(error.severity == ErrorSeverity.CRITICAL for error in self.errors)

    def get_stats(self) -> Dict[str, Any]:
        """Restituisce statistiche complete degli errori."""
        stats = {
            "total_errors": len(self.errors),
            "by_severity": self.get_error_summary(),
            "by_check": {},
            "by_layer": {},
            "has_critical": self.has_critical_errors(),
        }

        # Conteggio per check e layer in un singolo loop
        for error in self.errors:
            # Conteggio per check
            check_name = error.check_name
            if check_name not in stats["by_check"]:
                stats["by_check"][check_name] = 0
            stats["by_check"][check_name] += 1

            # Conteggio per layer
            layer_name = error.layer_name
            if layer_name not in stats["by_layer"]:
                stats["by_layer"][layer_name] = 0
            stats["by_layer"][layer_name] += 1

        # Durata validazione se disponibile
        if self.context and self.context.duration:
            stats["validation_duration"] = self.context.duration

        return stats
