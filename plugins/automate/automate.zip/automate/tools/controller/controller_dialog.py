# -*- coding: utf-8 -*-
"""
/***************************************************************************
 ControllerDialog
                                 A QGIS plugin
 The AUTOMATE plug-in
                             -------------------
        begin                : 2024-09-23
        copyright            : (C) 2024 by Ing. Antonio Attadia
        email                : info.antatta@gmail.com
        git sha              : $Format:%H$
 ***************************************************************************/
 GUI for controller
"""
# # 2. STANDARD LIBRARY
import os
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Optional

# # 3. THIRD-PARTY LIBRARIES
from qgis.core import Qgis, QgsProject
from qgis.gui import QgsCheckableComboBox
from qgis.PyQt import QtWidgets, uic
from qgis.PyQt.QtCore import QCoreApplication, Qt
from qgis.utils import iface

# # 4. PROJECT LIBRARIES
from core import CONST
from core.utils import last_file

# # 5. LOCAL IMPORTS
from .controller import Controller

# This loads your .ui file so that PyQt can populate your plugin with the elements from Qt Designer
FORM_CLASS, _ = uic.loadUiType(
    os.path.join(os.path.dirname(__file__), "ControllerDialog.ui")
)


class ControllerDialog(QtWidgets.QDialog, FORM_CLASS):
    def __init__(self, parent=None):
        """Constructor."""
        super(ControllerDialog, self).__init__(parent)
        # Set up the user interface from Designer through FORM_CLASS.
        # After self.setupUi() you can access any designer object by doing
        # self.<objectname>, and you can use autoconnect slots - see
        # http://qt-project.org/doc/qt-4.8/designer-using-a-ui-file.html
        # #widgets-and-dialogs-with-auto-connect
        self.setupUi(self)

        # Nessuna variabile hardcoded! Usa CONST direttamente nei metodi

        self.button_box: QtWidgets.QDialogButtonBox
        self.button_box.button(QtWidgets.QDialogButtonBox.Ok).setText("Run")
        self.button_box.button(QtWidgets.QDialogButtonBox.Ok).clicked.connect(self.run)
        self.button_box.button(QtWidgets.QDialogButtonBox.Cancel).clicked.connect(
            self.cancel
        )
        self.button_box.button(QtWidgets.QDialogButtonBox.Save).clicked.connect(
            self.save
        )
        self.button_box.button(QtWidgets.QDialogButtonBox.Reset).clicked.connect(
            self.button_box_reset
        )
        self.button_box.button(QtWidgets.QDialogButtonBox.YesToAll).clicked.connect(
            self.button_box_all
        )

        self.textEdit: QtWidgets.QTextEdit
        self.textEdit.setReadOnly(True)

        self.project: QgsProject = QgsProject.instance()
        self.home_path: Path = Path(self.project.homePath())
        self.controller: Optional[Controller] = self.initObj()
        self.discover_checks()
        return

    def discover_checks(self):
        """Scopri i controlli disponibili nel controller con display names user-friendly"""

        if self.controller:
            # Ottieni i display_names e descriptions dal Controller
            display_names = self.controller.validator_display_names
            descriptions = self.controller.validator_descriptions
            
            # Crea lista di tuple (method_name, display_name, description) per i controlli disponibili
            available_checks = []
            for validator_name, display_name in display_names.items():
                method_name = f"check_{validator_name}"
                description = descriptions.get(validator_name, f"Controllo {validator_name}")
                # Verifica che il metodo esista davvero nel controller
                if hasattr(self.controller, method_name) and callable(getattr(self.controller, method_name)):
                    available_checks.append((method_name, display_name, description))
            
            # Ordina alfabeticamente per display_name (ignorando maiuscole/minuscole)
            available_checks.sort(key=lambda x: x[1].lower())
            
            self._setComboBox(available_checks)
            return available_checks

    def _setComboBox(self, checkList: list[tuple[str, str, str]]):
        """
        Popola la ComboBox con controlli usando display names user-friendly.
        
        Args:
            checkList: Lista di tuple (method_name, display_name, description)
        """
        for method_name, display_name, description in checkList:
            self.addChekItemCB(method_name, display_name, description)
        return

    def addChekItemCB(self, method_name: str, display_name: str, description: Optional[str] = None):
        """
        Aggiunge un item alla ComboBox con display_name visibile e method_name come userData.
        
        Args:
            method_name: Nome tecnico del metodo (es. "check_mandatory_fields")
            display_name: Nome user-friendly (es. "Campi obbligatori")
            description: Descrizione completa per tooltip (opzionale)
        """
        self.mComboBox: QgsCheckableComboBox
        # Mostra display_name all'utente, ma store method_name per l'esecuzione
        self.mComboBox.addItemWithCheckState(display_name, Qt.Unchecked, method_name)
        
        # Imposta il tooltip se la descrizione è fornita
        if description:
            # Ottieni l'indice dell'item appena aggiunto
            index = self.mComboBox.count() - 1
            # Imposta il tooltip per l'item
            self.mComboBox.setItemData(index, description, Qt.ToolTipRole)

    def button_box_reset(self):
        self.mComboBox.deselectAllOptions()

    def button_box_all(self):
        self.mComboBox.selectAllOptions()

    def initObj(self):
        lotto: str = self.project.baseName()[: CONST["cifre_max_nome_lotto"]]
        if not lotto:
            msg = "Non è stato possibile individuare il nome del lotto dal progetto aperto"
            self.write(msg)
            iface.messageBar().pushMessage("ControllerDialog", msg, level=Qgis.Critical)
            return None

        lotto_dir = self.home_path / lotto
        lotto_path = last_file(lotto_dir, lotto, "gpkg")

        if not lotto_path.exists():
            msg = f"Non è stato individuato il file {lotto_path=}"
            self.write(msg)
            iface.messageBar().pushMessage("ControllerDialog", msg, level=Qgis.Critical)
            return None

        return Controller(lotto, lotto_path, self)

    def run(self):
        if not self.controller:
            return

        # Disabilita i pulsanti durante l'esecuzione
        self.button_box.button(QtWidgets.QDialogButtonBox.Ok).setEnabled(False)
        self.button_box.button(QtWidgets.QDialogButtonBox.Save).setEnabled(False)
        self.button_box.button(QtWidgets.QDialogButtonBox.Reset).setEnabled(False)
        self.button_box.button(QtWidgets.QDialogButtonBox.YesToAll).setEnabled(False)

        try:
            self.controller.msg_signal.connect(self.write)

            # ciclo sui controlli selezionati - usa userData per ottenere method_name
            selected_methods = []
            selected_displays = []
            
            # Ottieni method_name dai userData degli item selezionati
            for i in range(self.mComboBox.count()):
                if self.mComboBox.itemCheckState(i) == Qt.Checked:
                    display_name = self.mComboBox.itemText(i)
                    method_name = self.mComboBox.itemData(i)  # userData contiene method_name
                    selected_methods.append(method_name)
                    selected_displays.append(display_name)
            
            total_checks = len(selected_methods)
            self.write(f"🚀 Inizio esecuzione di {total_checks} controlli...")
            QCoreApplication.processEvents()  # Aggiorna l'UI immediatamente

            for i, (method_name, display_name) in enumerate(zip(selected_methods, selected_displays), 1):
                self.write(f"🔍 [{i}/{total_checks}] Avvio controllo: {display_name}")

                func = getattr(self.controller, method_name, None)
                # Verifico che la funzione esista nella classe prima di eseguirla
                if not callable(func):
                    self.write(
                        f"❌ Funzione {method_name} non trovata! Non è possibile effettuare il controllo. (controller.py modificato?)"
                    )
                    continue

                try:
                    result = func()
                    if result:
                        self.write(f"✅ Controllo {display_name} superato")
                    else:
                        self.write(
                            f"❌ Controllo {display_name} NON superato. Effettua le dovute correzioni"
                        )
                except Exception as e:
                    self.write(
                        f"🟡 Si è verificato un errore nell'esecuzione di {display_name}. {e}"
                    )

                # Piccola pausa per permettere l'aggiornamento dell'UI
                time.sleep(0.1)
                QCoreApplication.processEvents()

            self.write(f"🏁 Controlli completati! Elaborati {total_checks} controlli.")

        finally:
            # Riabilita i pulsanti al termine dell'esecuzione
            self.button_box.button(QtWidgets.QDialogButtonBox.Ok).setEnabled(True)
            self.button_box.button(QtWidgets.QDialogButtonBox.Save).setEnabled(True)
            self.button_box.button(QtWidgets.QDialogButtonBox.Reset).setEnabled(True)
            self.button_box.button(QtWidgets.QDialogButtonBox.YesToAll).setEnabled(True)

        return

    def save(self):
        if not self.controller:
            return
        # Salvataggio report errori su file CSV
        error_csv_path = self.home_path / CONST["check_csv_file"]
        try:
            # Usa il nuovo ErrorReporter se disponibile
            if (
                hasattr(self.controller, "error_reporter")
                and self.controller.error_reporter.has_errors()
            ):
                # Export structured con metadata ricchi
                self.controller.error_reporter.export_to_csv(error_csv_path)
                self.write(f"💾 Salvato report errori in {error_csv_path.name}")

                # Genera report statistiche
                stats = self.controller.error_reporter.get_stats()
                stats_text = self._format_error_statistics(stats)
                self.write(f"📊 Statistiche errori:\n{stats_text}")

            elif (
                not hasattr(self.controller, "error_reporter")
                or not self.controller.error_reporter.has_errors()
            ):
                self.write(
                    "✨ Nessun errore trovato - Validazione completata con successo!"
                )
        except Exception as e:
            self.write(
                f"❌ Si è verificato un errore nel salvataggio del report errori {error_csv_path.name}. {e}"
            )

        # Salvataggio report errori su file GPKG
        error_gpkg_path = self.home_path / CONST["check_gpkg_file"]
        try:
            # report errori di validazione
            if (
                hasattr(self.controller, "error_reporter")
                and self.controller.error_reporter.has_errors()
            ):
                self.controller.error_reporter.export_to_gpkg(error_gpkg_path)
                self.write(
                    f"💾 Salvato report errori completo in {error_gpkg_path.name}"
                )

        except Exception as e:
            self.write(
                f"❌ Si è verificato un errore nel salvataggio del report errori {error_gpkg_path.name}. {e}"
            )
        return

    def cancel(self):
        """
        Cancella l'esecuzione e pulisce le risorse.
        """
        if self.controller is not None:
            # Pulisci i dati
            self.controller.clear()

            # Disconnetti i segnali
            try:
                self.controller.msg_signal.disconnect()
            except:
                pass

        # Pulisci l'output
        self.textEdit.clear()
        return

    def write(self, text: str):
        text = text.strip()  # Rimuovi spazi vuoti all'inizio e alla fine
        if text:
            current_text = self.textEdit.toPlainText()
            time = datetime.now()
            msg = f"{time.strftime('%Y.%m.%d %H:%M:%S.%f')[:-3]}|{text}"
            if current_text.endswith("\n"):
                self.textEdit.insertPlainText(msg)
            else:
                self.textEdit.append(msg)

            # Forza l'aggiornamento dell'interfaccia utente
            self.textEdit.repaint()
            QCoreApplication.processEvents()

            # Scorre automaticamente alla fine per mostrare l'ultimo messaggio
            scrollbar = self.textEdit.verticalScrollBar()
            scrollbar.setValue(scrollbar.maximum())

    def clear(self):
        """
        Pulisce tutto il contenuto del widget textEdit.
        """
        self.textEdit.clear()

    def _format_error_statistics(self, stats: dict) -> str:
        """
        Formatta le statistiche degli errori in modo leggibile per l'interfaccia.
        """
        lines = []
        lines.append(f"   📊 Totale errori: {stats['total_errors']}")

        # Statistiche per severità
        if stats["by_severity"]:
            lines.append("   🎯 Per severità:")
            for severity, count in stats["by_severity"].items():
                if count > 0:
                    icon = {"CRITICAL": "🔴", "ERROR": "🟡", "WARNING": "🔵"}.get(
                        severity, "⚫"
                    )
                    lines.append(f"      {icon} {severity}: {count}")

        # Top 5 controlli con più errori
        if stats["by_check"]:
            top_checks = sorted(
                stats["by_check"].items(), key=lambda x: x[1], reverse=True
            )[:5]
            lines.append("   🔍 Top controlli con errori:")
            for check, count in top_checks:
                lines.append(f"      • {check}: {count}")

        # Top 5 layer con più errori
        if stats["by_layer"]:
            top_layers = sorted(
                stats["by_layer"].items(), key=lambda x: x[1], reverse=True
            )[:5]
            lines.append("   🗺️ Top layer con errori:")
            for layer, count in top_layers:
                lines.append(f"      • {layer}: {count}")

        # Indicatore errori critici
        if stats.get("has_critical", False):
            lines.append(
                "   ⚠️ ATTENZIONE: Presenti errori CRITICI che richiedono intervento immediato!"
            )

        return "\n".join(lines)

    def show_error_summary(self):
        """
        Mostra un riepilogo degli errori nell'interfaccia utente.
        Utile per chiamare durante l'esecuzione dei controlli.
        """
        if not self.controller or not hasattr(self.controller, "error_reporter"):
            return

        if self.controller.error_reporter.has_errors():
            stats = self.controller.error_reporter.get_stats()
            summary = self._format_error_statistics(stats)
            self.write(f"📈 Riepilogo errori corrente:\n{summary}")
        else:
            self.write("✅ Nessun errore rilevato finora")

    def closeEvent(self, event):
        """
        Gestisce la chiusura del dialog e pulisce le risorse.
        """
        if self.controller is not None:
            # Disconnetti i segnali per evitare riferimenti circolari
            try:
                self.controller.msg_signal.disconnect()
            except:
                pass  # Il segnale potrebbe non essere connesso

            # Pulisci i dati del controller
            self.controller.clear()

            # Se il controller è un QThread, terminalo correttamente
            if hasattr(self.controller, "terminate"):
                self.controller.terminate()
                self.controller.wait()  # Aspetta che il thread termini

            # Rimuovi il riferimento
            self.controller = None

        # Chiama il metodo padre per completare la chiusura
        super().closeEvent(event)
