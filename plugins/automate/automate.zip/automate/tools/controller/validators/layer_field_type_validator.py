# -*- coding: utf-8 -*-
"""
Layer Field Type Validator - Validator per controlli sui tipi di campo.
Verifica che i campi di ogni layer abbiano i tipi corretti come definiti nel database.
"""
# # 1. FUTURE IMPORTS
from __future__ import annotations

# # 5. LOCAL IMPORTS
from ..error_types import ErrorSeverity
from . import ControllerContext, ValidatorRegistry
from .base_validator import BaseValidator


@ValidatorRegistry.register
class LayerFieldTypeValidator(BaseValidator):
    """
    Validator per verificare i tipi di campo nei layer SDI.

    Controlla che i campi di ogni layer abbiano i tipi corretti
    come definiti nel database di configurazione.
    """
    
    # Class variables per metadata (nuovo sistema)
    name: str = "layer_field_type"
    description: str = "Verifica i tipi di campo nei layer SDI"
    display_name: str = "tipo campo del layer"
    
    def __init__(self, context: ControllerContext):
        super().__init__(context)

    def validate(self) -> bool:
        """
        Verifica i tipi di campo nei layer SDI.

        Args:
            layers_sdi: Lista custom di layer da verificare.
                       Se None, usa la lista dal context

        Returns:
            bool: True se tutti i tipi sono corretti, False altrimenti
        """
        check = True
        
        layers_sdi = self.get_sdi_layers()

        # Verifica ogni layer nella lista
        for layer in layers_sdi:
            if not self.layer_exists(layer):
                continue

            # Ottieni i campi e i tipi previsti dal database
            expected_fields = []
            try:
                expected_fields = self.context.db.get_layer_fields_type("", layer)
            except Exception as e:
                self.add_error(
                    layer_name=layer,
                    fid="*",
                    field_name="*",
                    message=f"Errore ottenimento tipi campo: {e}",
                    severity=ErrorSeverity.ERROR,
                )
                check = False
                continue

            if not expected_fields:
                continue

            # Ottieni la definizione del layer dal GPKG
            layer_obj = self.get_lotto_layer(layer)
            if not layer_obj:
                self.add_error(
                    layer_name=layer,
                    fid="*",
                    field_name="*",
                    message="Layer non trovato nel GPKG",
                    severity=ErrorSeverity.ERROR,
                )
                check = False
                continue

            layer_definition = layer_obj.GetLayerDefn()

            # Crea dizionario dei campi presenti nel layer con i loro tipi
            actual_fields = {}
            for i in range(layer_definition.GetFieldCount()):
                field_defn = layer_definition.GetFieldDefn(i)
                field_name = field_defn.GetName()
                field_type = field_defn.GetTypeName()
                actual_fields[field_name] = field_type

            # Verifica che i campi e i tipi corrispondano
            for field, expected_type in expected_fields:
                if field not in actual_fields:
                    self.add_error(
                        layer_name=layer,
                        fid="*",
                        field_name=field,
                        message="Campo mancante",
                        severity=ErrorSeverity.ERROR,
                        metadata={
                            "expected_type": expected_type,
                            "validation_type": "missing_field",
                        },
                    )
                    check = False

                elif actual_fields[field] != expected_type:
                    self.add_error(
                        layer_name=layer,
                        fid="*",
                        field_name=field,
                        message=f"Il campo ha un tipo errato: {actual_fields[field]} invece di {expected_type}",
                        severity=ErrorSeverity.ERROR,
                        metadata={
                            "expected_type": expected_type,
                            "actual_type": actual_fields[field],
                            "validation_type": "wrong_field_type",
                        },
                    )
                    check = False

        return check
