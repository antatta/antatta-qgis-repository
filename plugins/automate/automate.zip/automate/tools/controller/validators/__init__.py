# -*- coding: utf-8 -*-
"""
Validators Module - Sistema modulare per validazioni Controller
Sistema di registrazione automatica e context condiviso per validators.
"""

# # 2. STANDARD LIBRARY
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Type

# # 3. THIRD-PARTY LIBRARIES
from osgeo import ogr

# # 4. PROJECT LIBRARIES
from database import DatabaseConnect

# # 5. LOCAL IMPORTS
from ..error_reporter import ErrorReporter


@dataclass
class ControllerContext:
    """
    Contesto condiviso per tutti i validators.
    Contiene tutti i dati e oggetti necessari per le validazioni.
    """

    lotto_name: str # Identificativo del lotto
    lotto_gpkg_path: Path # Path del file GPKG del lotto
    lotto_dir_path: Path # Path della directory del lotto
    db: DatabaseConnect  # DatabaseConnect
    # Costanti condivise - importate una sola volta nel context
    c: Optional[Dict[str, Any]]
    # DataSource sorgente del lotto
    src_ds: ogr.DataSource
    # error_reporter per logging strutturato
    error_reporter: ErrorReporter
    # Riferimento al controller per emissione segnali
    controller: Optional[Any] = None  # Controller instance


class ValidatorRegistry:
    """
    Registry per autodiscovery e gestione automatica dei validators.
    Supporta auto-registrazione tramite decorator e delegator dinamico.
    """

    _validators: Dict[str, Type["BaseValidator"]] = {}

    @classmethod
    def register(cls, validator_class: Type["BaseValidator"]):
        """
        Decorator per registrare automaticamente un validator.
        Utilizza la class variable 'name' del validator per la registrazione.

        Usage:
            @ValidatorRegistry.register
            class MyValidator(BaseValidator):
                name = "nome_validator"
                # ...
        """
        # Ottieni il nome dalla class variable name
        validator_name = getattr(validator_class, 'name', None)
        
        if validator_name is None:
            raise ValueError(
                f"Validator {validator_class.__name__} deve avere una class variable 'name' definita"
            )
        
        # Registra nel registry
        cls._validators[validator_name] = validator_class
        return validator_class

    @classmethod
    def get_all_validators(cls) -> Dict[str, Type["BaseValidator"]]:
        """Restituisce dizionario di tutte le classi validator registrate."""
        return cls._validators.copy()

    @classmethod
    def create_all_validators(
        cls, context: ControllerContext
    ) -> Dict[str, "BaseValidator"]:
        """Crea istanze di tutti i validators registrati con il context fornito."""
        return {
            name: validator_class(context)
            for name, validator_class in cls._validators.items()
        }

    @classmethod
    def get_validator_names(cls) -> List[str]:
        """Restituisce lista ordinata dei nomi dei validators per autodiscovery."""
        return sorted(cls._validators.keys())

    @classmethod
    def get_validator_descriptions(cls) -> List[tuple[str, str]]:
        """
        Restituisce lista di tuple (nome, descrizione) per tutti i validators.
        Utile per CLI help e Dialog population.
        """
        descriptions = []
        for name, validator_class in cls._validators.items():
            # Usa il nome del validator come descrizione di fallback
            description = getattr(validator_class, '__doc__', name.replace('_', ' ').title())
            if description:
                # Prendi solo la prima riga della docstring
                description = description.strip().split('\n')[0]
            else:
                description = name.replace('_', ' ').title()
            descriptions.append((name, description))
        return sorted(descriptions)

    @classmethod
    def has_validator(cls, name: str) -> bool:
        """Verifica se un validator è registrato."""
        return name in cls._validators

    @classmethod
    def get_validator_class(cls, name: str) -> Optional[Type["BaseValidator"]]:
        """Ottiene la classe di un validator specifico."""
        return cls._validators.get(name)

    @classmethod
    def get_validator_display_name(cls, name: str) -> Optional[str]:
        """
        Ottiene il display_name di un validator specifico.
        
        Args:
            name: Nome del validator (es. "mandatory_fields")
            
        Returns:
            str: display_name del validator (es. "Campi obbligatori") 
                 o None se il validator non esiste
        """
        validator_class = cls._validators.get(name)
        if validator_class is None:
            return None
        
        # Usa display_name dalla class variable, fallback al nome del validator
        return getattr(validator_class, 'display_name', name)


# # 5. LOCAL IMPORTS
# Import della classe base per permettere l'uso del type hint
from .base_validator import BaseValidator


def _autodiscover_validators():
    """
    🚀 SISTEMA AUTODISCOVERY DINAMICO
    
    Importa automaticamente tutti i validator files nella cartella
    per attivare la registrazione tramite decoratori.
    """
    # # 2. STANDARD LIBRARY
    import importlib
    from pathlib import Path
    
    validators_dir = Path(__file__).parent
    
    print("🔍 Autodiscovery dinamico dei validators...")
    
    # Trova tutti i file .py nella cartella validators (esclusi i file di sistema)
    validator_files = [
        f.stem for f in validators_dir.glob("*.py")
        if f.name not in ("__init__.py", "base_validator.py", "overlap_detector.py")
    ]
    
    imported_count = 0
    for validator_file in validator_files:
        try:
            importlib.import_module(f".{validator_file}", package=__name__)
            imported_count += 1
        except Exception as e:
            print(f"⚠️ Errore autodiscovery {validator_file}: {e}")
    
    registry_count = len(ValidatorRegistry.get_all_validators())
    print(f"✅ Autodiscovery completato: {imported_count} file importati, {registry_count} validators registrati")
    
    if registry_count == 0:
        print("⚠️ Nessun validator registrato! Verifica i decoratori @ValidatorRegistry.register")

# Esegui autodiscovery all'import del modulo
_autodiscover_validators()
