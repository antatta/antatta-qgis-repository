"""
Validator per il controllo del codice RG (Regional Geographic Code).

Questo validator sostituisce il metodo check_rg_cod del Controller
con un approccio modulare e testabile.
"""
# # 1. FUTURE IMPORTS
from __future__ import annotations  # SEMPRE in cima!

# # 2. STANDARD LIBRARY
from typing import Optional

# # 3. THIRD-PARTY LIBRARIES
from osgeo import ogr

# # 5. LOCAL IMPORTS
from ..error_types import ErrorSeverity
from . import ControllerContext, ValidatorRegistry
from .base_validator import BaseValidator


@ValidatorRegistry.register
class RgCodValidator(BaseValidator):
    """
    Validator per verificare la correttezza del codice rg_cod.

    Controlla che il valore memorizzato nel campo 'univoco' di ogni feature
    corrisponda al valore calcolato usando la funzione rg_cod.
    """
    
    # Class variables per metadata (nuovo sistema)
    name: str = "rg_cod"
    description: str = "Verifica la correttezza del codice RG_COD per tutte le features dei layer SDI"
    display_name: str = "rg_cod"
    
    def __init__(self, context: ControllerContext):
        super().__init__(context)

    def validate(self) -> bool:
        """
        Esegue il controllo del codice RG_COD.

        Returns:
            True se tutti i codici RG sono corretti, False altrimenti
        """

        check_passed = True

        # Cicla su tutti i layer SDI esistenti
        for layer_name in self.get_sdi_layers():
            if not self.layer_exists(layer_name):
                continue

            layer_result = self._validate_layer(layer_name)
            if not layer_result:
                check_passed = False

        return check_passed

    def _validate_layer(self, layer_name: str) -> bool:
        """
        Valida un singolo layer per i codici RG.

        Args:
            layer_name: Nome del layer da validare

        Returns:
            True se il layer è valido, False altrimenti
        """
        layer_obj = self.get_lotto_layer(layer_name)
        if not layer_obj:
            self.add_error(
                layer_name=layer_name,
                fid="",
                field_name="",
                message=f"Layer {layer_name} non trovato",
            )
            return False

        # Ottieni prefisso e suffisso dalla tabella LAYER_TRIPLETTA
        try:
            result = self.context.db.get_layer_prefix_suffix("", layer_name)
            prefisso, suffisso = result
        except Exception as e:
            self.add_error(
                layer_name=layer_name,
                fid="",
                field_name="",
                message=f"Errore ottenimento prefisso/suffisso: {e}",
            )
            return False

        check_passed = True

        # Verifica ogni feature del layer
        layer_obj.ResetReading()
        while (feature := layer_obj.GetNextFeature()) is not None:
            feature_result = self._validate_feature(
                layer_name, feature, prefisso, suffisso
            )
            if not feature_result:
                check_passed = False

        return check_passed

    def _validate_feature(
        self, layer_name: str, feature: ogr.Feature, prefisso: str, suffisso: str
    ) -> bool:
        """
        Valida una singola feature per il codice RG.

        Args:
            layer_name: Nome del layer
            feature: Feature OGR da validare
            prefisso: Prefisso per il calcolo RG
            suffisso: Suffisso per il calcolo RG

        Returns:
            True se la feature è valida, False altrimenti
        """
        fid = feature.GetFID()

        try:
            # Prendi il valore di univoco memorizzato sulla feature
            rg_cod_memorizzato = feature.GetFieldAsString(
                self.context.c["UNIVOCO_FEATURE"]
            )

            # Calcola il valore corretto usando la funzione rg_cod
            rg_cod_calcolato = self._calculate_rg_cod(feature, prefisso, suffisso)

            # Confronta i valori
            if rg_cod_memorizzato != rg_cod_calcolato:
                error_message = f"{self.context.c['UNIVOCO_FEATURE']} errato: '{rg_cod_memorizzato}' invece di '{rg_cod_calcolato}'"

                self.add_error(
                    layer_name=layer_name,
                    fid=str(fid),
                    field_name=self.context.c["UNIVOCO_FEATURE"],
                    message=error_message,
                    severity=ErrorSeverity.ERROR,
                    metadata={
                        "rg_cod_memorizzato": rg_cod_memorizzato,
                        "rg_cod_calcolato": rg_cod_calcolato,
                        "prefisso": prefisso,
                        "suffisso": suffisso,
                    },
                )

                return False

        except Exception as e:
            self.add_error(
                layer_name=layer_name,
                fid=str(fid),
                field_name="",
                message=f"Errore validazione feature: {e}",
            )
            return False

        return True

    def _calculate_rg_cod(
        self, feature: ogr.Feature, prefisso: str, suffisso: str
    ) -> str:
        """
        Calcola il valore del campo 'rg_cod' per una feature.

        Questa è la stessa logica del metodo rg_cod originale del Controller.

        Args:
            feature: Feature OGR
            prefisso: Prefisso per il calcolo
            suffisso: Suffisso per il calcolo

        Returns:
            Codice RG calcolato come stringa
        """

        # Lista per memorizzare i pezzi per calcolare l'rg_cod
        rg_cod_elements = []

        # Tripletta
        field_index = feature.GetFieldIndex(self.context.c["TRIPLETTA"])
        if field_index == -1:
            tripletta = "???"  # Indica che manca il campo
        else:
            # prendo il valore memorizzato nel campo
            tripletta = feature.GetFieldAsString(self.context.c["TRIPLETTA"])

        # Verifica se il valore è vuoto e sostituisce con !!!
        if tripletta == "":
            tripletta = "!!!"  # Indica che non è stato inserito nessun valore

        # Calcolo prefisso
        if not prefisso:
            prefisso = ""
        if prefisso.lower() == "tripletta":
            prefisso = tripletta + "_"
        rg_cod_elements.append(prefisso)

        # calcolo progressivo
        fid = feature.GetFID()

        # fmt: off
        if fid < 10 ** self.context.c["cifre_max_elementi_lotto"]:
            # aggiungo il nome del file
            rg_cod_elements.append(self.context.lotto_name.zfill(self.context.c["cifre_max_nome_lotto"]))
            rg_cod_elements.append(str(fid).zfill(self.context.c["cifre_max_elementi_lotto"]))
        else:
            rg_cod_elements.append(
                str(fid).zfill(
                    self.context.c["cifre_max_nome_lotto"] + self.context.c["cifre_max_elementi_lotto"]
                )
            )
        # fmt: on

        # calcolo suffisso
        if not suffisso:
            suffisso = ""
        if suffisso.lower() == "tripletta":
            suffisso = "_" + tripletta
        rg_cod_elements.append(suffisso)

        # Unisci tutti gli elementi con underscore
        return "".join(
            filter(None, rg_cod_elements)
        )  # filter(None, ...) rimuove elementi vuoti
