# -*- coding: utf-8 -*-
"""
BaseValidator - Classe base astratta per tutti i validators.
Definisce l'interfaccia comune e fornisce helper methods.
"""
# # 1. FUTURE IMPORTS
from __future__ import annotations  # SEMPRE in cima!

# # 2. STANDARD LIBRARY
from abc import ABC, abstractmethod
from typing import Any, List, Optional, Union  # Solo tipi runtime necessari

# # 3. THIRD-PARTY LIBRARIES
from osgeo import ogr

# # 5. LOCAL IMPORTS
from ..error_types import ErrorSeverity, ValidationError
from . import ControllerContext


class BaseValidator(ABC):
    """
    Classe base astratta per tutti i validators del Controller.

    Ogni validator deve definire le class variables:
    - name: str = nome identificativo per CLI e autodiscovery
    - description: str = descrizione per help e documentazione
    - display_name: str = nome user-friendly per interfacce grafiche
    
    E implementare:
    - validate(): metodo principale di validazione
    """
    
    # Class variables obbligatorie (devono essere sovrascritte dalle sottoclassi)
    name: Optional[str] = None  # Nome tecnico del validator
    description: Optional[str] = None  # Descrizione breve del validator
    display_name: Optional[str] = None  # Nome user-friendly per interfaccia

    def __init__(self, context: Union[ControllerContext, None]):
        """Inizializza il validator con il context del controller.

        Args:
            context: Context condiviso del controller.
            
        Raises:
            ValueError: Se context è None
        """
        if not context:
            raise ValueError(
                f"Impossibile inizializzare {self.__class__.__name__}: "
                f"il parametro 'context' è obbligatorio e non può essere None."
            )
        
        # Verifica che il context abbia gli attributi essenziali
        required_attrs = ['c','db', 'src_ds', 'error_reporter']
        missing_attrs = [attr for attr in required_attrs if not hasattr(context, attr)]
        
        if missing_attrs:
            raise ValueError(
                f"Context non valido per {self.__class__.__name__}: "
                f"mancano gli attributi obbligatori: {', '.join(missing_attrs)}"
            )

        self.context:ControllerContext = context

    @abstractmethod
    def validate(self, *args, **kwargs) -> bool:
        """
        Metodo principale di validazione.

        Args:
            *args, **kwargs: Parametri specifici per ogni validator

        Returns:
            bool: True se la validazione ha successo, False se ci sono errori

        Raises:
            Exception: In caso di errori critici durante la validazione
        """
        pass

    def add_error(
        self,
        layer_name: str,
        fid: str,
        field_name: str,
        message: str,
        severity: ErrorSeverity = ErrorSeverity.ERROR,
        metadata: Optional[dict] = None,
        geometry: Any = None,
        crs: str = "EPSG:3857",
    ):
        """Helper per aggiungere errori tramite l'error reporter del context.

        Args:
            layer_name: Nome del layer
            fid: ID della feature
            field_name: Nome del campo
            message: Messaggio di errore
            severity: Severità dell'errore (default: ERROR)
            metadata: Metadati aggiuntivi per l'errore
            geometry: Geometria associata all'errore (Shapely, OGR, QGIS) - opzionale
            crs: Sistema di coordinate (usato solo per errori geometrici)
        """
        if metadata is None:
            metadata = {}

        if self.context and self.context.error_reporter:
            # Usa il nome del validator (property name) come check_name per compatibility
            # check_name = f"check_{self.name}"
            check_name = f"{self.display_name}"

            # Crea un ValidationError unificato che gestisce automaticamente
            # sia errori tabellari (geometry=None) che geometrici (geometry!=None)
            error = ValidationError(
                check_name=check_name,
                layer_name=layer_name,
                feature_id=fid,
                field_name=field_name,
                error_message=message,
                severity=severity,
                metadata=metadata,
                geometry=geometry,
                crs=crs if geometry is not None else None,
            )
            self.context.error_reporter.add_error(error)

            # 🔥 IMPORTANTE: Emetti il segnale per compatibilità con l'interfaccia
            # Questo garantisce che i messaggi vengano visualizzati come nel controller originale
            if self.context.controller and hasattr(
                self.context.controller, "msg_signal"
            ):
                # error_pipe = f"{check_name}|{layer_name}|{fid}|{field_name}|{message}"
                error_pipe = error.to_pipe_format()
                self.context.controller.msg_signal.emit(error_pipe)

    def get_lotto_layer(self, layer_name: str):
        """Helper per ottenere un layer dal src_ds del context, ovvero dal lotto.

        Args:
            layer_name: Nome del layer da ottenere

        Returns:
            Layer oggetto o None se non trovato/context non disponibile
        """
        # src_ds è garantito valido dal BaseValidator.__init__
        try:
            layer = self.context.src_ds.GetLayerByName(layer_name)
            if layer is None:
                # Layer non trovato - reporta come errore critico
                self.add_error(
                    layer_name=layer_name,
                    fid="N/A",
                    field_name="layer_existence",
                    message=f"Layer '{layer_name}' non trovato nel datasource",
                    severity=ErrorSeverity.CRITICAL,
                    metadata={
                        "validation_type": "layer_access", 
                        "requested_layer": layer_name
                        }
                )
                return None
            return layer
        except Exception as e:
            # Errore GDAL nell'accesso - reporta come errore critico
            self.add_error(
                layer_name=layer_name,
                fid="N/A", 
                field_name="layer_access",
                message=f"Errore nell'accesso al layer '{layer_name}': {str(e)}",
                severity=ErrorSeverity.CRITICAL,
                metadata={
                    "validation_type": "gdal_error",
                    "error_type": type(e).__name__
                    }
            )
            return None

    def get_sdi_layers(self) -> List[str]:
        """
        Helper per ottenere i layer SDI dal DB master.
        Lista dei layer a carico della SDI.
        
        Returns:
            List[str]: Lista dei nomi dei layer SDI
        """
        
        try:
            self.layers_sdi: List[str] = self.context.db.get_layers_sdi("")
        except Exception as e:
            print(f"⚠️  Errore recupero layers_sdi: {e}")
            self.layers_sdi: List[str] = []
            
        return self.layers_sdi

    def get_layer_crs(self, layer: ogr.Layer) -> str:
        """
        Ottiene il sistema di coordinate (CRS) di un layer OGR.
        
        Args:
            layer: Layer OGR da cui estrarre il CRS
            
        Returns:
            str: CRS nel formato EPSG:xxxx, default EPSG:3857 se non determinabile
        """
        # TODO: Semplificare recupero solo CRS e modificare dentro il metodo di salvataggio errori
        spatial_ref = layer.GetSpatialRef()
        return (
            f"EPSG:{spatial_ref.GetAttrValue('AUTHORITY', 1)}"
            if spatial_ref and spatial_ref.GetAttrValue("AUTHORITY", 1)
            else "EPSG:32633"
        )

    def layer_exists(self, layer_name: str) -> bool:
        """
        Helper per verificare l'esistenza di un layer.

        Args:
            layer_name: Nome del layer da verificare

        Returns:
            bool: True se il layer esiste
        """
        # existing_layers è garantito disponibile (part del context validato)
        layer = self.context.src_ds.GetLayerByName(layer_name)
        if layer is None:
            self.add_error(
                layer_name=layer_name,
                fid="N/A",
                field_name="layer_existence",
                message=f"Layer '{layer_name}' non trovato nel datasource",
                severity=ErrorSeverity.CRITICAL,
                metadata={
                    "validation_type": "layer_existence", 
                    "requested_layer": layer_name
                    }
            )
            return False

        return True

    def __repr__(self) -> str:
        """Rappresentazione string per debug."""
        return f"{self.__class__.__name__}(name='{self.name}')"
