# -*- coding: utf-8 -*-
"""
Image Position Validator - Validator per SGA_INTERF_SEZ
Verifica la corrispondenza tra la posizione rilevata nell'immagine allegata 
e il valore memorizzato nel campo 'field_lato_posa'
"""
# # 1. FUTURE IMPORTS
from __future__ import annotations

# # 2. STANDARD LIBRARY
import os
from pathlib import Path
from typing import Optional, Tuple, List, Dict, Any, Union
from dataclasses import dataclass

# # 3. THIRD-PARTY LIBRARIES
import cv2
import numpy as np
from osgeo import ogr

# # 5. LOCAL IMPORTS
from .base_validator import BaseValidator
from ..error_types import ErrorSeverity
from . import ControllerContext, ValidatorRegistry

@ValidatorRegistry.register
class SectionImagePipePositionValidator(BaseValidator):
    """
    Validator per la verifica delle posizioni della tubazione nelle immagini della sezione di percorrenza
    
    Questo validator verifica che il campo lato_posa delle interferenze di sezione
    sia concorde con la posizione effettiva della tubazione nell'immagine allegata,
    utilizzando tecniche di elaborazione delle immagini per rilevare la posizione.
    """
    
    # Class variables richieste da BaseValidator
    name:str = "section_vs_pipe_position_in_image"
    description:str = "Verifica corrispondenza tra posizione tubazione nell'immagine e campo lato posa sul layer"
    display_name:str = "Sezione percorenza 3, lato posa indicato vs immagine"
    
    def __init__(self, context: ControllerContext):
        """
        Args:
            context: Context del controller
        """
        super().__init__(context)
        # Il percorso base verrà impostato nel metodo validate() usando le costanti
        self.detection_engine = RedDetectionEngine()
        self.results: List[ValidationResult] = []
        self.base_image_path: Optional[Path] = None
    
    def validate(self) -> bool:
        """
        Metodo principale di validazione richiesto da BaseValidator
        
        Returns:
            bool: True se validazione completata senza errori critici
        """
        assert self.context.CONST is not None
        const = self.context.CONST
        
        
        layer_name: str = const['ly_interf_sez']
        attached_field:str = const['filed_attached']
        position_field:str = const['field_lato_posa']
        self.base_image_path = self.context.lotto_dir_path / const['dir_allegati'] / const['dir_img_sezioni_percorrenza']
        
        try:            
            # Ottieni layer dal context
            layer = self.get_lotto_layer(layer_name)
            if not layer:
                return False
            
            # Esegui validazione del layer
            results = self.validate_ogr_layer(layer, attached_field, position_field)
            
            # Report statistiche finali e determina esito
            if results:
                valid_count = sum(1 for r in results if r.is_valid)
                total_count = len(results)
                error_count = total_count - valid_count
                
                print(f"📊 Validazione completata: {valid_count}/{total_count} features valide")
                
                # Il controllo è superato solo se NON ci sono errori (tutti validi)
                if error_count == 0:
                    print("✅ Controllo SUPERATO: nessun errore rilevato")
                    return True
                else:
                    print(f"❌ Controllo FALLITO: {error_count} errori rilevati")
                    return False
            else:
                print("❌ Nessun risultato dalla validazione")
                return False
                
        except Exception as e:
            self.add_error(
                layer_name=layer_name,
                fid="N/A",
                field_name="validation_process",
                message=f"Errore durante validazione: {str(e)}",
                severity=ErrorSeverity.CRITICAL
            )
            return False
    
    
    def resolve_image_path(self, attached_filename: str) -> Optional[Path]:
        """
        Risolve il percorso completo dell'immagine
        
        Args:
            attached_filename: Nome file dall'attributo 'attached'
            
        Returns:
            Path completo o None se non trovato
        """
        if not attached_filename:
            return None
            
        if not self.base_image_path:
            print("⚠️  Percorso base immagini non configurato")
            return None
        
        # Prova diversi pattern di percorso
        possible_paths = [
            self.base_image_path / attached_filename,
            self.base_image_path / f"{attached_filename}.jpg",
            self.base_image_path / f"{attached_filename}.jpeg",
            self.base_image_path / f"{attached_filename}.png"
        ]
        
        for path in possible_paths:
            if path.exists():
                return path
        
        print(f"⚠️  File immagine non trovato: {attached_filename} nei percorsi: {[str(p) for p in possible_paths]}")
        return None
    
    def normalize_position_value(self, field_value: Any) -> Optional[str]:
        """
        Normalizza il valore del campo field_lato_posa
        
        Args:
            field_value: Valore dal campo (numerico o stringa)
            
        Returns:
            'sinistra', 'destra' o None
        """
        if field_value is None:
            return None
        
        # Ottieni i valori dalle costanti
        const = self.context.CONST
        if const is None:
            # Fallback se CONST non è disponibile
            value_sx = 1
            value_dx = 2
        else:
            value_sx = const.get('value_lato_posa_sx', 1) if hasattr(const, 'get') else getattr(const, 'value_lato_posa_sx', 1)
            value_dx = const.get('value_lato_posa_dx', 2) if hasattr(const, 'get') else getattr(const, 'value_lato_posa_dx', 2)
        
        # Prima verifica valori numerici dalle costanti
        if isinstance(field_value, (int, float)):
            if field_value == value_sx:
                return 'sinistra'
            elif field_value == value_dx:
                return 'destra'
        
        # Se è stringa, prova conversione numerica
        try:
            numeric_value = int(field_value)
            if numeric_value == value_sx:
                return 'sinistra'
            elif numeric_value == value_dx:
                return 'destra'
        except (ValueError, TypeError):
            pass
        
        # Fallback per valori stringa tradizionali
        str_value = str(field_value).lower().strip()
        left_values = ['sinistra', 'left', 'l', 's', 'sx', 'sin']
        right_values = ['destra', 'right', 'r', 'd', 'dx', 'des']
        
        if str_value in left_values:
            return 'sinistra'
        elif str_value in right_values:
            return 'destra'
        else:
            print(f"⚠️  Valore field_lato_posa non riconosciuto: '{field_value}' (attesi: {value_sx}=sinistra, {value_dx}=destra)")
            return None
    
    def validate_ogr_feature(self, feature: ogr.Feature, attached_field: str = 'ATTACHED', 
                            position_field: str = 'COD_LATO_POSA') -> ValidationResult:
        """
        Valida una singola feature OGR
        
        Args:
            feature: Feature OGR da validare
            attached_field: Nome campo con il file immagine
            position_field: Nome campo con la posizione indicata
            
        Returns:
            ValidationResult con i risultati della validazione
        """
        feature_id = feature.GetFID()
        
        # Estrai i valori dei campi
        attached_file = feature.GetField(attached_field)
        expected_position_raw = feature.GetField(position_field)
        
        # Normalizza la posizione indicata
        expected_position = self.normalize_position_value(expected_position_raw)
        
        # Inizializza risultato base
        result = ValidationResult(
            feature_id=feature_id,
            attached_file=str(attached_file) if attached_file else "",
            expected_position=expected_position or "N/A",
            detected_position=None,
            match_count=0,
            coordinates=None,
            is_valid=False,
            error_message=None
        )
        
        # Validazioni preliminari
        if not attached_file:
            result.error_message = f"Campo '{attached_field}' vuoto o non presente"
            return result
        
        if not expected_position:
            result.error_message = f"Campo '{position_field}' non valido: '{expected_position_raw}'"
            return result
        
        # Risolvi percorso immagine
        image_path = self.resolve_image_path(str(attached_file))
        if not image_path:
            result.error_message = f"File immagine non trovato: {attached_file}"
            return result
        
        # Esegui rilevamento
        match_count, detected_position, coordinates, rectangles = self.detection_engine.detect_red_position(str(image_path))
        
        result.match_count = match_count
        result.detected_position = detected_position
        result.coordinates = coordinates
        
        # Valuta i risultati
        if match_count == 0:
            result.error_message = "Nessun simbolo rosso rilevato nell'immagine"
        elif match_count > 1:
            result.error_message = f"Troppi simboli rossi rilevati ({match_count}). Impossibile determinare posizione."
            # Crea immagine debug per match multipli
            self._create_debug_image(str(image_path), str(attached_file), rectangles, match_count)
        elif match_count == 1:
            if detected_position == expected_position:
                result.is_valid = True
                result.confidence = 1.0
            else:
                result.error_message = f"Posizione rilevata '{detected_position}' non corrisponde a quella indicata '{expected_position}'"
        
        return result
    
    def validate_ogr_layer(self, layer: ogr.Layer, attached_field: str = 'ATTACHED', 
                          position_field: str = 'COD_LATO_POSA') -> List[ValidationResult]:
        """
        Valida tutte le features di un layer OGR
        
        Args:
            layer: Layer OGR da validare
            attached_field: Nome campo con il file immagine  
            position_field: Nome campo con la posizione
            
        Returns:
            Lista dei risultati di validazione
        """
        if not layer:
            print("❌ Layer non valido")
            return []
        
        self.results = []
        layer.ResetReading()
        feature_count = layer.GetFeatureCount()
        
        print(f"🔍 Inizio validazione layer - {feature_count} features")
        
        # Verifica esistenza campi
        layer_defn = layer.GetLayerDefn()
        field_names = [layer_defn.GetFieldDefn(i).GetName() for i in range(layer_defn.GetFieldCount())]
        
        if attached_field not in field_names:
            error_msg = f"Campo '{attached_field}' non trovato nel layer. Campi disponibili: {field_names}"
            self.add_error(
                layer_name=layer.GetName(),
                fid="N/A",
                field_name=attached_field,
                message=error_msg,
                severity=ErrorSeverity.CRITICAL
            )
            return []
            
        if position_field not in field_names:
            error_msg = f"Campo '{position_field}' non trovato nel layer. Campi disponibili: {field_names}"
            self.add_error(
                layer_name=layer.GetName(), 
                fid="N/A",
                field_name=position_field,
                message=error_msg,
                severity=ErrorSeverity.CRITICAL
            )
            return []
        
        # Processa ogni feature
        processed = 0
        feature = layer.GetNextFeature()
        
        while feature:
            result = self.validate_ogr_feature(feature, attached_field, position_field)
            self.results.append(result)
            
            # Report errore se necessario
            if not result.is_valid:
                self.add_error(
                    layer_name=layer.GetName(),
                    fid=str(result.feature_id),
                    field_name=attached_field if result.attached_file else position_field,
                    message=result.error_message or "Errore sconosciuto",
                    severity=ErrorSeverity.ERROR
                )
            
            processed += 1
            if processed % 50 == 0:  # Log ogni 50 features
                print(f"📊 Processate {processed}/{feature_count} features")
                
            feature = layer.GetNextFeature()
        
        # Statistiche finali
        valid_count = sum(1 for r in self.results if r.is_valid)
        error_count = len(self.results) - valid_count
        
        print(f"✅ Validazione completata: {valid_count}/{len(self.results)} valide, {error_count} errori")
        
        return self.results
    
    def _create_debug_image(self, image_path: str, attached_filename: str, rectangles: List[Dict], match_count: int) -> None:
        """
        Crea un'immagine debug per match multipli
        
        Args:
            image_path: Percorso dell'immagine originale
            attached_filename: Nome del file allegato
            rectangles: Lista dei rettangoli rilevati
            match_count: Numero di match trovati
        """
        try:
            # Carica immagine originale
            image = cv2.imread(image_path)
            if image is None:
                print(f"❌ Impossibile caricare immagine per debug: {image_path}")
                return
            
            # Crea directory di output se non esiste
            const = self.context.CONST
            if const:
                debug_dir_name = f"{const['dir_img_sezioni_percorrenza']}_errate"
            else:
                debug_dir_name = "sezioni_percorrenza_errate"
            debug_dir = self.context.lotto_dir_path.parent / "check" / debug_dir_name
            debug_dir.mkdir(parents=True, exist_ok=True)
            
            # Nome file di output
            debug_filename = f"{Path(attached_filename).stem}_match_multipli.jpg"
            debug_path = debug_dir / debug_filename
            
            # Genera immagine debug
            debug_image = self._generate_debug_image(image, rectangles, match_count, attached_filename)
            
            # Salva immagine
            cv2.imwrite(str(debug_path), debug_image)
            print(f"🔍 Debug immagine salvata: {debug_path}")
            
        except Exception as e:
            print(f"❌ Errore creazione immagine debug per {attached_filename}: {str(e)}")
    
    def _generate_debug_image(self, image: np.ndarray, rectangles: List[Dict], match_count: int, filename: str) -> np.ndarray:
        """
        Genera l'immagine debug con annotazioni fucsia
        
        Args:
            image: Immagine originale (numpy array)
            rectangles: Lista rettangoli dei match
            match_count: Numero di match
            filename: Nome file per info debug
            
        Returns:
            Immagine debug annotata
        """
        height, width = image.shape[:2]
        center_x = width // 2
        debug_image = image.copy()
        
        # Colore fucsia
        fucsia_color = (255, 0, 255)
        
        # 1. Linea tratteggiata verticale di mezzeria
        self._draw_dashed_line(debug_image, (center_x, 0), (center_x, height), 
                              color=fucsia_color, thickness=2, dash_length=20)
        
        # 2. Testi "SINISTRA" e "DESTRA"
        font = cv2.FONT_HERSHEY_SIMPLEX
        font_scale = 1.5
        font_thickness = 3
        
        # Testo "SINISTRA" in alto a sinistra
        cv2.putText(debug_image, "SINISTRA", (20, 50), font, font_scale, fucsia_color, font_thickness)
        
        # Testo "DESTRA" in alto a destra 
        text_size = cv2.getTextSize("DESTRA", font, font_scale, font_thickness)[0]
        text_x = width - text_size[0] - 20
        cv2.putText(debug_image, "DESTRA", (text_x, 50), font, font_scale, fucsia_color, font_thickness)
        
        # 3. Rettangoli fucsia attorno ai match
        for i, rect in enumerate(rectangles):
            cv2.rectangle(debug_image, 
                         (rect['x'], rect['y']), 
                         (rect['x'] + rect['w'], rect['y'] + rect['h']), 
                         fucsia_color, 3)
            
            # Numero del match sopra il rettangolo
            match_text = f"#{i+1}"
            text_pos = (rect['x'], max(rect['y'] - 10, 15))
            cv2.putText(debug_image, match_text, text_pos, 
                       cv2.FONT_HERSHEY_SIMPLEX, 0.8, fucsia_color, 2)
        
        # 4. Informazioni errore in basso a sinistra
        error_info = f"MATCH: {match_count} | Troppi match in {filename}, necessario correggere"
        cv2.putText(debug_image, error_info, (20, height - 20), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.7, fucsia_color, 2)
        
        return debug_image
    
    def _draw_dashed_line(self, image: np.ndarray, pt1: Tuple[int, int], pt2: Tuple[int, int], 
                         color: Tuple[int, int, int], thickness: int = 1, dash_length: int = 10) -> None:
        """
        Disegna una linea tratteggiata tra due punti
        
        Args:
            image: Immagine su cui disegnare
            pt1: Punto iniziale (x, y)
            pt2: Punto finale (x, y) 
            color: Colore BGR (b, g, r)
            thickness: Spessore linea
            dash_length: Lunghezza di ogni tratto
        """
        x1, y1 = pt1
        x2, y2 = pt2
        
        # Calcola la distanza totale
        distance = np.sqrt((x2 - x1)**2 + (y2 - y1)**2)
        
        # Calcola il numero di segmenti
        num_segments = int(distance / (dash_length * 2))
        
        if num_segments == 0:
            return
        
        # Calcola i punti di inizio e fine di ogni segmento
        for i in range(num_segments):
            start_ratio = (i * 2 * dash_length) / distance
            end_ratio = ((i * 2 + 1) * dash_length) / distance
            
            if start_ratio > 1:
                break
                
            end_ratio = min(end_ratio, 1)
            
            start_x = int(x1 + (x2 - x1) * start_ratio)
            start_y = int(y1 + (y2 - y1) * start_ratio)
            end_x = int(x1 + (x2 - x1) * end_ratio)
            end_y = int(y1 + (y2 - y1) * end_ratio)
            
            cv2.line(image, (start_x, start_y), (end_x, end_y), color, thickness)
    
    def get_summary_stats(self) -> Dict[str, Any]:
        """
        Restituisce statistiche riassuntive dei risultati
        """
        if not self.results:
            return {}
        
        total = len(self.results)
        valid = sum(1 for r in self.results if r.is_valid)
        
        # Conta errori per tipo
        error_types = {}
        for result in self.results:
            if not result.is_valid and result.error_message:
                error_type = result.error_message.split('.')[0]  # Prima parte del messaggio
                error_types[error_type] = error_types.get(error_type, 0) + 1
        
        # Conta posizioni rilevate
        detected_positions = {}
        for result in self.results:
            if result.detected_position:
                detected_positions[result.detected_position] = detected_positions.get(result.detected_position, 0) + 1
        
        return {
            'total_features': total,
            'valid_matches': valid,
            'invalid_matches': total - valid,
            'success_rate': (valid / total * 100) if total > 0 else 0,
            'error_types': error_types,
            'detected_positions': detected_positions
        }



@dataclass
class ValidationResult:
    """Risultato della validazione per una singola feature"""
    feature_id: int
    attached_file: str
    expected_position: str
    detected_position: Optional[str]
    match_count: int
    coordinates: Optional[Tuple[int, int]]
    is_valid: bool
    error_message: Optional[str]
    confidence: float = 1.0

class RedDetectionEngine:
    """Motore per il rilevamento delle zone rosse nelle immagini"""
    
    def __init__(self):
        # Range HSV per il rilevamento del rosso
        self.lower_red1 = np.array([0, 100, 50])
        self.upper_red1 = np.array([10, 255, 255])
        self.lower_red2 = np.array([160, 100, 50])
        self.upper_red2 = np.array([180, 255, 255])
    
    def detect_red_position(self, image_path: str) -> Tuple[int, Optional[str], Optional[Tuple[int, int]], List[Dict]]:
        """
        Rileva la posizione delle zone rosse in un'immagine
        
        Returns:
            Tuple[match_count, position, coordinates, rectangles]
            - match_count: numero di zone rosse rilevate
            - position: 'sinistra', 'destra' o None
            - coordinates: coordinate del centro se match_count == 1
            - rectangles: lista dei rettangoli trovati per debug
        """
        try:
            # Carica immagine
            image = cv2.imread(str(image_path))
            if image is None:
                return 0, None, None, []
            
            height, width = image.shape[:2]
            center_x = width // 2
            
            # Conversione HSV
            hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
            
            # Creazione maschere per il rosso
            mask1 = cv2.inRange(hsv, self.lower_red1, self.upper_red1)
            mask2 = cv2.inRange(hsv, self.lower_red2, self.upper_red2)
            mask = cv2.bitwise_or(mask1, mask2)
            
            # Trova contorni
            contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            
            # Calcola rettangoli per tutti i contorni
            rectangles = []
            for cnt in contours:
                x, y, w, h = cv2.boundingRect(cnt)
                rect = {
                    'x': x, 'y': y, 'w': w, 'h': h,
                    'center_x': x + w // 2, 'center_y': y + h // 2
                }
                rectangles.append(rect)
            
            if len(contours) == 0:
                return 0, None, None, []
            
            if len(contours) == 1:
                # Un solo match - calcola posizione
                rect = rectangles[0]
                center_match_x = rect['center_x']
                center_match_y = rect['center_y']
                
                # Determina se è a sinistra o destra
                position = 'sinistra' if center_match_x < center_x else 'destra'
                
                return 1, position, (center_match_x, center_match_y), rectangles
            else:
                # Match multipli - non possiamo determinare la posizione
                return len(contours), None, None, rectangles
                
        except Exception as e:
            print(f"❌ Errore nel rilevamento immagine {image_path}: {str(e)}")
            return 0, None, None, []

