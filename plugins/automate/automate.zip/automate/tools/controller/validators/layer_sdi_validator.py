# -*- coding: utf-8 -*-
"""
Layer SDI Validator - Validator per controlli sulla presenza dei layer SDI.
Verifica la presenza dei layer richiesti dalla SDI nel database GPKG.
"""
# # 1. FUTURE IMPORTS
from __future__ import annotations

# # 3. THIRD-PARTY LIBRARIES
from osgeo import ogr

# # 5. LOCAL IMPORTS
from ..error_types import ErrorSeverity
from . import ControllerContext, ValidatorRegistry
from .base_validator import BaseValidator


@ValidatorRegistry.register
class LayerSDIValidator(BaseValidator):
    """
    Validator per verificare la presenza dei layer SDI nel GPKG.

    Controlla che tutti i layer richiesti dalla SDI siano presenti
    nel database GPKG e segnala eventuali layer mancanti.
    """
    
    # Class variables per metadata (nuovo sistema)
    name: str = "layer_sdi"
    description: str = "Verifica la presenza dei layer SDI nel GPKG"
    display_name: str = "presenza layer di progetto SDI"
    
    def __init__(self, context: ControllerContext):
        super().__init__(context)

    def validate(self) -> bool:
        """
        Verifica la presenza dei layer SDI nel GPKG.
        
        Returns:
            bool: True se tutti i layer sono presenti, False se mancano layer

        Raises:
            RuntimeError: Se il context non è disponibile
        """

        check = True

        # Abilita le eccezioni OGR per una migliore gestione errori
        ogr.UseExceptions()

        # Verifica la presenza di ogni layer nella lista LAYERS_SDI
        for layer_name in self.get_sdi_layers():
            if self.layer_exists(layer_name):
                print(f"Layer {layer_name} trovato nel GPKG")
                continue
            self.add_error(
                layer_name=layer_name,
                fid="N/A",
                field_name="layer_existence",
                message=f"Layer {layer_name} non trovato nel GPKG",
                severity=ErrorSeverity.CRITICAL,
                metadata={
                    "validation_type": "layer_presence",
                    "expected_layer": layer_name,
                    "available_layers": self.context.existing_layers[
                        :10
                    ],  # Prima 10 per debug
                    "total_available": len(self.context.existing_layers),
                    "gpkg_path": str(self.context.lotto_gpkg_path),
                },
            )
            check = False

        return check
