# -*- coding: utf-8 -*-
"""
Values Combinations Validator - Validator per combinazioni di valori ammissibili.
Verifica che le combinazioni di campi rispettino le regole di business definite.
"""
# # 1. FUTURE IMPORTS
from __future__ import annotations

# # 2. STANDARD LIBRARY
import yaml
from pathlib import Path

# # 3. THIRD-PARTY LIBRARIES
from osgeo import ogr

# # 5. LOCAL IMPORTS
from ..error_types import ErrorSeverity
from . import ControllerContext, ValidatorRegistry
from .base_validator import BaseValidator


@ValidatorRegistry.register
class ValuesCombinationsValidator(BaseValidator):
    """
    Validator per combinazioni di valori su più layer.

    Supporta regole di combinazione configurabili per qualsiasi layer
    tramite file YAML esterno (values_combinations_rules.yaml).
    Controlla che le combinazioni di campi rispettino le regole di business
    definite nel sistema (es. materiale/diametro/specie per tubazioni).
    """
    
    # Class variables per metadata (nuovo sistema)
    name: str = "values_combinations"
    description: str = "Verifica combinazioni di valori configurabili per layer multipli"
    display_name: str = "values_combinations"
    
    def __init__(self, context: ControllerContext):
        super().__init__(context)
        self._rules_config = None

    def validate(self) -> bool:
        """
        Verifica le combinazioni di valori in tutti i layer configurati.
        
        Returns:
            bool: True se tutte le combinazioni sono valide, False altrimenti
        """
        # Carica la configurazione delle regole
        rules_config = self._load_combinations_rules()
        if not rules_config:
            return False
        
        check = True
        enabled_layers = rules_config.get("validation_config", {}).get("enabled_layers", [])
        
        # Valida ogni layer configurato
        for layer_key in enabled_layers:
            layer_result = self._validate_layer(layer_key, rules_config)
            if not layer_result:
                check = False
        
        return check

    def _load_combinations_rules(self) -> dict:
        """
        Carica il file YAML delle regole di combinazione.
        
        Returns:
            Dict: Configurazione caricata dal YAML
        """
        try:
            # Trova il path del file YAML (accanto al validator)
            validator_dir = Path(__file__).parent
            rules_file = validator_dir / "values_combinations_rules.yaml"
            
            if not rules_file.exists():
                self.add_error(
                    layer_name="system",
                    fid="0",
                    field_name="config",
                    message=f"File regole non trovato: {rules_file}",
                    severity=ErrorSeverity.CRITICAL
                )
                return {}
            
            with open(rules_file, 'r', encoding='utf-8') as f:
                config = yaml.safe_load(f)
            
            # Type guard per assicurarsi che il config sia un dict
            if not isinstance(config, dict):
                self.add_error(
                    layer_name="system",
                    fid="0", 
                    field_name="config",
                    message="Il file YAML non contiene un dizionario valido",
                    severity=ErrorSeverity.CRITICAL
                )
                return {}
            
            return config
            
        except Exception as e:
            self.add_error(
                layer_name="system", 
                fid="0",
                field_name="config",
                message=f"Errore caricamento regole: {str(e)}",
                severity=ErrorSeverity.CRITICAL
            )
            return {}

    def _validate_layer(self, layer_key: str, rules_config: dict) -> bool:
        """
        Valida le combinazioni per un singolo layer.
        
        Args:
            layer_key: Chiave del layer (es: "ly_tubazione")
            rules_config: Configurazione delle regole
            
        Returns:
            bool: True se il layer è valido, False altrimenti
        """
        # Controllo di guardia per type checking
        assert self.context.c is not None

        const = self.context.c
        
        # Verifica che il layer esista nelle CONST
        if layer_key not in const:
            return True  # Skip se il layer non è configurato
        
        # Ottieni il layer OGR
        layer_obj = self.get_lotto_layer(const[layer_key])
        if layer_obj is None:
            return True  # Skip se il layer non esiste
        
        # Ottieni le regole per questo layer
        layer_rules = rules_config.get("layers", {}).get(layer_key, {})
        if not layer_rules:
            return True  # Skip se non ci sono regole
        
        # Converti le regole nel formato atteso
        combinations = self._convert_layer_rules_to_combinations(layer_rules, rules_config)
        
        check = True
        layer_obj.ResetReading()
        
        # Valida ogni feature del layer
        while (feature := layer_obj.GetNextFeature()) is not None:
            feature_result = self._validate_feature_combinations(
                feature, combinations, layer_key, rules_config
            )
            if not feature_result:
                check = False
        
        return check

    def _convert_layer_rules_to_combinations(self, layer_rules: dict, rules_config: dict) -> dict:
        """
        Converte le regole YAML di un layer nel formato delle combinazioni.
        
        Args:
            layer_rules: Regole per il layer specifico
            rules_config: Configurazione completa
            
        Returns:
            Dict con combinazioni nel formato atteso
        """
        # Controllo di guardia per type checking
        assert self.context.c is not None
        const = self.context.c
        
        field_mappings = rules_config.get("global_field_mappings", {})
        combination_groups = layer_rules.get("combination_groups", {})
        
        result = {}
        
        for group_config_key, group_config in combination_groups.items():
            group_key = group_config.get("group_key")
            if not group_key:
                continue
            
            converted_rules = []
            
            for rule in group_config.get("rules", []):
                converted_rule = {}
                conditions = rule.get("conditions", {})
                
                for yaml_field_name, values in conditions.items():
                    # Ottieni il nome del campo effettivo
                    const_field_key = field_mappings.get(yaml_field_name)
                    if const_field_key and const_field_key in const:
                        field_name = const[const_field_key]
                        
                        # Converte i valori
                        converted_values = self._convert_values(values, const)
                        converted_rule[field_name] = converted_values
                
                converted_rules.append(converted_rule)
            
            result[group_key] = converted_rules
        
        return result

    def _convert_values(self, values, const: dict):
        """
        Converte i valori dalle chiavi CONST ai valori effettivi.
        
        Args:
            values: Valori da convertire
            const: Dizionario delle costanti
            
        Returns:
            Valori convertiti
        """
        if isinstance(values, list):
            converted = []
            for value in values:
                if value is None:
                    converted.append(None)
                elif isinstance(value, str) and value.startswith("value_"):
                    converted.append(const.get(value, value))
                else:
                    converted.append(value)
            return converted
        elif values == "NOT_NULL":
            return "NOT_NULL"
        elif isinstance(values, str) and values.startswith("value_"):
            return const.get(values, values)
        else:
            return values

    def _validate_feature_combinations(self, feature: ogr.Feature, combinations: dict, layer_key: str, rules_config: dict) -> bool:
        """
        Valida le combinazioni per una feature di un layer specifico.
        
        Args:
            feature: Feature da validare
            combinations: Combinazioni per il layer
            layer_key: Chiave del layer
            rules_config: Configurazione completa delle regole
            
        Returns:
            bool: True se valida, False altrimenti
        """
        # Controllo di guardia per type checking
        assert self.context.c is not None

        const = self.context.c
        fid = feature.GetFID()
        check = True

        # Ottieni le regole originali per verificare global_conditions
        layer_rules = rules_config.get("layers", {}).get(layer_key, {})
        combination_groups = layer_rules.get("combination_groups", {})

        for check_name, combinazioni in combinations.items():
            # Trova il gruppo originale per verificare global_conditions
            group_config = self._find_group_by_check_name(check_name, combination_groups)
            
            # Verifica le global_conditions se esistono
            if group_config and not self._check_global_conditions(feature, group_config, rules_config):
                continue  # Skip questo gruppo se le condizioni globali non sono soddisfatte
            
            if not self._validate_combination_group(feature, combinazioni, check_name):
                # Estrai valori attuali per debug
                current_values = {}
                for field in combinazioni[0].keys():
                    current_values[field] = feature.GetField(field)

                self.add_error(
                    layer_name=const[layer_key],
                    fid=str(fid),
                    field_name=",".join(combinazioni[0].keys()),
                    message=f"Combinazione di valori non ammessa per {check_name} nel layer {const[layer_key]}",
                    severity=ErrorSeverity.ERROR,
                    metadata={
                        "layer_key": layer_key,
                        "check_type": check_name,
                        "current_values": current_values,
                        "validation_type": "value_combination_check",
                    },
                )
                check = False

        return check

    def _validate_combination_group(
        self, feature: ogr.Feature, combinazioni: list, check_name: str
    ) -> bool:
        """
        Valida un gruppo di combinazioni per una feature.

        Args:
            feature: Feature da validare
            combinazioni: Lista delle combinazioni ammissibili
            check_name: Nome del controllo

        Returns:
            bool: True se almeno una combinazione è valida, False altrimenti
        """
        for combinazione in combinazioni:
            if self._validate_single_combination(feature, combinazione):
                return True  # Almeno una combinazione è valida
        
        return False  # Nessuna combinazione valida

    def _validate_single_combination(
        self, feature: ogr.Feature, combinazione: dict
    ) -> bool:
        """
        Valida una singola combinazione per una feature.

        Args:
            feature: Feature da validare
            combinazione: Dizionario {campo: valori_ammessi}

        Returns:
            bool: True se tutti i campi hanno valori ammessi, False altrimenti
        """
        for field, valid_values in combinazione.items():
            value = feature.GetField(field)
            
            # 🆕 GESTIONE VALORI SPECIALI PER REGOLE CONDIZIONALI
            if valid_values == "NOT_NULL":
                # Il campo NON deve essere NULL
                if value is None:
                    return False
            elif isinstance(valid_values, list):
                # Comportamento standard: il valore deve essere nella lista
                if value not in valid_values:
                    return False
            else:
                # Valore singolo
                if value != valid_values:
                    return False
        
        return True

    def _find_group_by_check_name(self, check_name: str, combination_groups: dict) -> dict | None:
        """
        Trova il gruppo di configurazione originale da un check_name.
        
        Args:
            check_name: Nome del controllo (group_key)
            combination_groups: Gruppi di combinazioni dal YAML
            
        Returns:
            Dict del gruppo o None se non trovato
        """
        for group_config in combination_groups.values():
            if group_config.get("group_key") == check_name:
                return group_config
        return None

    def _check_global_conditions(self, feature: ogr.Feature, group_config: dict, rules_config: dict) -> bool:
        """
        Verifica se le condizioni globali di un gruppo sono soddisfatte.
        
        Args:
            feature: Feature da controllare
            group_config: Configurazione del gruppo
            rules_config: Configurazione completa
            
        Returns:
            bool: True se le condizioni sono soddisfatte o non esistono
        """
        global_conditions = group_config.get("global_conditions")
        if not global_conditions:
            return True  # Nessuna condizione globale = sempre valido
        
        # Controllo di guardia per type checking
        assert self.context.c is not None
        const = self.context.c
        
        field_mappings = rules_config.get("global_field_mappings", {})
        
        for yaml_field_name, expected_values in global_conditions.items():
            # Ottieni il nome del campo effettivo
            const_field_key = field_mappings.get(yaml_field_name)
            if const_field_key and const_field_key in const:
                field_name = const[const_field_key]
                actual_value = feature.GetField(field_name)
                
                # Converti i valori attesi
                converted_values = self._convert_values(expected_values, const)
                
                # Verifica che il valore attuale sia nella lista dei valori ammessi
                if isinstance(converted_values, list):
                    if actual_value not in converted_values:
                        return False
                else:
                    if actual_value != converted_values:
                        return False
        
        return True
