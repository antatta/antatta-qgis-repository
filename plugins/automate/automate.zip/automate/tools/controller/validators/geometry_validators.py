# -*- coding: utf-8 -*-
"""
Geometry Validators - Validators per controlli geometrici.
Contiene validators per lunghezza feature, distanze, sovrapposizioni, etc.
"""
# # 1. FUTURE IMPORTS
from __future__ import annotations

# # 3. THIRD-PARTY LIBRARIES
from osgeo import ogr

# # 5. LOCAL IMPORTS
from ..error_types import ErrorSeverity
from . import ControllerContext, ValidatorRegistry
from .base_validator import BaseValidator


@ValidatorRegistry.register
class FeatureLengthValidator(BaseValidator):
    """
    Validator per verificare la lunghezza delle feature nei layer SDI.

    Controlla che le feature LineString abbiano una lunghezza minima
    secondo i parametri definiti in CONST.
    """
    
    # Class variables per metadata (nuovo sistema)
    name: str = "feature_length"
    description: str = "Verifica la lunghezza delle feature nei layer SDI"
    display_name: str = "feature_length"
    
    def __init__(self, context: ControllerContext):
        super().__init__(context)

    def validate(self) -> bool:
        """
        Verifica la lunghezza delle feature nei layer SDI.

        Args:
            layers_sdi: Lista custom di layer da verificare.
                       Se None, usa la lista dal context

        Returns:
            bool: True se tutte le lunghezze sono valide, False altrimenti
        """
        check = True
        
        for layer in self.get_sdi_layers():
            if not self.layer_exists(layer):
                continue

            # Ottieni il layer dal GPKG
            layer_obj = self.get_lotto_layer(layer)
            if layer_obj is None:
                continue

            # Controlla che il layer esista e che la geometria sia di tipo LineString
            geom_type = layer_obj.GetGeomType()
            if geom_type != ogr.wkbLineString:
                continue

            # Verifica ogni feature del layer
            layer_obj.ResetReading()
            while (feature := layer_obj.GetNextFeature()) is not None:
                fid = feature.GetFID()
                geom = feature.GetGeometryRef()

                # Se la geometria è None, segnala un errore
                if geom is None:
                    self.add_error(
                        layer_name=layer,
                        fid=str(fid),
                        field_name="geometry",
                        message="Geometria non presente",
                        severity=ErrorSeverity.CRITICAL,
                        metadata={"validation_type": "missing_geometry"},
                    )
                    check = False
                    continue

                # Calcola la lunghezza dell'elemento in metri
                lunghezza = geom.Length()

                # Controlla se la lunghezza è inferiore al valore minimo
                if lunghezza < self.context.CONST["min_lunghezza_tubo"]:
                    self.add_error(
                        layer_name=layer,
                        fid=str(fid),
                        field_name="geometry",
                        message=f"Lunghezza feature troppo corta: {lunghezza:.2f} m, minimo richiesto: {self.context.CONST['min_lunghezza_tubo']} m",
                        severity=ErrorSeverity.WARNING,
                        metadata={
                            "length_found": lunghezza,
                            "min_required": self.context.CONST["min_lunghezza_tubo"],
                            "validation_type": "feature_length_check",
                        },
                    )
                    check = False

        return check
