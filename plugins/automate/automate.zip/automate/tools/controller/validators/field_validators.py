# -*- coding: utf-8 -*-
"""
Field Validators - Validators per controlli sui campi.
Contiene validators per campi obbligatori, validazione valori, etc.
"""
# # 1. FUTURE IMPORTS
from __future__ import annotations

# # 2. STANDARD LIBRARY
from typing import List, Optional

# # 5. LOCAL IMPORTS
from ..error_types import ErrorSeverity
from . import ControllerContext, ValidatorRegistry
from .base_validator import BaseValidator


@ValidatorRegistry.register
class MandatoryFieldsValidator(BaseValidator):
    """
    Validator per verificare che i campi obbligatori siano compilati.

    Controlla che i campi UNIVOCO_FEATURE e UNIVOCO_LOTTO siano
    compilati per tutte le feature di tutti i layer SDI.
    """
    
    # Class variables per metadata (nuovo sistema)
    name: str = "mandatory_fields"
    description: str = "Verifica che i campi obbligatori siano compilati"
    display_name: str = "campi obbligatori"
    
    def __init__(self, context: ControllerContext):
        super().__init__(context)

    def validate(self, layers_sdi: Optional[List[str]] = None) -> bool:
        """
        Verifica che i campi obbligatori siano compilati.

        Args:
            layers_sdi: Lista custom di layer da verificare.
                       Se None, usa la lista dal context

        Returns:
            bool: True se tutti i campi obbligatori sono compilati, False altrimenti
        """
        # Usa la lista custom o quella dal context
        layers_sdi = self.get_sdi_layers()

        check = True
        # Cicla su tutti i layer
        for layer in layers_sdi:
            if not self.layer_exists(layer):
                continue

            # Ottieni la definizione del layer dal GPKG
            layer_obj = self.get_lotto_layer(layer)
            if layer_obj is None:
                continue

            # Verifica che i campi obbligatori siano compilati per ogni feature
            layer_obj.ResetReading()
            while (feature := layer_obj.GetNextFeature()) is not None:
                fid_str = str(feature.GetFID())

                # Lista dei campi obbligatori da verificare
                mandatory_fields = [
                    self.context.c["UNIVOCO_FEATURE"],
                    self.context.c["UNIVOCO_LOTTO"],
                ]

                for mandatory_field in mandatory_fields:
                    field_value = feature.GetFieldAsString(mandatory_field)
                    if not field_value:  # Se il campo è vuoto o None
                        error_msg = f"Campo '{mandatory_field}' non compilato"

                        self.add_error(
                            layer_name=layer,
                            fid=fid_str,
                            field_name=mandatory_field,
                            message=error_msg,
                            severity=ErrorSeverity.ERROR,
                            metadata={
                                "field_type": "mandatory",
                                "current_value": field_value or "",
                                "expected": "non-empty value",
                                "validation_type": "mandatory_field_check",
                            },
                        )
                        check = False

        return check
