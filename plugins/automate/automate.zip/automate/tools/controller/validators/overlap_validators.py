# -*- coding: utf-8 -*-
"""
Overlap Validators - Validators per controlli di sovrapposizione geometrica.
Contiene validators per sovrapposizioni tra layer di ripristini.
"""
# # 1. FUTURE IMPORTS
from __future__ import annotations

# # 2. STANDARD LIBRARY
from abc import ABC, abstractmethod

# # 5. LOCAL IMPORTS
from ..error_types import ErrorSeverity
from . import ControllerContext, ValidatorRegistry
from .base_validator import BaseValidator
from .overlap_detector import OverlapDetector


class BaseOverlapValidator(BaseValidator, OverlapDetector, ABC):
    """
    Classe base astratta per i validator di sovrapposizione.

    Contiene la logica comune per verificare sovrapposizioni geometriche
    tra feature di un layer.
    """
    def __init__(self, context: ControllerContext):
        super().__init__(context)

    @property
    @abstractmethod
    def target_layer(self) -> str:
        """Nome del layer su cui eseguire i controlli di sovrapposizione."""
        pass

    def validate(self) -> bool:
        """
        Verifica sovrapposizioni nel layer target raggruppando per livello.

        Returns:
            bool: True se non ci sono sovrapposizioni, False altrimenti
        """

        # Ottieni il layer target
        layer_obj = self.get_lotto_layer(self.target_layer)
        if not layer_obj:
            return True
        
        # Usa la nuova interfaccia _detect_overlap_zones che raggruppa automaticamente per livello
        overlap_zones = self._detect_overlap_zones(layer_obj, self.context)

        if not overlap_zones:
            return True
            
        # Ci sono sovrapposizioni - aggiungi errori
        # Determina il CRS dal layer
        crs = self.get_layer_crs(layer_obj)
        
        for _, zone_data in overlap_zones.items():
            zone_geometry = zone_data["geometry"]  # OGR Geometry
            zone_fids = zone_data["fids"]
            zone_univoci = zone_data["univoco"]
            zone_level = zone_data["level"]
            overlap_count = zone_data["overlap_count"]
            surface_area = zone_data["surface"]
            zone_id = zone_data["zone_id"] # uso zone_id per coerenza
            
            # Crea messaggio di errore descrittivo
            fids_str = ", ".join(str(f) for f in zone_fids)
            univoci_str = ", ".join(str(u) for u in zone_univoci)
            error_msg = (
                f"Poligoni sovrapposti per {surface_area:.2f} m² a livello '{zone_level}/NULL'."
                f"Eliminare la zona di overlap: "
                f"Zona {zone_id} "
                f"({overlap_count} geometrie con:  "
                f"FIDs: {fids_str} ovvero Univoci: {univoci_str}). "
            )
            
            self.add_error(
                layer_name=self.target_layer,
                fid=fids_str,
                field_name="geometry", 
                message=error_msg,
                severity=ErrorSeverity.ERROR,
                geometry=zone_geometry,
                crs=crs,
                metadata={
                    "validation_type": "geometric_overlap",
                    "level": zone_level,
                    "overlap_count": overlap_count,
                    "involved_fids": zone_fids,
                    "involved_univoci": zone_univoci,
                    "surface_area": round(surface_area, 4),
                    "zone_id": zone_id
                }
            )            
        
        return False


@ValidatorRegistry.register
class LayerRipristiniOverlapsReteValidator(BaseOverlapValidator):
    """
    Validator per verificare sovrapposizioni tra geometrie del layer ripristini rete.

    Controlla che non ci siano sovrapposizioni geometriche tra le feature
    del layer ripristini rete.
    """

    # Class variables per metadata (nuovo sistema)
    name: str = "overlap_ripristini_rete"
    description: str = "Verifica sovrapposizioni tra geometrie del layer ripristini rete"
    display_name: str = "sovrapposizione ripristini (rete)"

    @property
    def target_layer(self) -> str:
        return self.context.c["ly_ripristini"]


@ValidatorRegistry.register
class LayerRipristiniOverlapsAllacciamentiValidator(BaseOverlapValidator):
    """
    Validator per verificare sovrapposizioni tra geometrie del layer ripristini allacci.

    Controlla che non ci siano sovrapposizioni geometriche tra le feature
    del layer ripristini allacci.
    """

    # Class variables per metadata (nuovo sistema)
    name: str = "overlap_ripristini_allacci"
    description: str = "Verifica sovrapposizioni tra geometrie del layer ripristini allacci"
    display_name: str = "sovrapposizione ripristini (allacci)"

    @property
    def target_layer(self) -> str:
        return self.context.c["ly_ripristini_allacciamenti"]