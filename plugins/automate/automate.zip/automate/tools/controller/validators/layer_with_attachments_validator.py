# -*- coding: utf-8 -*-
"""
Layer With Attachments Validator - Validator per controllo allegati.
Verifica che gli allegati referenziati nei layer esistano fisicamente.
"""
# # 1. FUTURE IMPORTS
from __future__ import annotations

# # 2. STANDARD LIBRARY
from pathlib import Path

# # 3. THIRD-PARTY LIBRARIES
from osgeo import ogr

# # 5. LOCAL IMPORTS
from ..error_types import ErrorSeverity
from . import ControllerContext, ValidatorRegistry
from .base_validator import BaseValidator


@ValidatorRegistry.register
class LayerWithAttachmentsValidator(BaseValidator):
    """
    Validator per verificare la presenza di allegati per i layer specificati.

    Controlla che gli allegati referenziati nei layer esistano fisicamente
    nelle directory configurate.
    """

    # Class variables per metadata (nuovo sistema)
    name: str = "layer_with_attachments"
    description: str = "Verifica la presenza di allegati per i layer specificati"
    display_name: str = "allegati al layer"

    def __init__(self, context: ControllerContext):
        super().__init__(context)

    def validate(self) -> bool:
        """
        Controlla la presenza di allegati per i layer specificati.

        Args:
            layers_sdi: Lista custom di layer da verificare.
                       Se None, usa la lista dal context

        Returns:
            bool: True se tutti gli allegati sono presenti, False altrimenti
        """
        check = True

        # Cicla su tutti i layer
        for layer in self.get_sdi_layers():
            if not self.layer_exists(layer):
                continue

            layer_result = self._validate_layer_attachments(layer)
            if not layer_result:
                check = False

        return check

    def _validate_layer_attachments(self, layer: str) -> bool:
        """
        Valida gli allegati per un singolo layer.

        Args:
            layer: Nome del layer da validare

        Returns:
            bool: True se tutti gli allegati sono presenti, False altrimenti
        """
        # Ottieni le informazioni di allegato per il layer corrente
        try:
            result = self.context.db.get_layer_field_with_attach("", layer)
        except Exception as e:
            self.add_error(
                layer_name=layer,
                fid="*",
                field_name="*",
                message=f"Errore ottenimento info allegati: {e}",
                severity=ErrorSeverity.ERROR,
            )
            return False

        if not result:
            return True  # Nessun allegato configurato

        # Estrai informazioni allegato
        field, attached_dir, attached_type = result

        layer_obj = self.get_lotto_layer(layer)
        if layer_obj is None:
            return True

        # Verifica che il campo esista
        layer_fields = []
        layer_defn = layer_obj.GetLayerDefn()
        for i in range(layer_defn.GetFieldCount()):
            layer_fields.append(layer_defn.GetFieldDefn(i).GetName())

        if field not in layer_fields:
            return True  # Campo non presente, skip

        check = True

        # Controlla ogni feature nel layer corrente
        layer_obj.ResetReading()
        while (feature := layer_obj.GetNextFeature()) is not None:
            feature_result = self._validate_feature_attachment(
                layer, feature, field, attached_dir, attached_type
            )
            if not feature_result:
                check = False

        return check

    def _validate_feature_attachment(
        self,
        layer: str,
        feature: ogr.Feature,
        field: str,
        attached_dir: str,
        attached_type: str,
    ) -> bool:
        """
        Valida l'allegato per una singola feature.

        Args:
            layer: Nome del layer
            feature: Feature da validare
            field: Nome del campo allegato
            attached_dir: Directory degli allegati
            attached_type: Tipo di allegato

        Returns:
            bool: True se l'allegato è presente, False altrimenti
        """

        fid = feature.GetFID()
        value = feature.GetFieldAsString(field)

        # Skip valori vuoti
        if value == "":
            return True

        # Costruisci il path dell'allegato
        attached_file_path = Path(
            self.context.lotto_dir_path
            / self.context.CONST["dir_allegati"]
            / attached_dir
            / value
        )

        # Verifica che il file esista
        if not attached_file_path.exists():
            self.add_error(
                layer_name=layer,
                fid=str(fid),
                field_name=field,
                message=f"Allegato '{value}' non trovato nella cartella '{attached_file_path.parent}'",
                severity=ErrorSeverity.ERROR,
                metadata={
                    "file_path": str(attached_file_path),
                    "attachment_dir": attached_dir,
                    "attachment_type": attached_type,
                    "expected_filename": value,
                    "validation_type": "attachment_check",
                },
            )
            return False

        return True
