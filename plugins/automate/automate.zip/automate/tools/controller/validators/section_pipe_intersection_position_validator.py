# -*- coding: utf-8 -*-
"""
NewValidator - Descrizione del nuovo validator.
[Sostituisci questa descrizione con la funzionalità specifica]
"""
# # 1. FUTURE IMPORTS
from __future__ import annotations

# # 2. STANDARD LIBRARY
import math
from typing import Optional

# # 3. THIRD-PARTY LIBRARIES
from osgeo import ogr

# # 5. LOCAL IMPORTS
from ..error_types import ErrorSeverity
from . import ControllerContext, ValidatorRegistry
from .base_validator import BaseValidator


@ValidatorRegistry.register
class SectionPipeIntersectionPositionValidator(BaseValidator):
    """
    Validator per la verifica della corrispondenza del lato di posa delle tubazioni.
    
    Questo validator verifica che il campo lato_posa delle interferenze di sezione
    sia concorde con il lato effettivo di posa delle tubazioni, determinato tramite
    intersezione geometrica e calcolo delle distanze dai vertici.
    """
    
    # Class variables per metadata (sistema di registrazione)
    name: str = "section_vs_pipe_intersection"  # Nome tecnico per CLI e autodiscovery
    description: str = "Verifica corrispondenza tra lato posa tubazioni indicato e poszione della sezione rispetto alla tubazione"  # Help e documentazione
    display_name: str = "Sezione percorenza 2, lato posa indicato vs posizione sezione"  # Nome user-friendly per UI

    def __init__(self, context: ControllerContext):
        """
        Inizializza il validator con il context del controller.
        
        Args:
            context: Context condiviso del controller
        """
        super().__init__(context)
        # Aggiungi qui eventuali inizializzazioni specifiche del validator
        # self._cache = {}
        # self._config = self._load_config()

    def validate(self) -> bool:
        """
        Metodo principale di validazione per il lato di posa delle tubazioni.
        
        Returns:
            bool: True se tutte le validazioni sono corrette, False altrimenti
        """
        # Type narrowing per Pylance - attributi garantiti dal BaseValidator
        assert self.context.CONST is not None
        
        # Ottieni le costanti necessarie
        const = self.context.CONST
        
        # Verifica che tutti i layer necessari siano configurati
        required_layers = ['ly_interf_sez', 'ly_tubazione']
        for layer_key in required_layers:
            if layer_key not in const:
                print(f"⚠️  Layer {layer_key} non configurato, skip validazione")
                return True
        
        # Ottieni i layer OGR
        interf_layer = self.get_lotto_layer(const['ly_interf_sez'])
        tubazione_layer = self.get_lotto_layer(const['ly_tubazione'])
        
        if interf_layer is None or tubazione_layer is None:
            print("⚠️  Uno o più layer non esistono, skip validazione")
            return True
        
        # Valida ogni feature del layer interferenze
        check = True
        interf_layer.ResetReading()
        
        while (feature := interf_layer.GetNextFeature()) is not None:
            if not self._validate_feature(feature, const['ly_interf_sez'], tubazione_layer):
                check = False
        
        return check

    def _validate_feature(self, feature: ogr.Feature, layer_name: str, tubazione_layer: ogr.Layer) -> bool:
        """
        Valida una singola feature del layer interferenze di sezione.
        
        Args:
            feature: Feature OGR da validare (interferenza sezione)
            layer_name: Nome del layer per error reporting
            tubazione_layer: Layer delle tubazioni per l'intersezione
            
        Returns:
            bool: True se la feature è valida, False altrimenti
        """
        assert self.context.CONST is not None
        const = self.context.CONST
        
        fid = feature.GetFID()
        
        # Ottieni il CRS del layer delle sezioni
        interf_layer = self.get_lotto_layer(const['ly_interf_sez'])
        layer_crs = self.get_layer_crs(interf_layer) if interf_layer else "EPSG:32633"
        
        # Per il layer SGA_INTERF_SEZ non c'è filtro su tipo_interv
        # Il filtro si applica solo alle tubazioni durante l'intersezione
        
        # Ottieni la geometria dell'interferenza
        interf_geom = feature.GetGeometryRef()
        if interf_geom is None:
            self.add_error(
                layer_name=layer_name,
                fid=str(fid),
                field_name="geometry",
                message="Geometria mancante",
                severity=ErrorSeverity.ERROR,
                metadata={"validation_type": "geometry_missing"}
            )
            return False
        
        # Verifica che la geometria sia una linea
        geom_type = interf_geom.GetGeometryType()
        if geom_type not in [ogr.wkbLineString, ogr.wkbMultiLineString]:
            self.add_error(
                layer_name=layer_name,
                fid=str(fid),
                field_name="geometry",
                message="La geometria deve essere di tipo linea",
                severity=ErrorSeverity.ERROR,
                metadata={"validation_type": "invalid_geometry_type", "geometry_type": geom_type}
            )
            return False
        
        # Trova l'intersezione con le tubazioni
        intersection_point = self._find_intersection_with_tubazioni(interf_geom, tubazione_layer)
        
        
        if intersection_point is None:
            # Ottieni il punto centrale della sezione per localizzare l'errore
            center_point = self._get_section_center_point(interf_geom)
            
            self.add_error(
                layer_name=layer_name,
                fid=str(fid),
                field_name="geometry",
                message=f"Nessuna intersezione trovata con le tubazioni",
                severity=ErrorSeverity.WARNING,
                geometry=center_point,
                crs=layer_crs,
                metadata={
                    "validation_type": "no_intersection",
                }
            )
            return True  # Non è un errore bloccante
        
        # Determina il lato di posa basato sulla geometria
        determined_side = self._determine_lateral_position(interf_geom, intersection_point)
        
        # Verifica concordanza con il campo lato_posa
        lato_posa_field = const.get('field_lato_posa', 'COD_LATO_POSA')
        recorded_side = feature.GetField(lato_posa_field)
        
        if recorded_side != determined_side:
            side_name_recorded = "sinistra" if recorded_side == const.get('value_lato_posa_sx', 1) else "destra"
            side_name_determined = "sinistra" if determined_side == const.get('value_lato_posa_sx', 1) else "destra"
            
            # Ottieni le coordinate e geometria per il report dell'errore
            if intersection_point is not None:
                ref_point = intersection_point
                ref_description = "punto intersezione"
            else:
                # Punto centrale della sezione
                ref_point = self._get_section_center_point(interf_geom)
                ref_description = "centro sezione"
            
            
            self.add_error(
                layer_name=layer_name,
                fid=str(fid),
                field_name=lato_posa_field,
                message=f"Lato posa non concorde: registrato {side_name_recorded}, calcolato {side_name_determined}",
                severity=ErrorSeverity.ERROR,
                geometry=ref_point,
                crs=layer_crs,
                metadata={
                    "validation_type": "lateral_position_mismatch",
                    "recorded_side": recorded_side,
                    "determined_side": determined_side,
                    "reference_type": ref_description
                }
            )
            return False
        
        return True

    def _find_intersection_with_tubazioni(self, interf_geom: ogr.Geometry, tubazione_layer: ogr.Layer) -> Optional[ogr.Geometry]:
        """
        Trova il punto di intersezione tra la geometria dell'interferenza e le tubazioni.
        Utilizza l'indice spaziale per migliorare le performance.
        
        Args:
            interf_geom: Geometria dell'interferenza di sezione
            tubazione_layer: Layer delle tubazioni
            
        Returns:
            Geometria del punto di intersezione o None se non trovata
        """
        assert self.context.CONST is not None
        const = self.context.CONST
        
        # Ottieni l'envelope (bounding box) dell'interferenza per il filtro spaziale
        envelope = interf_geom.GetEnvelope()  # (minX, maxX, minY, maxY)
        
        # Applica filtro spaziale usando l'indice spaziale del layer
        tubazione_layer.SetSpatialFilterRect(envelope[0], envelope[2], envelope[1], envelope[3])
        
        # Configura il filtro per il tipo di intervento
        tipo_interv_field = const.get('field_tipo_interv', 'COD_TIPO_INTERV')
        nuova_posa_value = const.get('value_tipo_intervento_nuova_posa', 1)
        
        # Applica anche filtro attributi se possibile per ulteriori ottimizzazioni
        filter_sql = f"{tipo_interv_field} = {nuova_posa_value}"
        tubazione_layer.SetAttributeFilter(filter_sql)
        
        tubazione_layer.ResetReading()
        
        while (tub_feature := tubazione_layer.GetNextFeature()) is not None:
            # Il filtro attributi già garantisce che sia nuova posa, ma manteniamo 
            # il controllo come fallback nel caso il filtro non sia supportato
            try:
                tipo_interv = tub_feature.GetField(tipo_interv_field)
                if tipo_interv != nuova_posa_value:
                    continue
            except:
                # Se il campo non esiste, skip questa feature
                continue
            
            tub_geom = tub_feature.GetGeometryRef()
            if tub_geom is None:
                continue
            
            # 1. Calcola l'intersezione geometrica
            intersection = interf_geom.Intersection(tub_geom)
            # 2. Se c'è un'intersezione geometrica valida
            if intersection is not None and not intersection.IsEmpty():
                # 2.1. INTERSEZIONE PUNTUALE DIRETTA
                # SOLO punti sono intersezioni valide - ignora sovrapposizioni lineari
                if intersection.GetGeometryType() == ogr.wkbPoint:
                    return intersection # ✅ Punto di intersezione
                # 2.2. SOVRAPPOSIZIONE LINEARE - ignorata
                elif intersection.GetGeometryType() in [ogr.wkbLineString, ogr.wkbMultiLineString]:
                    # Potrebbe essere sovrapposizione 
                    # Sovrapposizione lineare - ignora questa tubazione e continua
                    continue # ❌ Sovrapposizione - ignora
                # 2.3. PUNTI MULTIPLI
                elif intersection.GetGeometryType() == ogr.wkbMultiPoint:
                    # Multipli punti di intersezione - prendi il primo
                    if intersection.GetGeometryCount() > 0:
                        first_point = intersection.GetGeometryRef(0)
                        if first_point and first_point.GetGeometryType() == ogr.wkbPoint:
                            return first_point # ✅ Primo punto multiplo
                
                # Altri tipi di geometria - continua la ricerca
                continue
            
            # 3. Se NON c'è intersezione geometrica, controlla i vertici
            # controlla se l'intersezione coincide con un vertice della tubazione
            vertex_point = self._check_vertex_intersection(interf_geom, tub_geom)
            if vertex_point is not None:
                return vertex_point  # ✅ Intersezione su vertice
            
        # Rimuovi i filtri per ripristinare lo stato originale del layer
        tubazione_layer.SetSpatialFilter(None)
        tubazione_layer.SetAttributeFilter(None)
        
        return None
    
    def _determine_lateral_position(self, interf_geom: ogr.Geometry, intersection_point: ogr.Geometry) -> int:
        """
        Determina il lato di posa basato sulla distanza del punto di intersezione dai vertici dell'interferenza.
        
        Args:
            interf_geom: Geometria dell'interferenza (dovrebbe essere una linea)
            intersection_point: Punto di intersezione con la tubazione
            
        Returns:
            Codice del lato di posa (sx o dx)
        """
        assert self.context.CONST is not None
        const = self.context.CONST
        
        # Ottieni i valori per sinistra e destra
        value_sx = const.get('value_lato_posa_sx', 1)
        value_dx = const.get('value_lato_posa_dx', 2)
        
        # Estrai le coordinate del punto di intersezione
        intersection_x = intersection_point.GetX()
        intersection_y = intersection_point.GetY()
        
        # Ottieni i vertici della geometria dell'interferenza
        if interf_geom.GetGeometryType() == ogr.wkbLineString:
            line = interf_geom
        elif interf_geom.GetGeometryType() == ogr.wkbMultiLineString:
            line = interf_geom.GetGeometryRef(0)  # Prima linea
        else:
            line = None
        
        if line is None or line.GetPointCount() < 2:
            # Fallback: assumiamo lato destro se non abbiamo abbastanza punti
            return value_dx
        
        # Primo e ultimo vertice della linea
        first_x, first_y = line.GetX(0), line.GetY(0)
        last_x, last_y = line.GetX(line.GetPointCount() - 1), line.GetY(line.GetPointCount() - 1)
        
        # Calcola le distanze
        dist_to_first = self._calculate_distance(intersection_x, intersection_y, first_x, first_y)
        dist_to_last = self._calculate_distance(intersection_x, intersection_y, last_x, last_y)
        
        # Se è più vicino al primo vertice -> sinistra, altrimenti -> destra
        if dist_to_first < dist_to_last:
            return value_sx
        else:
            return value_dx
    
    def _calculate_distance(self, x1: float, y1: float, x2: float, y2: float) -> float:
        """
        Calcola la distanza euclidea tra due punti.
        
        Args:
            x1, y1: Coordinate del primo punto
            x2, y2: Coordinate del secondo punto
            
        Returns:
            Distanza tra i due punti
        """
        return math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2)
    
    def _check_vertex_intersection(self, interf_geom: ogr.Geometry, tub_geom: ogr.Geometry) -> Optional[ogr.Geometry]:
        """
        Controlla se l'interferenza passa su un vertice (iniziale o finale) della tubazione.
        Questo è considerato un'intersezione valida.
        
        Args:
            interf_geom: Geometria dell'interferenza di sezione
            tub_geom: Geometria della tubazione
            
        Returns:
            Punto del vertice se c'è intersezione, None altrimenti
        """
        assert self.context.CONST is not None
        const = self.context.CONST
        
        # Ottieni la linea principale della tubazione
        if tub_geom.GetGeometryType() == ogr.wkbLineString:
            tub_line = tub_geom
        elif tub_geom.GetGeometryType() == ogr.wkbMultiLineString:
            tub_line = tub_geom.GetGeometryRef(0)  # Prima linea
        else:
            return None
        
        if tub_line is None or tub_line.GetPointCount() < 2:
            return None
        
        # Crea punti per il primo e ultimo vertice della tubazione
        first_vertex = ogr.Geometry(ogr.wkbPoint)
        first_vertex.AddPoint(tub_line.GetX(0), tub_line.GetY(0))
        
        last_vertex = ogr.Geometry(ogr.wkbPoint)
        last_vertex.AddPoint(
            tub_line.GetX(tub_line.GetPointCount() - 1),
            tub_line.GetY(tub_line.GetPointCount() - 1)
        )
        
        # Controlla se l'interferenza interseca i vertici con una tolleranza minima
        tolerance = const['max_distance_interf_sez'] # 0.01 m # Tolleranza da costanti
        
        # Controlla primo vertice
        if interf_geom.Distance(first_vertex) <= tolerance:
            return first_vertex
        
        # Controlla ultimo vertice
        if interf_geom.Distance(last_vertex) <= tolerance:
            return last_vertex
        
        return None
    
    def _get_section_center_point(self, interf_geom: ogr.Geometry) -> ogr.Geometry:
        """
        Calcola il punto centrale della sezione di interferenza.
        
        Args:
            interf_geom: Geometria dell'interferenza di sezione
            
        Returns:
            Punto centrale della geometria
        """
        # Ottieni la linea principale
        if interf_geom.GetGeometryType() == ogr.wkbLineString:
            line = interf_geom
        elif interf_geom.GetGeometryType() == ogr.wkbMultiLineString:
            line = interf_geom.GetGeometryRef(0)  # Prima linea
        else:
            # Fallback: usa il centroide
            centroid = interf_geom.Centroid()
            return centroid if centroid else self._create_point(0, 0)
        
        if line is None or line.GetPointCount() == 0:
            return self._create_point(0, 0)
        
        # Calcola il punto centrale della linea usando Value() per qualsiasi tipo di linea
        # Questo garantisce che il punto sia effettivamente sulla geometria
        line_length = line.Length()
        if line_length > 0:
            # Usa Value() per ottenere un punto a metà della lunghezza della linea
            mid_distance = line_length / 2.0
            mid_point = line.Value(mid_distance)
            return mid_point if mid_point else self._create_point(0, 0)
        else:
            # Linea con lunghezza zero, usa il primo punto
            return self._create_point(line.GetX(0), line.GetY(0))
    
    def _create_point(self, x: float, y: float) -> ogr.Geometry:
        """
        Crea un punto OGR dalle coordinate.
        
        Args:
            x, y: Coordinate del punto
            
        Returns:
            Geometria punto OGR
        """
        point = ogr.Geometry(ogr.wkbPoint)
        point.AddPoint(x, y)
        return point