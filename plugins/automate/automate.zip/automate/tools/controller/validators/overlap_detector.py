# -*- coding: utf-8 -*-
"""
Pure OGR Geometric Overlap Detector - Equivalente di GeometricOverlapMixin usando solo OGR.

Implementa lo stesso algoritmo Connected Components del GeometricOverlapMixin
ma utilizzando esclusivamente la libreria OGR/GDAL per le operazioni geometriche.
"""

# # 2. STANDARD LIBRARY
from collections import defaultdict
from itertools import combinations
from typing import Any, Dict, List, Optional

# # 3. THIRD-PARTY LIBRARIES
from osgeo import ogr


class UnionFind:
    """Struttura dati Union-Find per raggrupare elementi connessi."""
    
    def __init__(self, n):
        self.parent = list(range(n))
        self.rank = [0] * n
    
    def find(self, x):
        if self.parent[x] != x:
            self.parent[x] = self.find(self.parent[x])  # Path compression
        return self.parent[x]
    
    def union(self, x, y):
        px, py = self.find(x), self.find(y)
        if px == py:
            return
        # Union by rank
        if self.rank[px] < self.rank[py]:
            px, py = py, px
        self.parent[py] = px
        if self.rank[px] == self.rank[py]:
            self.rank[px] += 1
    
    def get_components(self):
        """Restituisce i gruppi connessi come lista di liste."""
        components = defaultdict(list)
        for i in range(len(self.parent)):
            components[self.find(i)].append(i)
        return list(components.values())


class OverlapDetector:
    """
    Rilevatore di sovrapposizioni geometriche usando solo OGR.
    
    Implementa:
    - Connected Components con Union-Find per raggruppare geometrie che si intersecano
    - Filtro per area minima per ignorare micro-sovrapposizioni
    - Algoritmo gerarchico applicato solo sui gruppi connessi piccoli
    - Operazioni geometriche pure OGR per performance
    - Scalabilità: O(n²) + O(2^dimensione_gruppo) invece di O(2^n)
    """
    
    def __init__(self):
        """
        Inizializza il rilevatore.
        
        """

    def detect_overlap_zones(self, geometries_with_metadata: List[Dict[str, Any]], threshold: float = 0.01) -> List[ogr.Geometry]:
        """
        Rileva tutte le zone di sovrapposizione usando algoritmo Connected Components.
        
        Questo è il metodo principale che coordina l'intero processo:
        1. Raggruppa geometrie che si intersecano in componenti connessi (Union-Find)
        2. Per ogni gruppo, applica l'algoritmo gerarchico originale
        3. Combina i risultati di tutti i gruppi
        
        Args:
            geometries_with_metadata: Lista di dict con chiavi: fid, cod_ripristino, geometry (ogr.Geometry)
            threshold: Soglia area minima in m² per considerare significativa una sovrapposizione

        Returns:
            List[ogr.Geometry]: Lista delle zone di sovrapposizione mutualmente esclusive
        """
        if not geometries_with_metadata or len(geometries_with_metadata) < 2:
            return []

        print(f"🚀 Avvio rilevamento sovrapposizioni con algoritmo Connected Components (Pure OGR)...")
        print(f"📊 Geometrie da analizzare: {len(geometries_with_metadata)}")
        print(f"📏 Soglia area minima: {threshold} m²")

        # Estrai le zone di sovrapposizione (nuova struttura)
        overlap_zones_data = self._extract_overlap_zones(geometries_with_metadata, threshold)
        
        # Estrai solo le geometrie per mantenere retrocompatibilità con interfaccia deprecata
        overlap_zones = [zone['geometry'] for zone in overlap_zones_data]

        print(f"🎯 Analisi completata: {len(overlap_zones)} zone di sovrapposizione rilevate")
        return overlap_zones

    def _extract_overlap_zones(self, geometries_with_metadata: List[Dict[str, Any]], threshold: float) -> List[Dict[str, Any]]:
        """
        Estrae le zone di sovrapposizione usando algoritmo Connected Components con OGR.
        
        Processo:
        1. Test intersezioni dirette a coppie con filtro area minima
        2. Raggruppa geometrie intersecanti in componenti connessi (Union-Find)
        3. Applica algoritmo gerarchico complesso originale solo sui singoli gruppi connessi
        
        Vantaggi:
        - Scalabilità: O(n²) + O(2^dimensione_gruppo) invece di O(2^n)
        - Precisione: mantiene tutta la logica gerarchica originale
        - Efficienza: gruppi piccoli = calcoli rapidi
        
        Args:
            geometries_with_metadata: Lista di geometrie con metadati
            threshold: Soglia area minima in m² per considerare significativa una sovrapposizione
            
        Returns:
            List[Dict[str, Any]]: Zone di sovrapposizione con metadati
                                 Ogni dict contiene: geometry, involved_fids, involved_univoci, overlap_count
        """
        if not geometries_with_metadata or len(geometries_with_metadata) < 2:
            return []

        n_geometries = len(geometries_with_metadata)

        print(f"🚀 Avvio rilevamento sovrapposizioni con algoritmo Connected Components (Pure OGR)...")
        print(f"📊 Geometrie da analizzare: {n_geometries}")
        print(f"📏 Soglia area minima: {threshold} m²")
        
        # Step 1: Test intersezioni dirette a coppie con filtro area
        intersecting_pairs = set()
        intersection_tests = 0
        filtered_out_count = 0
        
        print(f"🔍 Test intersezioni dirette a coppie...")
        
        for i in range(n_geometries):
            geom_i = geometries_with_metadata[i]["geometry"]
            
            for j in range(i + 1, n_geometries):
                geom_j = geometries_with_metadata[j]["geometry"]
                intersection_tests += 1
                
                # Test intersezione geometrica diretta con OGR
                if geom_i.Intersects(geom_j):
                    intersection = geom_i.Intersection(geom_j)
                    
                    if intersection and not intersection.IsEmpty():
                        # Verifica che l'intersezione sia una superficie (Polygon/MultiPolygon)
                        geom_type = intersection.GetGeometryType()
                        if geom_type not in [ogr.wkbPolygon, ogr.wkbMultiPolygon]:
                            # Skip geometrie non-areali (LineString, Point, etc.)
                            continue
                            
                        intersection_area = intersection.Area()

                        if intersection_area > threshold:
                            intersecting_pairs.add((i, j))
                            fid_i = geometries_with_metadata[i].get('fid')
                            fid_j = geometries_with_metadata[j].get('fid')
                            print(f"   ✅ Sovrapposizione significativa FID {fid_i}-{fid_j}: {intersection_area:.6f} m²")
                        else:
                            filtered_out_count += 1
                            fid_i = geometries_with_metadata[i].get('fid')
                            fid_j = geometries_with_metadata[j].get('fid')
                            print(f"   🚫 Micro-sovrapposizione ignorata FID {fid_i}-{fid_j}: {intersection_area:.6f} m² < {threshold} m²")

        print(f"✅ Test intersezioni: {len(intersecting_pairs)} coppie significative "
              f"da {intersection_tests} test geometrici "
              f"({filtered_out_count} micro-sovrapposizioni filtrate)")
        
        if not intersecting_pairs:
            print(f"🎯 Nessuna sovrapposizione significativa trovata")
            return []
        
        # Step 2: Raggruppa geometrie connesse usando Union-Find
        print(f"🔗 Creazione gruppi connessi...")
        union_find = UnionFind(n_geometries)
        
        for i, j in intersecting_pairs:
            union_find.union(i, j)
        
        connected_components = union_find.get_components()
        
        # Filtra solo i gruppi con sovrapposizioni (>= 2 geometrie)
        overlap_groups = [group for group in connected_components if len(group) >= 2]
        isolated_count = len(connected_components) - len(overlap_groups)
        
        print(f"📊 Analisi gruppi connessi:")
        print(f"   🔗 {len(overlap_groups)} gruppi con sovrapposizioni")
        print(f"   🔸 {isolated_count} geometrie isolate (senza sovrapposizioni)")
        
        if overlap_groups:
            print(f"📍 Gruppi con sovrapposizioni:")
            for idx, group in enumerate(overlap_groups):
                fids = [geometries_with_metadata[i].get('fid') for i in group]
                print(f"   Gruppo {idx+1}: {len(group)} geometrie (FID: {fids})")
        
        # Step 3: Applica algoritmo gerarchico sui gruppi con sovrapposizioni
        all_overlap_zones = []
        
        for group_idx, group in enumerate(overlap_groups):
            print(f"🎯 Elaborazione gruppo {group_idx+1}/{len(overlap_groups)} con {len(group)} geometrie...")
            
            # Estrai le geometrie del gruppo
            group_geometries = [geometries_with_metadata[i] for i in group]
            
            # Applica algoritmo gerarchico originale al gruppo
            group_overlap_zones = self._extract_overlap_zones_hierarchical(group_geometries)
            all_overlap_zones.extend(group_overlap_zones)
            
            print(f"   ✅ Gruppo {group_idx+1}: {len(group_overlap_zones)} zone di sovrapposizione")
        
        print(f"🎉 Elaborazione completata: {len(all_overlap_zones)} zone totali da tutti i gruppi")
        return all_overlap_zones

    def _extract_overlap_zones_hierarchical(self, geometries_with_metadata: List[Dict]) -> List[Dict[str, Any]]:
        """
        Algoritmo gerarchico per estrarre zone di sovrapposizione mutualmente esclusive con OGR.
        
        Args:
            geometries_with_metadata: Lista di geometrie del gruppo connesso con chiavi: geometry, fid, univoco
            
        Returns:
            List[Dict[str, Any]]: Zone di sovrapposizione con metadati
                                 Ogni dict contiene: geometry, involved_fids, involved_univoci, overlap_count
        """
        if len(geometries_with_metadata) < 2:
            return []

        print(f"   🔧 Algoritmo gerarchico con OGR su {len(geometries_with_metadata)} geometrie...")

        # Calcola tutte le intersezioni possibili per questo gruppo
        all_intersections = {}
        processed_combinations = 0
        n_geometries = len(geometries_with_metadata)

        # Calcola tutte le intersezioni possibili
        for combination_size in range(2, n_geometries + 1):
            for indices in combinations(range(n_geometries), combination_size):
                processed_combinations += 1
                
                # Calcola intersezione di tutte le geometrie nella combinazione usando OGR
                intersection_geom = None
                for idx in indices:
                    geom = geometries_with_metadata[idx]["geometry"]
                    if intersection_geom is None:
                        intersection_geom = geom.Clone()  # Clona per non modificare l'originale
                    else:
                        intersection_geom = intersection_geom.Intersection(geom)
                    
                    if intersection_geom.IsEmpty():
                        break  # Ottimizzazione: se vuota, non continuare
                
                if intersection_geom and not intersection_geom.IsEmpty():
                    # Pulisci la geometria con buffer(0)
                    cleaned_geom = self._clean_geometry_ogr(intersection_geom)
                    
                    if cleaned_geom and not cleaned_geom.IsEmpty():
                        # Verifica che sia una superficie prima di chiamare Area()
                        geom_type = cleaned_geom.GetGeometryType()
                        if geom_type in [ogr.wkbPolygon, ogr.wkbMultiPolygon] and cleaned_geom.Area() > 0:
                            involved_fids = [geometries_with_metadata[idx].get('fid') for idx in indices]
                            # Usa 'univoco' invece di 'cod_ripristino' per la nuova struttura dati
                            involved_codes = [geometries_with_metadata[idx].get('univoco') for idx in indices]

                            all_intersections[indices] = {
                                'geometry': cleaned_geom,
                                'involved_fids': involved_fids,
                                'involved_codes': involved_codes,
                                'overlap_count': len(indices)
                            }

        print(f"   📊 Processate {processed_combinations} combinazioni, {len(all_intersections)} intersezioni valide")

        # Applica sottrazione gerarchica per zone mutualmente esclusive
        return self._create_mutually_exclusive_zones_ogr(all_intersections)

    def _create_mutually_exclusive_zones_ogr(self, all_intersections: Dict) -> List[Dict[str, Any]]:
        """
        Crea zone mutualmente esclusive applicando sottrazione gerarchica con OGR.
        
        Rimuove dalle zone di overlap più basso le aree già coperte da zone di overlap più alto.
        Args:
            all_intersections: Dizionario con tutte le intersezioni calcolate
            
        Returns:
            List[Dict[str, Any]]: Zone mutualmente esclusive con metadati
                                 Ogni dict contiene: geometry, involved_fids, involved_univoci, overlap_count
        """
        if not all_intersections:
            return []

        print(f"   🎯 Creazione zone mutualmente esclusive da {len(all_intersections)} intersezioni con OGR...")
        
        # Ordina per numero di overlaps decrescente (zone più complesse prima)
        sorted_intersections = sorted(all_intersections.items(), 
                                    key=lambda x: x[1]['overlap_count'], 
                                    reverse=True)
        
        mutually_exclusive_zones = []
        
        for indices, intersection_data in sorted_intersections:
            current_geometry = intersection_data['geometry'].Clone()
            
            # Sottrai tutte le zone già processate (con overlap più alto) usando OGR
            for existing_zone_data in mutually_exclusive_zones:
                existing_geom = existing_zone_data['geometry']
                if current_geometry.Intersects(existing_geom):
                    current_geometry = current_geometry.Difference(existing_geom)
                    current_geometry = self._clean_geometry_ogr(current_geometry)
                    
                    if not current_geometry or current_geometry.IsEmpty():
                        break
            
            # Aggiungi la zona risultante se valida
            if current_geometry and not current_geometry.IsEmpty():
                # Verifica che sia una superficie prima di chiamare Area()
                geom_type = current_geometry.GetGeometryType()
                if geom_type in [ogr.wkbPolygon, ogr.wkbMultiPolygon] and current_geometry.Area() > 0:
                    # Crea la struttura dati completa
                    zone_data = {
                        'geometry': current_geometry,
                        'involved_fids': intersection_data['involved_fids'],
                        'involved_univoci': intersection_data['involved_codes'],
                        'overlap_count': intersection_data['overlap_count']
                    }
                    mutually_exclusive_zones.append(zone_data)
        
        print(f"   ✅ Create {len(mutually_exclusive_zones)} zone mutualmente esclusive con OGR")
        return mutually_exclusive_zones

    def _clean_geometry_ogr(self, geom: ogr.Geometry) -> Optional[ogr.Geometry]:
        """
        Pulisce una geometria da artefatti numerici usando OGR.
        
        Args:
            geom: ogr.Geometry da pulire
            
        Returns:
            ogr.Geometry: Geometria pulita e valida, o None se non pulibile
        """
        if not geom or geom.IsEmpty():
            return None
        
        try:
            # Buffer(0) per correggere problemi topologici con OGR
            cleaned = geom.Buffer(0.0)  # Buffer zero per pulizia
            
            if cleaned and not cleaned.IsEmpty():
                # Verifica che sia una superficie prima di chiamare Area()
                geom_type = cleaned.GetGeometryType()
                if geom_type in [ogr.wkbPolygon, ogr.wkbMultiPolygon] and cleaned.Area() > 0:
                    return cleaned
                else:
                    return None
            else:
                return None
                
        except Exception as e:
            print(f"   ⚠️ Errore pulizia geometria: {e}")
            return None



    def _detect_overlap_zones(self, layer_obj: ogr.Layer, context) -> Dict[int, Dict[str, Any]]:
        """
        Rileva e analizza zone di sovrapposizione significative in un layer.

        Raggruppa le geometrie per livello e identifica zone di sovrapposizione 
        mutualmente esclusive utilizzando un algoritmo gerarchico avanzato.
        Filtra le zone per area minima accettabile.

        Args:
            layer_obj (ogr.Layer): Layer di input da analizzare
            context: Context contenente le costanti e configurazioni

        Returns:
            Dict[int, Dict[str, Any]]: Dizionario con le zone di sovrapposizione rilevate.
                                      Chiave: ID progressivo
                                      Valore: Dizionario con geometry, surface, fids, univoco, etc.
        """
        
        level_groups = defaultdict(list)
        total_features = 0
        
        for feature in layer_obj:
            total_features += 1
            level_value = feature.GetField(context.c["field_livello"])
            level_value = level_value if level_value is not None else context.c["value_livello_standard"]
            fid = feature.GetFID()
            univoco_value = feature.GetField(context.c["UNIVOCO_FEATURE"])
            geom = feature.GetGeometryRef()
            if geom:
                level_groups[level_value].append({
                    "fid": fid,
                    "univoco": univoco_value,
                    "geometry": geom.Clone()
                })
        
        # 2. Analisi overlay per scomporre tutte le sovrapposizioni
        result_dict = {}
        id_counter = 0
        for level, features in level_groups.items():
            
            if len(features) < 2:
                continue
            
            # Estrae tutte le geometrie con metadati per l'overlay analysis
            geometries_with_metadata = [
                {
                    "fid": f["fid"],
                    "univoco": f["univoco"], 
                    "geometry": f["geometry"]
                } 
                for f in features
            ]
            
            # Crea l'overlay di tutte le geometrie per trovare le zone di sovrapposizione
            # Usa la soglia minima accettabile dal context
            threshold = context.c["max_area_sovrapposizione_ripristino_accettabile"]
            overlap_zones = self._extract_overlap_zones(geometries_with_metadata, threshold)
            
            if not overlap_zones:
                continue
            
            # Processa ogni zona di sovrapposizione come elemento separato
            for i, zone in enumerate(overlap_zones):
                zone_geometry = zone["geometry"]
                zone_fids = zone["involved_fids"] 
                zone_univoci = zone["involved_univoci"]
                overlap_count = zone["overlap_count"]
                
                # Filtra per area minima accettabile
                if zone_geometry.Area() < context.c["max_area_sovrapposizione_ripristino_accettabile"]:
                    continue
                
                # Aggiunta al dizionario di output
                result_dict[id_counter] = {
                    "zone_id": i + 1,  # Identificativo della zona
                    "geometry": zone_geometry,
                    "surface": zone_geometry.Area(),
                    "fids": sorted(zone_fids),
                    "univoco": sorted(zone_univoci),
                    "level": level,
                    "overlap_count": overlap_count  # Quante geometrie si sovrappongono
                }
                id_counter += 1

        return result_dict

