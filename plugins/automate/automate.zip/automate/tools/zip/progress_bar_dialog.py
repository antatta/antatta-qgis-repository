# -*- coding: utf-8 -*-
"""
/***************************************************************************
 ProgressBarDialog
                                 A QGIS plugin
 The AUTOMATE plug-in
                             -------------------
        begin                : 2024-09-23
        copyright            : (C) 2024 by Ing. Antonio Attadia
        email                : antonio.attadia@italgas.it
        git sha              : $Format:%H$
 ***************************************************************************/
 progress bar to show zip process progression
"""
import os

from qgis.PyQt import uic
from qgis.PyQt import QtWidgets

# This loads your .ui file so that PyQt can populate your plugin with the elements from Qt Designer
FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'ProgressBarDialog.ui'))


class ProgressBarDialog(QtWidgets.QDialog, FORM_CLASS):
    def __init__(self, parent=None):
        """Constructor."""
        super(ProgressBarDialog, self).__init__(parent)
        # Set up the user interface from Designer through FORM_CLASS.
        # After self.setupUi() you can access any designer object by doing
        # self.<objectname>, and you can use autoconnect slots - see
        # http://qt-project.org/doc/qt-4.8/designer-using-a-ui-file.html
        # #widgets-and-dialogs-with-auto-connect
        self.setupUi(self)
        self.progressBar:QtWidgets.QProgressBar
        self.label_max:QtWidgets.QLabel
        
        return
        
    def set_max(self, valore_massimo:int):
        self.label_max.setText(f"{valore_massimo}")
        self.progressBar.setMaximum(valore_massimo)
        return
    
    def set_value(self, valore_avanzamento:int):
        self.progressBar.setValue(valore_avanzamento)
        return
    
    def get_value(self):
        return self.progressBar.value()
    
    def increment(self):
        valore_corrente = self.get_value()
        self.set_value(valore_corrente + 1)