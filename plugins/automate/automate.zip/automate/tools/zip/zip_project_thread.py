# -*- coding: utf-8 -*-
"""
/***************************************************************************
 ZipProjectThread
                                 A QGIS plugin
 The AUTOMATE plug-in
                             -------------------
        begin                : 2024-09-23
        copyright            : (C) 2024 by Ing. Antonio Attadia
        email                : info.antatta@gmail.com
        git sha              : $Format:%H$
 ***************************************************************************/
 Thread class to zip project files asynchronously
"""
# # 1. FUTURE IMPORTS
from __future__ import annotations

# # 2. STANDARD LIBRARY
import traceback
import zipfile
from pathlib import Path

# # 3. THIRD-PARTY LIBRARIES
from PyQt5.QtCore import QThread, pyqtSignal


class ZipProjectThread(QThread):
    # Definizione dei segnali per la comunicazione tra thread e main thread
    progress = pyqtSignal(str)
    completed = pyqtSignal(str)  # Segnale custom per il messaggio di completamento
    error = pyqtSignal(str)

    def __init__(self, project_home_path:Path, project_file_path:Path, lotto_dir_path:Path, zip_file_path:Path):
        """
        Initialize the zip thread.
        
        :param home_path: Project home directory path
        :param project_path: Project file path  
        :param project_subdir: Project subdirectory to compress
        :param zip_file_path: Target zip file path
        """
        super().__init__()
        self.project_home_path:Path = project_home_path
        self.project_file_path:Path = project_file_path
        self.lotto_dir_path:Path = lotto_dir_path
        self.zip_file_path:Path = zip_file_path

    def run(self):
        """Execute the zip compression in the thread."""
        try:
            # Converte Path a stringa per compatibilità
            zip_path_str = str(self.zip_file_path)
            
            # Crea lo zip mantenendo la struttura della directory
            with zipfile.ZipFile(zip_path_str, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as zipf:
                # Aggiungi il file del progetto
                zipf.write(self.project_file_path, Path(self.project_file_path).name)
                progress_msg = f"Aggiunto il file del progetto: {Path(self.project_file_path).name}"
                self.progress.emit(progress_msg)

                # Directory con il nome del progetto
                for file in self.lotto_dir_path.rglob('*'):
                    if file.is_file():
                        rel_path = file.relative_to(self.project_home_path)
                        progress_msg = f"Aggiungendo: {file.name}"
                        self.progress.emit(progress_msg)
                        zipf.write(str(file), str(rel_path))  # Converti Path a stringa
            
        except Exception as e:
            error_msg = f"Errore nella creazione del file zip: {e}\nTraceback:\n{traceback.format_exc()}"
            self.error.emit(error_msg)

        # Verifica che il file esista dopo la creazione
        if Path(zip_path_str).exists():
            file_size = Path(zip_path_str).stat().st_size
            success_msg = f"File zip creato: {zip_path_str} (dimensione: {file_size/(1024*1024):.2f} MB)"
            self.completed.emit(success_msg)
            # Il segnale finished() sarà emesso automaticamente da QThread
        else:
            error_msg = f"ERRORE: File zip non trovato dopo la creazione: {zip_path_str}"
            self.error.emit(error_msg)