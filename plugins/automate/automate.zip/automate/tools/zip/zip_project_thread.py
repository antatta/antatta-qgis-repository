# -*- coding: utf-8 -*-
"""
/***************************************************************************
 ZipProjectThread
                                 A QGIS plugin
 The AUTOMATE plug-in
                             -------------------
        begin                : 2024-09-23
        copyright            : (C) 2024 by Ing. Antonio Attadia
        email                : antonio.attadia@italgas.it
        git sha              : $Format:%H$
 ***************************************************************************/
 Thread class to zip project files asynchronously
"""
from PyQt5.QtCore import QThread, pyqtSignal
import zipfile
import traceback
from pathlib import Path

class ZipProjectThread(QThread):
    # Definizione dei segnali per la comunicazione tra thread e main thread
    progress = pyqtSignal(str)
    finished = pyqtSignal(str)
    error = pyqtSignal(str)

    def __init__(self, home_path, project_path, project_subdir, zip_file_path):
        """
        Initialize the zip thread.
        
        :param home_path: Project home directory path
        :param project_path: Project file path  
        :param project_subdir: Project subdirectory to compress
        :param zip_file_path: Target zip file path
        """
        QThread.__init__(self)
        self.home_path = home_path
        self.project_path = project_path
        self.project_subdir = project_subdir
        self.zip_file_path = zip_file_path

    def run(self):
        """Execute the zip compression in the thread."""
        try:
            # Converte Path a stringa per compatibilità
            zip_path_str = str(self.zip_file_path)
            
            # Crea lo zip mantenendo la struttura della directory
            with zipfile.ZipFile(zip_path_str, 'w', zipfile.ZIP_DEFLATED) as zipf:
                # Aggiungi il file del progetto
                zipf.write(self.project_path, Path(self.project_path).name)
                progress_msg = f"Aggiunto il file del progetto: {Path(self.project_path).name}"
                self.progress.emit(progress_msg)

                # Directory con il nome del progetto
                for file in self.project_subdir.rglob('*'):
                    if file.is_file():
                        rel_path = file.relative_to(self.home_path)
                        progress_msg = f"Aggiungendo: {file.name}"
                        self.progress.emit(progress_msg)
                        zipf.write(str(file), str(rel_path))  # Converti Path a stringa

            # Verifica che il file esista dopo la creazione
            if Path(zip_path_str).exists():
                file_size = Path(zip_path_str).stat().st_size
                success_msg = f"File zip creato: {zip_path_str} (dimensione: {file_size} bytes)"
                self.finished.emit(success_msg)
            else:
                error_msg = f"ERRORE: File zip non trovato dopo la creazione: {zip_path_str}"
                self.error.emit(error_msg)
            
        except Exception as e:
            error_msg = f"Errore nella creazione del file zip: {e}"
            self.error.emit(error_msg)
