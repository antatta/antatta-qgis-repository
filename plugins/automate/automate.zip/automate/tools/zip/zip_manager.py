# -*- coding: utf-8 -*-
"""
/***************************************************************************
 ZipManager
                                 A QGIS plugin
 AUTOMATE
                              -------------------
        begin                : 2025-08-20
        copyright            : (C) 2025 by Ing. Antonio Attadia
        email                : antonio.attadia@italgas.it
 ***************************************************************************/
 Manager class for project zip operations with progress tracking
"""

from pathlib import Path
from qgis.core import QgsProject, Qgis
from qgis.utils import iface

from ...core.utils import last_file
from .zip_project_thread import ZipProjectThread
from .progress_bar_dialog import ProgressBarDialog


class ZipManager:
    """Manager class for handling project zip operations with progress tracking."""
    
    def __init__(self, qgis_iface):
        """
        Initialize the ZipManager.
        
        :param qgis_iface: QGIS interface instance
        :type qgis_iface: QgsInterface
        """
        self.iface = qgis_iface
        self.thread = None
        self.progress_bar = None

        # limite elementi lotto
        self.cifre_max_elementi_lotto = 4
        self.cifre_max_nome_lotto = 4
        
        # Project information
        self.project:QgsProject = None
        self.lotto:str = None
        
        self.project_path:Path = None
        self.project_home_path:Path = None
        self.lotto_dir:Path = None
        self.gpkg_path:Path = None
    
    def set_variables(self, project: QgsProject) -> bool:
        self.project = project
        self.project_path = Path(self.project.fileName())
        self.project_home_path = Path(self.project.homePath())
        
        # Verify project is valid
        print(f"DEBUG: Checking project_home_path: {self.project_home_path}")
        if not self.project_home_path or not self.project_home_path.exists():
            raise ValueError("Progetto non valido o non salvato")

        # Set lotto name
        self.lotto:str = self.project.baseName()[:self.cifre_max_nome_lotto]
        print(f"DEBUG: Checking lotto name: {self.lotto}")
        # Verify lotto name is valid
        if not self.lotto:
            raise ValueError("Nome del progetto non valido")
        
        # Verify lotto directory exists
        self.lotto_dir = self.project_home_path / self.lotto
        print(f"DEBUG: Checking lotto directory: {self.lotto_dir}")
        if not self.lotto_dir.exists() or not self.lotto_dir.is_dir():
            raise ValueError(f"Directory del progetto '{self.lotto}' non trovata in {self.lotto_dir}")
        
        # Find latest gpkg file in lotto directory
        self.gpkg_path = last_file(self.lotto_dir, self.lotto, 'gpkg')
        print(f"DEBUG: Checking lotto.gpkg file: {self.gpkg_path}")
        if not self.gpkg_path or not self.gpkg_path.exists():
            raise ValueError(f"File gpkg del lotto non trovato: {self.gpkg_path}")
                
        print(f'DEBUG: home_path: {self.project_home_path}')
        print(f'DEBUG: project_path: {self.project_path}')
        print(f'DEBUG: lotto: {self.lotto}')
        print(f'DEBUG: lotto_dir: {self.lotto_dir}')
        print(f'DEBUG: lotto.gpkg: {self.gpkg_path}')
        return True
        
        
    def run(self, project: QgsProject):
        """
        Execute the zip project operation.
        
        Creates a zip file of the current project and saves it to Desktop/progettazione/.
        Handles project validation, saving, and compression with progress tracking.
        
        :raises ValueError: If no project is loaded or project directory not found
        :raises RuntimeError: If unable to save the current project
        """
        print("DEBUG: ZipManager.run() iniziato")
        
        # Check if another operation is already running
        if self.thread and self.thread.isRunning():
            print("DEBUG: Thread già in esecuzione")
            iface.messageBar().pushMessage('ZipManager', 
                                         'Un\'operazione di compressione è già in corso', 
                                         level=Qgis.Warning)
            return

        print("DEBUG: Ottenendo informazioni progetto")
        self.set_variables(project)

        try:
            # Save current project
            print("DEBUG: Salvando progetto")
            if not project.write():
                print("DEBUG: Impossibile salvare progetto")
                raise RuntimeError("Impossibile salvare il progetto corrente")

            # Close project after saving
            project.clear()

            # Setup destination directory
            desktop_path = Path.home() / "Desktop"
            target_dir = desktop_path / "progettazione"
            print(f"DEBUG: Directory target: {target_dir}")
            target_dir.mkdir(parents=True, exist_ok=True)
            
            # Verifica che la directory sia accessibile
            if not target_dir.exists():
                raise RuntimeError(f"Impossibile creare la directory: {target_dir}")
            if not target_dir.is_dir():
                raise RuntimeError(f"{target_dir} non è una directory")
            
            # Test scrittura nella directory
            test_file = target_dir / "test_write.tmp"
            try:
                test_file.write_text("test")
                test_file.unlink()
            except Exception as e:
                raise RuntimeError(f"Impossibile scrivere nella directory {target_dir}: {e}")
            
            # Count files for progress tracking
            numero_file = sum(1 for file in self.lotto_dir.rglob('*') if file.is_file()) + 1
            print(f"DEBUG: File da processare: {numero_file}")
            
            # Create zip file path
            zip_file_path = target_dir / f"{self.lotto}.zip"
            if zip_file_path.exists():
                zip_file_path.unlink()
            
            print("DEBUG: Chiamando _start_compression")
            # Setup and start compression thread
            self._start_compression(self.project_home_path, self.project_path, self.lotto_dir, zip_file_path, numero_file)
            print("DEBUG: _start_compression completato")
            
        except Exception as e:
            print(f"DEBUG: Errore in ZipManager.run(): {e}")
            import traceback
            print(f"DEBUG: Traceback: {traceback.format_exc()}")
            error_message = f"Errore durante la preparazione dello zip: {str(e)}"
            iface.messageBar().pushMessage('ZipManager', error_message, level=Qgis.Critical)
    
    def _start_compression(self, home_path, project_path, project_subdir, zip_file_path, file_count):
        """
        Start the compression thread with progress tracking.
        
        :param home_path: Project home directory path
        :type home_path: Path
        :param project_path: Project file path
        :type project_path: str
        :param project_subdir: Project subdirectory to compress
        :type project_subdir: Path
        :param zip_file_path: Target zip file path
        :type zip_file_path: Path
        :param file_count: Number of files to process
        :type file_count: int
        """
        try:
            # Create and configure compression thread
            self.thread = ZipProjectThread(home_path, project_path, project_subdir, zip_file_path)
            
            # Create and setup progress bar
            self.progress_bar = ProgressBarDialog()
            self.progress_bar.setWindowTitle(f"Preparazione file {zip_file_path.name}")
            self.progress_bar.set_value(0)
            self.progress_bar.set_max(file_count)
            self.progress_bar.show()
            
            # Connect thread signals to handlers
            self.thread.progress.connect(self._on_progress)
            self.thread.finished.connect(self._on_finished)
            self.thread.error.connect(self._on_error)
            
            # Start compression directly
            self.thread.start()
                    
        except Exception as e:
            error_message = f"Errore nell'avvio della compressione: {str(e)}"
            iface.messageBar().pushMessage('ZipManager', error_message, level=Qgis.Critical)
    
    def _on_progress(self, message):
        """
        Handle progress updates from compression thread.
        
        :param message: Progress message
        :type message: str
        """
        if self.progress_bar:
            self.progress_bar.increment()
    
    def _on_finished(self, message):
        """
        Handle compression completion.
        
        :param message: Completion message
        :type message: str
        """
        if self.progress_bar:
            self.progress_bar.close()
            self.progress_bar = None
        
        self.thread = None
        iface.messageBar().pushMessage('ZipManager', message, level=Qgis.Success)
    
    def _on_error(self, error_message):
        """
        Handle compression errors.
        
        :param error_message: Error message
        :type error_message: str
        """
        if self.progress_bar:
            self.progress_bar.close()
            self.progress_bar = None
        
        self.thread = None
        iface.messageBar().pushMessage('ZipManager', error_message, level=Qgis.Critical)
    
    def cleanup(self):
        """
        Clean up resources and stop any running operations.
        """
        if self.thread and self.thread.isRunning():
            self.thread.terminate()
            self.thread.wait()
        
        if self.progress_bar:
            self.progress_bar.close()
            self.progress_bar = None
        
        self.thread = None
