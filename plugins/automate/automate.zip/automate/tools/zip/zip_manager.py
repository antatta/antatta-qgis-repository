# -*- coding: utf-8 -*-
"""
/***************************************************************************
 ZipManager
                                 A QGIS plugin
 AUTOMATE
                              -------------------
        begin                : 2025-08-20
        copyright            : (C) 2025 by Ing. Antonio Attadia
        email                : antonio.attadia@italgas.it
 ***************************************************************************/
 Manager class for project zip operations with progress tracking
"""

from pathlib import Path
from qgis.core import QgsProject, Qgis
from qgis.utils import iface

from .zip_project_thread import ZipProjectThread
from .progress_bar_dialog import ProgressBarDialog


class ZipManager:
    """Manager class for handling project zip operations with progress tracking."""
    
    def __init__(self, qgis_iface):
        """
        Initialize the ZipManager.
        
        :param qgis_iface: QGIS interface instance
        :type qgis_iface: QgsInterface
        """
        self.iface = qgis_iface
        self.thread = None
        self.progress_bar = None
    
    def run(self):
        """
        Execute the zip project operation.
        
        Creates a zip file of the current project and saves it to Desktop/progettazione/.
        Handles project validation, saving, and compression with progress tracking.
        
        :raises ValueError: If no project is loaded or project directory not found
        :raises RuntimeError: If unable to save the current project
        """
        print("DEBUG: ZipManager.run() iniziato")
        
        # Check if another operation is already running
        if self.thread and self.thread.isRunning():
            print("DEBUG: Thread già in esecuzione")
            iface.messageBar().pushMessage('ZipManager', 
                                         'Un\'operazione di compressione è già in corso', 
                                         level=Qgis.Warning)
            return
        
        try:
            # Get current project information
            print("DEBUG: Ottenendo informazioni progetto")
            project = QgsProject.instance()
            project_path = project.fileName()
            home_path = Path(project.homePath())
            lotto = project.baseName()
            print(f"DEBUG: Progetto: {lotto}, Path: {project_path}")

            if not project_path:
                print("DEBUG: Nessun progetto caricato")
                raise ValueError("Nessun progetto caricato in QGIS")

            # Save current project
            print("DEBUG: Salvando progetto")
            if not project.write():
                print("DEBUG: Impossibile salvare progetto")
                raise RuntimeError("Impossibile salvare il progetto corrente")

            # Close project after saving
            project.clear()

            # Verify project subdirectory exists
            project_subdir = home_path / lotto
            print(f"DEBUG: Verificando directory: {project_subdir}")
            if not project_subdir.exists() or not project_subdir.is_dir():
                print(f"DEBUG: Directory progetto non trovata: {project_subdir}")
                raise ValueError(f"Directory del progetto '{lotto}' non trovata in {home_path}")

            # Setup destination directory
            desktop_path = Path.home() / "Desktop"
            target_dir = desktop_path / "progettazione"
            print(f"DEBUG: Directory target: {target_dir}")
            target_dir.mkdir(parents=True, exist_ok=True)
            
            # Verifica che la directory sia accessibile
            if not target_dir.exists():
                raise RuntimeError(f"Impossibile creare la directory: {target_dir}")
            if not target_dir.is_dir():
                raise RuntimeError(f"{target_dir} non è una directory")
            
            # Test scrittura nella directory
            test_file = target_dir / "test_write.tmp"
            try:
                test_file.write_text("test")
                test_file.unlink()
            except Exception as e:
                raise RuntimeError(f"Impossibile scrivere nella directory {target_dir}: {e}")
            
            # Count files for progress tracking
            numero_file = sum(1 for file in project_subdir.rglob('*') if file.is_file()) + 1
            print(f"DEBUG: File da processare: {numero_file}")
            
            # Create zip file path
            zip_file_path = target_dir / f"{lotto}.zip"
            if zip_file_path.exists():
                zip_file_path.unlink()
            
            print("DEBUG: Chiamando _start_compression")
            # Setup and start compression thread
            self._start_compression(home_path, project_path, project_subdir, zip_file_path, numero_file)
            print("DEBUG: _start_compression completato")
            
        except Exception as e:
            print(f"DEBUG: Errore in ZipManager.run(): {e}")
            import traceback
            print(f"DEBUG: Traceback: {traceback.format_exc()}")
            error_message = f"Errore durante la preparazione dello zip: {str(e)}"
            iface.messageBar().pushMessage('ZipManager', error_message, level=Qgis.Critical)
    
    def _start_compression(self, home_path, project_path, project_subdir, zip_file_path, file_count):
        """
        Start the compression thread with progress tracking.
        
        :param home_path: Project home directory path
        :type home_path: Path
        :param project_path: Project file path
        :type project_path: str
        :param project_subdir: Project subdirectory to compress
        :type project_subdir: Path
        :param zip_file_path: Target zip file path
        :type zip_file_path: Path
        :param file_count: Number of files to process
        :type file_count: int
        """
        try:
            # Create and configure compression thread
            self.thread = ZipProjectThread(home_path, project_path, project_subdir, zip_file_path)
            
            # Create and setup progress bar
            self.progress_bar = ProgressBarDialog()
            self.progress_bar.setWindowTitle(f"Preparazione file {zip_file_path.name}")
            self.progress_bar.set_value(0)
            self.progress_bar.set_max(file_count)
            self.progress_bar.show()
            
            # Connect thread signals to handlers
            self.thread.progress.connect(self._on_progress)
            self.thread.finished.connect(self._on_finished)
            self.thread.error.connect(self._on_error)
            
            # Start compression directly
            self.thread.start()
                    
        except Exception as e:
            error_message = f"Errore nell'avvio della compressione: {str(e)}"
            iface.messageBar().pushMessage('ZipManager', error_message, level=Qgis.Critical)
    
    def _on_progress(self, message):
        """
        Handle progress updates from compression thread.
        
        :param message: Progress message
        :type message: str
        """
        if self.progress_bar:
            self.progress_bar.increment()
    
    def _on_finished(self, message):
        """
        Handle compression completion.
        
        :param message: Completion message
        :type message: str
        """
        if self.progress_bar:
            self.progress_bar.close()
            self.progress_bar = None
        
        self.thread = None
        iface.messageBar().pushMessage('ZipManager', message, level=Qgis.Success)
    
    def _on_error(self, error_message):
        """
        Handle compression errors.
        
        :param error_message: Error message
        :type error_message: str
        """
        if self.progress_bar:
            self.progress_bar.close()
            self.progress_bar = None
        
        self.thread = None
        iface.messageBar().pushMessage('ZipManager', error_message, level=Qgis.Critical)
    
    def cleanup(self):
        """
        Clean up resources and stop any running operations.
        """
        if self.thread and self.thread.isRunning():
            self.thread.terminate()
            self.thread.wait()
        
        if self.progress_bar:
            self.progress_bar.close()
            self.progress_bar = None
        
        self.thread = None
