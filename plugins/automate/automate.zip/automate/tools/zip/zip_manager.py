"""
Enhanced ZipManager for QGIS project compression using AutomateContext.

This module provides a modernized approach to project archiving that leverages
the validated AutomateContext for simplified path management and error handling.
"""
# # 1. FUTURE IMPORTS
from __future__ import annotations

# # 2. STANDARD LIBRARY
from pathlib import Path
from typing import Callable, Optional

# # 3. THIRD-PARTY LIBRARIES
from qgis.core import Qgis
from qgis.utils import iface

# # 5. LOCAL IMPORTS
from ...core.context import AutomateContext
from .progress_bar_dialog import ProgressBarDialog
from .zip_project_thread import ZipProjectThread


class ZipManager:
    """
    Enhanced manager for project zip operations using AutomateContext.
    
    Simplifies project handling by leveraging the validated AutomateContext
    instead of manual variable setting and validation.
    """
    
    def __init__(self, context: AutomateContext, callback):
        """
        Initialize the ZipManager with AutomateContext.
        
        Args:
            context: Validated AutomateContext with project information
        """
            
        self.context = context
        self.thread: Optional[ZipProjectThread] = None
        self.progress_bar: Optional[ProgressBarDialog] = None
        self.callback = callback
    

    def run(self) -> bool:
        """
        Start the actual ZIP operation in a separate thread.
        
        Uses context data for all paths including GPKG file path.
            
        Returns:
            True if thread started successfully, False otherwise
        """
        
        # Check if another operation is already running
        if self.thread and self.thread.isRunning():
            msg = "Un'operazione di compressione è già in corso"
            self._show_warning(msg)
            return False
        
        # Determine ZIP file path and ensure directory exists
        try:
            zip_file_path = Path.home() / "Desktop" / "progettazione" / f"{self.context.lotto_name}.zip"
            zip_file_path.parent.mkdir(parents=True, exist_ok=True)
            
        except Exception as e:
            msg = f"Errore nella creazione della cartella ZIP: {str(e)}"
            self._show_error(msg)
            return False
        
        # Count files for progress tracking and create progress bar
        numero_file = sum(1 for file in self.context.lotto_dir_path.rglob('*') if file.is_file()) + 1
        msg = f"File da processare: {numero_file}"
        self._show_info(msg)
        
        self.progress_bar = ProgressBarDialog()
        self.progress_bar.setWindowTitle(f"Compressione {self.context.lotto_name}")
        self.progress_bar.set_value(0)
        self.progress_bar.set_max(numero_file)
        
        
        # Create and configure the ZIP thread
        self.thread = ZipProjectThread(
            project_home_path=self.context.project_home_path,
            project_file_path=self.context.project_file_path,
            lotto_dir_path=self.context.lotto_dir_path,
            zip_file_path=zip_file_path
        )
        
        # Connect thread signals to handlers
        self.thread.progress.connect(self._on_progress)
        self.thread.completed.connect(self._on_completed)
        self.thread.error.connect(self._on_error)
        
        # Show progress bar and start thread
        try:
            self.progress_bar.show()
            self.thread.start()
            
            return True
            
        except Exception as e:
            msg = f"Errore nell'avvio del thread di compressione: {str(e)}"
            self._show_error(msg)
            return False


    def stop(self):
        """Stop the current ZIP operation if running."""
        if self.thread and self.thread.isRunning():
            self.thread.stop()
            self.thread.wait()
            self.thread = None
            
        if self.progress_bar:
            self.progress_bar.close()
            self.progress_bar = None


    def _on_progress(self, message: str):
        """
        Handle progress updates from compression thread.
        
        :param message: Progress message
        :type message: str
        """
        self.progress_bar.increment()
        # print(f"DEBUG: ZipManager Progress: {message}")
    
    
    def _on_completed(self, message: str):
        """
        Handle compression completion.
        
        :param message: Completion message
        :type message: str
        """
        
        try:
            # Clean up resources
            if self.progress_bar:
                self.progress_bar.close()
                self.progress_bar = None
                
            self.thread = None
            # Show success message
            self._show_success(message)
            self.callback(True)
            
        except Exception as e:
            msg = f"Errore nella finalizzazione: {str(e)}"
            self._show_error(msg)
            self.callback(False)


    def _on_error(self, error_message: str):
        """
        Handle ZIP operation errors.
        
        Args:
            error_message: The error message from the thread
        """
        
        if self.progress_bar:
            self.progress_bar.close()
            self.progress_bar = None
            
        self.thread = None
        
        # Show error message
        self._show_error(error_message)
        self.callback(False)
    
    def _show_info(self, message: str):
        """Display info message to user."""
        
        print(f"DEBUG: ZipManager {message}")
        
        if not iface:
            return
        iface.messageBar().pushMessage(
            'ZipManager', message, level=Qgis.Info
        )

    def _show_success(self, message: str):
        """Display success message to user."""
        
        print(f"DEBUG: ZipManager {message}")
        
        if not iface:
            return
        iface.messageBar().pushMessage(
            'ZipManager', message, level=Qgis.Success
        )

    def _show_error(self, message: str):
        """Display error message to user."""
        
        print(f"DEBUG: ZipManager {message}")
        
        if not iface:
            return
        iface.messageBar().pushMessage(
            'ZipManager', message, level=Qgis.Critical
        )

    def _show_warning(self, message: str):
        """Display warning message to user."""
        
        print(f"DEBUG: ZipManager {message}")
        
        if not iface:
            return
        iface.messageBar().pushMessage(
            'ZipManager', message, level=Qgis.Warning
        )

    def get_progress(self) -> Optional[int]:
        """
        Get current progress percentage.
        
        Returns:
            Progress percentage (0-100) or None if no operation is running
        """
        if self.thread and self.thread.isRunning():
            return self.thread.get_progress()
        return None

    def is_running(self) -> bool:
        """
        Check if ZIP operation is currently running.
        
        Returns:
            True if operation is running, False otherwise
        """
        return self.thread is not None and self.thread.isRunning()
    