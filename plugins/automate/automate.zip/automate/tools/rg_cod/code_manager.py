# -*- coding: utf-8 -*-
"""
/***************************************************************************
 CodeManager
                                 A QGIS plugin
 The AUTOMATE plug-in
                             -------------------
        begin                : 2024-09-23
        copyright            : (C) 2024 by Ing. Antonio Attadia
        email                : info.antatta@gmail.com
        git sha              : $Format:%H$
 ***************************************************************************/
 Class for coordinating RG_COD management classes
"""

from qgis.core import QgsProject, QgsVectorLayer, QgsFeature
from .code_calculator import CodeCalculator
from .layer_updater import LayerUpdater
from .signal_manager import SignalManager
from ...database.database_connect import DatabaseConnect


class CodeManager:
    """Coordina le tre classi principali"""
    def __init__(self):
        self.calculator = CodeCalculator()
        self.updater = LayerUpdater(self.calculator)
        self.signal_manager = SignalManager(self.updater)
        self.project = None

    def run(self, project: QgsProject, layers: list[QgsVectorLayer]):
        if not self.calculator.set_variables(project):
            return
        
        self.project = project  # Salviamo il riferimento al progetto
        
        layers_name_db = self.calculator.connect_db.get_layers_rg_cod('')
        if not layers_name_db:
            return
        
        # Disconnettiamo prima di riconnettere per evitare connessioni multiple
        if hasattr(self, 'layers_added_connection'):
            self.project.layersAdded.disconnect(self.layers_added_connection)
        
        # Connettiamo il segnale layersAdded
        self.layers_added_connection = self.project.layersAdded.connect(
            lambda layers: self.run(self.project, layers)
        )
        
        for layer in layers:
            layer_name = self.calculator.get_layer_source_name(layer)
            if layer_name in layers_name_db:
                self.signal_manager.disconnect_layer_signals(layer)
                if self.updater.ensure_fields(layer):
                    self.signal_manager.connect_layer_signals(layer)
    
    def stop(self):        
        if self.project and hasattr(self, 'layers_added_connection'):
            try:
                self.project.layersAdded.disconnect(self.layers_added_connection)
                delattr(self, 'layers_added_connection')
            except Exception as e:
                print(f"Errore durante la disconnessione del segnale layersAdded: {e}")
        
        if self.project:
            for layer in self.project.mapLayers().values():
                self.signal_manager.disconnect_layer_signals(layer)
        
        self.project = None    
        
    def run_once(self, project: QgsProject, layer: QgsVectorLayer):
        if not self.calculator.set_variables(project):
            return
        
        layers_name_db = self.calculator.connect_db.get_layers_rg_cod('')
        if not layers_name_db:
            return
        
        layer_name = self.calculator.get_layer_source_name(layer)
        if layer_name not in layers_name_db:
            return
        
        if not self.updater.ensure_fields(layer):
            return
        
        if not layer.isEditable():
            layer.startEditing()
        
        for feature in layer.getFeatures():
            self.updater.update_feature("run_once", layer, feature.id(), False)
        
        layer.commitChanges()
    
    def run_on_feature(self, project: QgsProject, layer: QgsVectorLayer, feature: QgsFeature):
        if not self.calculator.set_variables(project):
            return
        
        layers_name_db = self.calculator.connect_db.get_layers_rg_cod('')
        if not layers_name_db:
            return
        
        layer_name = self.calculator.get_layer_source_name(layer)
        if layer_name not in layers_name_db:
            return
        
        if not self.updater.ensure_fields(layer):
            return
        
        if not layer.isEditable():
            layer.startEditing()
        
        self.updater.update_feature("run_on_future", layer, feature.id(), False)
        
        layer.commitChanges()
