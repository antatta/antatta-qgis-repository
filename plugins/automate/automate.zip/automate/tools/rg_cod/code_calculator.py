# -*- coding: utf-8 -*-
"""
/***************************************************************************
 CodeCalculator
                                 A QGIS plugin
 The AUTOMATE plug-in
                             -------------------
        begin                : 2024-09-23
        copyright            : (C) 2024 by Ing. Antonio Attadia
        email                : antonio.attadia@italgas.it
        git sha              : $Format:%H$
 ***************************************************************************/
 Class for RG_COD calculation and database connection
"""

import sys
import re
from pathlib import Path
from qgis.utils import iface
from qgis.core import Qgis, QgsProject, QgsVectorLayer, QgsFeature
from ...core.utils import last_file
from ...database.database_connect import DatabaseConnect


class CodeCalculator:
    """Gestisce la connessione al database e il calcolo dell'RG_COD"""
    def __init__(self) -> None:
        # limite elementi lotto
        self.cifre_max_elementi_lotto = 4
        self.cifre_max_nome_lotto = 4
        
        self.TRIPLETTA:str = "Tripletta"
        self.project:QgsProject = None
        self.lotto:str = None
        
        # path
        self.home_path:Path = None
        self.lotto_path:Path = None
        self.resource_path:Path = None
        
        # oggetto di collegamento al db
        self.connect_db = None

    def set_variables(self, project: QgsProject) -> bool:
        self.project = project
        self.home_path = Path(self.project.homePath())
        self.lotto = self.project.baseName()[:self.cifre_max_nome_lotto]
        self.lotto_dir = self.home_path / self.lotto
        self.lotto_path = last_file(self.lotto_dir, self.lotto, 'gpkg')
                
        self.connect_db = DatabaseConnect()
        
        print(f'home_path: {self.home_path}')
        print(f'lotto_path: {self.lotto_path}')
        print(f'resource_path: {self.resource_path}')
        
        return self.connect_db is not None


    def get_layer_source_name(self, layer:QgsVectorLayer) -> str:
        if not(layer and isinstance(layer, QgsVectorLayer)):
            return None
        
        provider_source = layer.source()
        match = re.search(r'(?<=layername=)[^|]+', provider_source)
        return match[0] if match else None

    def get_prefix_suffix(self, layer:QgsVectorLayer) -> tuple:
        layer_name = self.get_layer_source_name(layer)
        if not layer_name or not self.connect_db:
            return None, None
        
        result = self.connect_db.get_layer_prefix_suffix('', layer_name)
        
        if not result:
            msg = f"Layer {layer_name} non presente nella tabella LAYER nel db. L'rg_cod non avrà prefissi e suffissi"
            print(msg)
            iface.messageBar().pushMessage(u'rg_cod', msg, level=Qgis.Critical)
            return None, None
        
        return result

    def calculate_rg_cod(self, layer: QgsVectorLayer, feature: QgsFeature) -> str:
        prefix, suffix = self.get_prefix_suffix(layer)
        
        rg_cod_elements = []
        
        field_index = feature.fieldNameIndex(self.TRIPLETTA)
        tripletta = str(feature[self.TRIPLETTA]) if field_index != -1 else '???'
        if tripletta in ['', 'NULL']:
            tripletta = '!!!'

        if prefix and prefix.lower() == "tripletta":
            prefix = f"{tripletta}_"
        rg_cod_elements.append(prefix or '')
        
        fid = feature['fid']
        if fid < 10**self.cifre_max_elementi_lotto:
            rg_cod_elements.append(str(self.lotto).zfill(self.cifre_max_nome_lotto))
            rg_cod_elements.append(str(fid).zfill(self.cifre_max_elementi_lotto))
        else:
            rg_cod_elements.append(str(fid).zfill(self.cifre_max_nome_lotto + self.cifre_max_elementi_lotto ))
        
        if suffix and suffix.lower() == "tripletta":
            suffix = f"_{tripletta}"
        rg_cod_elements.append(suffix or '')
        
        return "".join(rg_cod_elements)
