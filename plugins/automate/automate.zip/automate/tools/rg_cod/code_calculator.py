# -*- coding: utf-8 -*-
"""
/***************************************************************************
 CodeCalculator
                                 A QGIS plugin
 The AUTOMATE plug-in
                             -------------------
        begin                : 2024-09-23
        copyright            : (C) 2024 by Ing. Antonio Attadia
        email                : info.antatta@gmail.com
        git sha              : $Format:%H$
 ***************************************************************************/
 Class for RG_COD calculation and database connection
"""
# # 1. FUTURE IMPORTS
from __future__ import annotations  # SEMPRE in cima!

# # 3. THIRD-PARTY LIBRARIES
from qgis.core import QgsFeature

# # 5. LOCAL IMPORTS
from ...core import AutomateContext


class CodeCalculator:
    """Gestisce la connessione al database e il calcolo dell'RG_COD"""
    def __init__(self, context: AutomateContext) -> None:
        self.context = context

    def calculate_rg_cod(self, feature: QgsFeature, prefix:str, suffix:str) -> str:
        assert self.context.c is not None, "Context cost must be provided"
        
        # Elementi per il calcolo di RG_COD
        cifre_max_nome_lotto = self.context.c.cifre_max_nome_lotto
        cifre_max_elementi_lotto = self.context.c.cifre_max_elementi_lotto
        field_tripletta = self.context.c.TRIPLETTA
        
        # Calcolo RG_COD
        rg_cod_elements = []
        
        idx_field_tripletta = feature.fieldNameIndex(field_tripletta)
        tripletta = str(feature[field_tripletta]) if idx_field_tripletta != -1 else '???'
        if tripletta in ['', 'NULL']:
            tripletta = '!!!'

        if prefix and prefix.lower() == "tripletta":
            prefix = f"{tripletta}_"
        rg_cod_elements.append(prefix or '')
        
        fid = feature['fid']
        
        if fid < 10**cifre_max_elementi_lotto:
            rg_cod_elements.append(str(self.context.lotto_name).zfill(cifre_max_nome_lotto))
            rg_cod_elements.append(str(fid).zfill(cifre_max_elementi_lotto))
        else:
            rg_cod_elements.append(str(fid).zfill(cifre_max_nome_lotto + cifre_max_elementi_lotto))
        
        if suffix and suffix.lower() == "tripletta":
            suffix = f"_{tripletta}"
        rg_cod_elements.append(suffix or '')
        
        return "".join(rg_cod_elements)
