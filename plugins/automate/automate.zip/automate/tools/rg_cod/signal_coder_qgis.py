# -*- coding: utf-8 -*-
"""
/***************************************************************************
 SignalCoderQGIS
                                 A QGIS plugin
 The AUTOMATE plug-in
                             -------------------
        begin                : 2024-09-23
        copyright            : (C) 2024 by Ing. Antonio Attadata
        email                : info.antatta@gmail.com
        git sha              : $Format:%H$
 ***************************************************************************/
 Class for Qt signal management with CoderQGIS integration
"""
# # 1. FUTURE IMPORTS
from __future__ import annotations  # SEMPRE in cima!

# # 2. STANDARD LIBRARY
from typing import Dict, List, Optional, Tuple

# # 3. THIRD-PARTY LIBRARIES
from qgis.core import QgsVectorLayer
from qgis.PyQt.QtCore import QMetaObject, pyqtBoundSignal

# # 5. LOCAL IMPORTS
from .coder_qgis import CoderQGIS


class SignalCoderQGIS:
    """
    Gestisce la connessione e disconnessione dei segnali dei layer QGIS.
    
    Utilizza CoderQGIS per aggiornare le feature tramite OGR quando
    vengono modificate o aggiunte in QGIS.
    """
    
    def __init__(self, updater: CoderQGIS):
        """
        Inizializza il SignalCoderQGIS.
        
        Args:
            updater: Istanza di CoderQGIS per gestire gli aggiornamenti
        """
        self.updater = updater
        self.connected_signals: Dict[str, List[Tuple[pyqtBoundSignal, QMetaObject.Connection]]] = {}
        
        print("🔗 SignalCoderQGIS inizializzato")

    def connect_layer_signals(self, layer: QgsVectorLayer) -> bool:
        """
        Connette i segnali di un layer QGIS ai metodi di aggiornamento OGR.
        
        Args:
            layer: Layer QGIS a cui connettere i segnali
            
        Returns:
            True se la connessione è riuscita, False altrimenti
        """
        try:
            if not layer or not layer.isValid():
                print(f"❌ Layer '{layer.name()}' non valido per connessione segnali")
                return False
            
            layer_id = layer.id()
            layer_name = layer.name()
            
            # Verifica se il layer è configurato per RG_COD
            layer_path, layer_name_ogr = self.updater._extract_ogr_info_from_qgis_layer(layer)
            if not self.updater.context.db.is_layer_rg_cod('', layer_name_ogr):
                print(f"📝 Layer '{layer_name}' non configurato per RG_COD, segnali non connessi")
                return False
            
            # Inizializza la lista dei segnali per questo layer se non esiste
            if layer_id not in self.connected_signals:
                self.connected_signals[layer_id] = []
            
            # Segnale per modifiche agli attributi delle feature esistenti
            try:
                value_changed_connection = layer.attributeValueChanged.connect(
                    lambda fid, field_idx, new_value: self._on_attribute_value_changed(layer, fid, field_idx, new_value)
                )
                self.connected_signals[layer_id].append((layer.attributeValueChanged, value_changed_connection))
                print(f"   ✅ Segnale attributeValueChanged connesso per '{layer_name}'")
            except Exception as e:
                print(f"   ❌ Errore connettendo attributeValueChanged per '{layer_name}': {e}")
            
            # Segnale per feature aggiunte
            try:
                feature_added_connection = layer.featureAdded.connect(
                    lambda fid: self._on_feature_added(layer, fid)
                )
                self.connected_signals[layer_id].append((layer.featureAdded, feature_added_connection))
                print(f"   ✅ Segnale featureAdded connesso per '{layer_name}'")
            except Exception as e:
                print(f"   ❌ Errore connettendo featureAdded per '{layer_name}': {e}")
            
            # Segnale per geometrie modificate (opzionale, per completezza)
            try:
                geometry_changed_connection = layer.geometryChanged.connect(
                    lambda fid, geometry: self._on_geometry_changed(layer, fid, geometry)
                )
                self.connected_signals[layer_id].append((layer.geometryChanged, geometry_changed_connection))
                print(f"   ✅ Segnale geometryChanged connesso per '{layer_name}'")
            except Exception as e:
                print(f"   ❌ Errore connettendo geometryChanged per '{layer_name}': {e}")
            
            print(f"🔗 Layer '{layer_name}' (ID: {layer_id}) segnali connessi:")
            return True
            
        except Exception as e:
            print(f"❌ Errore critico in connect_layer_signals per {layer.name() if layer else 'Unknown'}: {e}")
            return False

    def disconnect_layer_signals(self, layer: QgsVectorLayer) -> bool:
        """
        Disconnette i segnali di un layer QGIS.
        
        Args:
            layer: Layer QGIS da cui disconnettere i segnali
            
        Returns:
            True se la disconnessione è riuscita, False altrimenti
        """
        try:
            if not layer:
                print(f"❌ Layer non valido per disconnessione segnali")
                return False
            
            layer_id = layer.id()
            layer_name = layer.name()
            
            if layer_id not in self.connected_signals:
                print(f"📝 Nessun segnale connesso per layer '{layer_name}' (ID: {layer_id})")
                return True
            
            disconnected_count = 0
            for signal, connection in self.connected_signals[layer_id]:
                try:
                    signal.disconnect(connection)
                    disconnected_count += 1
                    print(f"   ✅ Segnale {signal.signal} disconnesso da '{layer_name}'")
                except Exception as e:
                    print(f"   ❌ Errore disconnettendo segnale da '{layer_name}': {e}")
            
            # Rimuovi il layer dalla lista
            del self.connected_signals[layer_id]
            
            print(f"🔌 {disconnected_count} segnali disconnessi per layer '{layer_name}' (ID: {layer_id})")
            return True
            
        except Exception as e:
            print(f"❌ Errore critico in disconnect_layer_signals per {layer.name() if layer else 'Unknown'}: {e}")
            return False

    def disconnect_all_signals(self) -> int:
        """
        Disconnette tutti i segnali da tutti i layer connessi.
        
        Returns:
            Numero di layer da cui sono stati disconnessi i segnali
        """
        try:
            disconnected_layers = 0
            
            # Copia la lista delle chiavi per evitare modifiche durante l'iterazione
            layer_ids = list(self.connected_signals.keys())
            
            print(f"🔌 Disconnettendo segnali da {len(layer_ids)} layer...")
            
            for layer_id in layer_ids:
                try:
                    # Trova il layer dal progetto QGIS
                    # # 3. THIRD-PARTY LIBRARIES
                    from qgis.core import QgsProject
                    project = QgsProject.instance()
                    layer = project.mapLayer(layer_id)
                    
                    if layer:
                        if self.disconnect_layer_signals(layer):
                            disconnected_layers += 1
                    else:
                        # Layer non più presente, rimuovi dalla lista
                        del self.connected_signals[layer_id]
                        print(f"   📝 Layer con ID {layer_id} non più presente, rimosso dalla lista")
                        
                except Exception as e:
                    print(f"   ❌ Errore disconnettendo layer ID {layer_id}: {e}")
                    continue
            
            print(f"🏁 Disconnessione completata: {disconnected_layers} layer processati")
            return disconnected_layers
            
        except Exception as e:
            print(f"❌ Errore critico in disconnect_all_signals: {e}")
            return 0

    def _on_attribute_value_changed(self, layer: QgsVectorLayer, fid: int, field_idx: int, new_value) -> None:
        """
        Gestore per il segnale attributeValueChanged.
        
        Chiamato quando cambia il valore di un attributo di una feature esistente.
        
        Args:
            layer: Layer QGIS contenente la feature
            fid: Feature ID della feature modificata
            field_idx: Indice del campo modificato
            new_value: Nuovo valore del campo
        """
        try:
            layer_name = layer.name()
            field_name = layer.fields().at(field_idx).name() if field_idx < layer.fields().count() else "Unknown"
            
            print(f"🔄 Attributo modificato: Layer '{layer_name}', FID {fid}, Campo '{field_name}' = {new_value}")
            
            # Aggiorna la feature tramite CoderQGIS
            print("DEBUG: Chiamata a update_feature di CoderQGIS")
            success, rg_cod = self.updater.update_feature_by_fid(layer, fid)
            print(f"DEBUG: update_feature restituisce {success}, {rg_cod}")

            if success:
                print(f"✅ Feature FID {fid} aggiornata con successo {rg_cod} nel layer '{layer_name}'")
            else:
                print(f"❌ Errore aggiornando feature FID {fid} nel layer '{layer_name}'")
                
        except Exception as e:
            print(f"❌ Errore in _on_attribute_value_changed: {e}")

    def _on_feature_added(self, layer: QgsVectorLayer, fid: int) -> None:
        """
        Gestore per il segnale featureAdded.
        
        Chiamato quando viene aggiunta una nuova feature al layer.
        
        Args:
            layer: Layer QGIS contenente la feature
            fid: Feature ID della feature aggiunta
        """
        try:
            layer_name = layer.name()
            
            print(f"➕ Feature aggiunta: Layer '{layer_name}', FID {fid}")
            
            # Aggiorna la feature appena aggiunta tramite CoderQGIS
            success, rg_cod = self.updater.update_feature_by_fid(layer, fid)
            
            if success:
                print(f"✅ Feature appena aggiunta FID {fid} configurata con successo {rg_cod} nel layer '{layer_name}'")
            else:
                print(f"❌ Errore configurando feature appena aggiunta FID {fid} nel layer '{layer_name}'")
                
        except Exception as e:
            print(f"❌ Errore in _on_feature_added: {e}")

    def _on_geometry_changed(self, layer: QgsVectorLayer, fid: int, geometry) -> None:
        """
        Gestore per il segnale geometryChanged.
        
        Chiamato quando cambia la geometria di una feature.
        
        Args:
            layer: Layer QGIS contenente la feature
            fid: Feature ID della feature con geometria modificata
            geometry: Nuova geometria
        """
        try:
            layer_name = layer.name()
            
            print(f"🔷 Geometria modificata: Layer '{layer_name}', FID {fid}")
            
            # Opzionalmente aggiorna anche quando cambia la geometria
            # (potrebbe non essere necessario per RG_COD, ma è utile per completezza)
            success, rg_cod = self.updater.update_feature_by_fid(layer, fid)
            
            if success:
                print(f"✅ Feature FID {fid} riaggiornata dopo modifica geometria {rg_cod} nel layer '{layer_name}'")
            else:
                print(f"❌ Errore riaggiornando feature FID {fid} dopo modifica geometria nel layer '{layer_name}'")
                
        except Exception as e:
            print(f"❌ Errore in _on_geometry_changed: {e}")

    def get_connected_layers_count(self) -> int:
        """
        Restituisce il numero di layer attualmente connessi.
        
        Returns:
            Numero di layer con segnali connessi
        """
        return len(self.connected_signals)

    def get_connected_layers_info(self) -> Dict[str, int]:
        """
        Restituisce informazioni sui layer connessi.
        
        Returns:
            Dizionario con ID layer -> numero di segnali connessi
        """
        return {layer_id: len(signals) for layer_id, signals in self.connected_signals.items()}

    def is_layer_connected(self, layer: QgsVectorLayer) -> bool:
        """
        Verifica se un layer ha segnali connessi.
        
        Args:
            layer: Layer QGIS da verificare
            
        Returns:
            True se il layer ha segnali connessi, False altrimenti
        """
        return layer.id() in self.connected_signals if layer else False