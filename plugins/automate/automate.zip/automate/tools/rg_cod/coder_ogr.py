# -*- coding: utf-8 -*-
"""
CoderOGR - Aggiornamento diretto tramite OGR senza passare per QGIS.

Questa classe fornisce metodi per aggiornare i codici RG_COD direttamente
tramite l'API OGR, bypassando l'layer QGIS per prestazioni ottimali.
"""

# # 1. FUTURE IMPORTS
from __future__ import annotations

# # 3. THIRD-PARTY LIBRARIES
from osgeo import ogr
from typing import List, Tuple


class CoderOGR:
    """
    Gestisce l'aggiornamento diretto dei layer tramite OGR senza passare per QGIS.
    
    Classe puramente OGR che offre metodi per:
    - Update di singola feature per FID  
    - Update di layer completi
    """
    
    # A. Update di singola feature per FID
    @staticmethod
    def update_feature_by_fid(layer_path: str, layer_name: str, prefix: str, suffix: str, fid: int,
                             lotto_name: str, univoco_feature_field: str, univoco_lotto_field: str,
                             tripletta_field: str, cifre_max_nome_lotto: int, cifre_max_elementi_lotto: int) -> Tuple[bool, str]:
        """
        Aggiorna una singola feature specificata da FID tramite OGR diretto.
        
        Args:
            layer_path: Percorso al file contenente il layer (es: gpkg, shp)
            layer_name: Nome del layer all'interno del file
            prefix: Prefisso per il calcolo del codice
            suffix: Suffisso per il calcolo del codice
            fid: Feature ID da aggiornare
            lotto_name: Nome del lotto per il codice
            univoco_feature_field: Nome campo per codice univoco feature
            univoco_lotto_field: Nome campo per codice univoco lotto
            tripletta_field: Nome campo tripletta
            cifre_max_nome_lotto: Cifre massime per nome lotto
            cifre_max_elementi_lotto: Cifre massime per elementi lotto
            
        Returns:
            True se l'aggiornamento è riuscito, False altrimenti
        """
        try:
            # Apri il dataset OGR in modalità scrittura
            dataset = ogr.Open(layer_path, 1)  # 1 = write access
            if not dataset:
                print(f"OGR Error: Impossibile aprire il dataset: {layer_path}")
                return False
            
            # Ottieni il layer OGR
            ogr_layer = dataset.GetLayerByName(layer_name)
            if not ogr_layer:
                print(f"OGR Error: Layer '{layer_name}' non trovato nel dataset")
                dataset = None
                return False
            
            # Ottieni la feature specifica
            ogr_feature = ogr_layer.GetFeature(fid)
            if not ogr_feature:
                print(f"OGR Error: Feature con FID {fid} non trovata nel layer '{layer_name}'")
                dataset = None
                return False
            
            # Aggiorna la feature
            success, rg_cod = CoderOGR._update_single_ogr_feature(
                ogr_layer, ogr_feature, prefix, suffix, lotto_name,
                univoco_feature_field, univoco_lotto_field, tripletta_field,
                cifre_max_nome_lotto, cifre_max_elementi_lotto
            )
            
            # Cleanup
            ogr_feature = None
            dataset = None
            
            if success:
                print(f"OGR Success: Feature FID {fid} aggiornata nel layer '{layer_name}'")
            
            return success, rg_cod
            
        except Exception as e:
            print(f"OGR Error in update_feature_by_fid: {e}")
            return False, ''
    
    # B. Update di singolo layer completo
    @staticmethod
    def update_single_layer_ogr(layer_path: str, layer_name: str, prefix: str, suffix: str,
                               lotto_name: str, univoco_feature_field: str, univoco_lotto_field: str,
                               tripletta_field: str, cifre_max_nome_lotto: int, cifre_max_elementi_lotto: int) -> int:
        """
        Aggiorna tutte le feature di un singolo layer tramite OGR diretto.
        
        Args:
            layer_path: Percorso al file contenente il layer
            layer_name: Nome del layer all'interno del file
            prefix: Prefisso per il calcolo del codice
            suffix: Suffisso per il calcolo del codice
            lotto_name: Nome del lotto per il codice
            univoco_feature_field: Nome campo per codice univoco feature
            univoco_lotto_field: Nome campo per codice univoco lotto
            tripletta_field: Nome campo tripletta
            cifre_max_nome_lotto: Cifre massime per nome lotto
            cifre_max_elementi_lotto: Cifre massime per elementi lotto
            
        Returns:
            Numero di feature aggiornate con successo
        """
        try:
            # Apri il dataset OGR in modalità scrittura
            dataset = ogr.Open(layer_path, 1)
            if not dataset:
                print(f"OGR Error: Impossibile aprire il dataset: {layer_path}")
                return 0
            
            # Ottieni il layer OGR
            ogr_layer = dataset.GetLayerByName(layer_name)
            if not ogr_layer:
                print(f"OGR Error: Layer '{layer_name}' non trovato nel dataset")
                dataset = None
                return 0
            
            updated_count = 0
            
            # Itera su tutte le feature del layer
            ogr_layer.ResetReading()
            while True:
                ogr_feature = ogr_layer.GetNextFeature()
                if ogr_feature is None:
                    break  # Fine feature
                
                result, rg_cod =  CoderOGR._update_single_ogr_feature(
                    ogr_layer, ogr_feature, prefix, suffix, lotto_name,
                    univoco_feature_field, univoco_lotto_field, tripletta_field,
                    cifre_max_nome_lotto, cifre_max_elementi_lotto
                )
                if result:
                    updated_count += 1
                
                ogr_feature = None
            
            # Cleanup
            dataset = None
            
            if updated_count > 0:
                msg = f"OGR Success: Aggiornate {updated_count} feature nel layer '{layer_name}'"
                print(msg)
            
            return updated_count
            
        except Exception as e:
            print(f"OGR Error in update_single_layer_ogr: {e}")
            return 0
    
    @staticmethod
    def _check_existing_fields(layer_path: str, layer_name: str, field_names: List[str]) -> Tuple[List[str], List[str]]:
        """
        Verifica quali campi esistono già nel layer e quali sono mancanti.
        
        Args:
            layer_path: Percorso al file contenente il layer
            layer_name: Nome del layer all'interno del file
            field_names: Lista dei nomi dei campi da verificare
            
        Returns:
            Tuple (campi_esistenti, campi_mancanti)
        """
        try:
            from osgeo import ogr
            
            # Apri il dataset OGR in modalità lettura
            dataset = ogr.Open(layer_path, 0)  # 0 = read access
            if not dataset:
                print(f"❌ Impossibile aprire il dataset per verifica campi: {layer_path}")
                return [], field_names  # Assume tutti mancanti se non riesce ad aprire
            
            # Ottieni il layer OGR
            ogr_layer = dataset.GetLayerByName(layer_name)
            if not ogr_layer:
                print(f"❌ Layer '{layer_name}' non trovato nel dataset per verifica campi")
                dataset = None
                return [], field_names  # Assume tutti mancanti se layer non trovato
            
            # Ottieni la definizione del layer
            layer_defn = ogr_layer.GetLayerDefn()
            
            # Crea lista dei campi esistenti nel layer (case-insensitive)
            existing_field_names = []
            for i in range(layer_defn.GetFieldCount()):
                field_defn = layer_defn.GetFieldDefn(i)
                existing_field_names.append(field_defn.GetName().upper())
            
            # Separa campi esistenti da quelli mancanti
            campi_esistenti = []
            campi_mancanti = []
            
            for field_name in field_names:
                if field_name.upper() in existing_field_names:
                    campi_esistenti.append(field_name)
                else:
                    campi_mancanti.append(field_name)
            
            # Cleanup
            dataset = None
            
            return campi_esistenti, campi_mancanti
            
        except Exception as e:
            print(f"❌ Errore in _check_existing_fields: {e}")
            # In caso di errore, assume tutti i campi come mancanti per sicurezza
            return [], field_names
    
    
    # C. Assicurati che i campi esistano nel layer
    @staticmethod
    def ensure_fields_exist(layer_path: str, layer_name: str, required_fields: List[Tuple[str, int, int]]) -> bool:
        """
        Verifica la presenza di una lista di campi nel layer e li aggiunge se mancanti.
        
        Args:
            layer_path: Percorso al file contenente il layer
            layer_name: Nome del layer all'interno del file
            required_fields: Lista di tuple (field_name, field_type, field_width)
                           field_type: ogr.OFTString, ogr.OFTInteger, ogr.OFTReal, etc.
                           field_width: larghezza del campo (per stringhe) o 0 per numerici
        
        Returns:
            True se tutti i campi esistono o sono stati creati con successo, False altrimenti
            
        Example:
            required_fields = [
                ("RG_COD", ogr.OFTString, 50),
                ("LOTTO", ogr.OFTString, 20), 
                ("TRIPLETTA", ogr.OFTString, 10),
                ("COUNTER", ogr.OFTInteger, 0)
            ]
        """
        try:
            # Apri il dataset OGR in modalità scrittura
            dataset = ogr.Open(layer_path, 1)  # 1 = write access
            if not dataset:
                print(f"OGR Error: Impossibile aprire il dataset per aggiunta campi: {layer_path}")
                return False
            
            # Ottieni il layer OGR
            ogr_layer = dataset.GetLayerByName(layer_name)
            if not ogr_layer:
                print(f"OGR Error: Layer '{layer_name}' non trovato nel dataset per aggiunta campi")
                dataset = None
                return False
            
            # Ottieni la definizione del layer
            layer_defn = ogr_layer.GetLayerDefn()
            
            # Verifica ogni campo richiesto
            fields_added = 0
            for field_name, field_type, field_width in required_fields:
                
                # Verifica se il campo esiste già
                field_exists = False
                for i in range(layer_defn.GetFieldCount()):
                    existing_field = layer_defn.GetFieldDefn(i)
                    if existing_field.GetName().upper() == field_name.upper():
                        field_exists = True
                        print(f"OGR Field: Campo '{field_name}' già esistente nel layer '{layer_name}'")
                        break
                
                # Se il campo non esiste, crealo
                if not field_exists:
                    field_defn = ogr.FieldDefn(field_name, field_type)
                    
                    # Imposta la larghezza per i campi stringa
                    if field_type == ogr.OFTString and field_width > 0:
                        field_defn.SetWidth(field_width)
                    
                    # Aggiungi il campo al layer
                    if ogr_layer.CreateField(field_defn) == ogr.OGRERR_NONE:
                        fields_added += 1
                        type_name = CoderOGR._get_field_type_name(field_type)
                        print(f"OGR Field: Campo '{field_name}' ({type_name}, {field_width}) aggiunto al layer '{layer_name}'")
                    else:
                        print(f"OGR Error: Impossibile aggiungere il campo '{field_name}' al layer '{layer_name}'")
                        dataset = None
                        return False
            
            # Cleanup
            dataset = None
            
            if fields_added > 0:
                print(f"OGR Success: {fields_added} nuovi campi aggiunti al layer '{layer_name}'")
            else:
                print(f"OGR Info: Tutti i campi richiesti già presenti nel layer '{layer_name}'")
            
            return True
            
        except Exception as e:
            print(f"OGR Error in ensure_fields_exist: {e}")
            return False
    
    @staticmethod
    def _get_field_type_name(field_type: int) -> str:
        """
        Converte il tipo di campo OGR in una stringa leggibile.
        
        Args:
            field_type: Tipo di campo OGR (ogr.OFTString, ogr.OFTInteger, etc.)
            
        Returns:
            Nome del tipo come stringa
        """
        type_mapping = {
            ogr.OFTString: "String",
            ogr.OFTInteger: "Integer", 
            ogr.OFTReal: "Real",
            ogr.OFTDate: "Date",
            ogr.OFTTime: "Time",
            ogr.OFTDateTime: "DateTime",
            ogr.OFTBinary: "Binary",
            ogr.OFTStringList: "StringList",
            ogr.OFTIntegerList: "IntegerList",
            ogr.OFTRealList: "RealList"
        }
        return type_mapping.get(field_type, f"Unknown({field_type})")
    
    # METODI HELPER PRIVATI
    @staticmethod
    def _calculate_rg_cod_ogr(ogr_feature, prefix: str, suffix: str, lotto_name: str,
                             tripletta_field: str, cifre_max_nome_lotto: int, cifre_max_elementi_lotto: int) -> str:
        """
        Calcola il codice RG_COD direttamente dai dati OGR.
        
        Args:
            ogr_feature: Feature OGR con i dati
            prefix: Prefisso per il codice
            suffix: Suffisso per il codice
            lotto_name: Nome del lotto
            tripletta_field: Nome campo tripletta
            cifre_max_nome_lotto: Cifre massime per nome lotto
            cifre_max_elementi_lotto: Cifre massime per elementi lotto
            
        Returns:
            Codice RG_COD calcolato
        """
        try:
            # Calcolo RG_COD
            rg_cod_elements = []
            
            # Gestione del campo tripletta
            tripletta = ogr_feature.GetField(tripletta_field) or '???'
            tripletta = str(tripletta)
            if tripletta in ['', 'NULL', None]:
                tripletta = '!!!'
            
            # Gestione prefix con tripletta
            if prefix and prefix.lower() == "tripletta":
                prefix = f"{tripletta}_"
            rg_cod_elements.append(prefix or '')
            
            # Ottieni il FID della feature OGR
            fid = ogr_feature.GetFID()
            
            # Logica del calcolo
            if fid < 10**cifre_max_elementi_lotto:
                rg_cod_elements.append(str(lotto_name).zfill(cifre_max_nome_lotto))
                rg_cod_elements.append(str(fid).zfill(cifre_max_elementi_lotto))
            else:
                rg_cod_elements.append(str(fid).zfill(cifre_max_nome_lotto + cifre_max_elementi_lotto))
            
            # Gestione suffix con tripletta
            if suffix and suffix.lower() == "tripletta":
                suffix = f"_{tripletta}"
            rg_cod_elements.append(suffix or '')
            
            return "".join(rg_cod_elements)
            
        except Exception as e:
            print(f"Errore nel calcolo RG_COD: {e}")
            return f"????"  # Valore di default in caso di errore

    @staticmethod
    def _update_single_ogr_feature(ogr_layer, ogr_feature, prefix: str, suffix: str, lotto_name: str,
                                  univoco_feature_field: str, univoco_lotto_field: str, tripletta_field: str,
                                  cifre_max_nome_lotto: int, cifre_max_elementi_lotto: int) -> Tuple[bool, str]:
        """
        Aggiorna una singola feature OGR con i codici calcolati.
        
        Args:
            ogr_layer: Layer OGR contenente la feature
            ogr_feature: Feature OGR da aggiornare
            prefix: Prefisso per il calcolo del codice
            suffix: Suffisso per il calcolo del codice
            lotto_name: Nome del lotto
            univoco_feature_field: Nome campo per codice univoco feature
            univoco_lotto_field: Nome campo per codice univoco lotto
            tripletta_field: Nome campo tripletta
            cifre_max_nome_lotto: Cifre massime per nome lotto
            cifre_max_elementi_lotto: Cifre massime per elementi lotto
            
        Returns:
            True se l'aggiornamento è riuscito, False altrimenti
        """
        try:
            # Calcola i codici direttamente da OGR
            rg_cod = CoderOGR._calculate_rg_cod_ogr(
                ogr_feature, prefix, suffix, lotto_name, tripletta_field,
                cifre_max_nome_lotto, cifre_max_elementi_lotto
            )
            
            # Trova gli indici dei campi da aggiornare
            univoco_feature_idx = ogr_feature.GetFieldIndex(univoco_feature_field)
            univoco_lotto_idx = ogr_feature.GetFieldIndex(univoco_lotto_field)
            
            # Aggiorna i campi se esistono
            fields_updated = False
            if univoco_feature_idx >= 0:
                ogr_feature.SetField(univoco_feature_idx, rg_cod)
                fields_updated = True
            
            if univoco_lotto_idx >= 0:
                ogr_feature.SetField(univoco_lotto_idx, lotto_name)
                fields_updated = True
            
            if not fields_updated:
                print(f"OGR Warning: Nessun campo da aggiornare trovato per FID {ogr_feature.GetFID()}")
                return False, ''
            
            # Salva le modifiche nel layer
            if ogr_layer.SetFeature(ogr_feature) != ogr.OGRERR_NONE:
                print(f"OGR Error: Impossibile salvare la feature FID {ogr_feature.GetFID()}")
                return False, ''
            
            fid = ogr_feature.GetFID()
            print(f"OGR Update: FID {fid} - {univoco_lotto_field}: {lotto_name} - {univoco_feature_field}: {rg_cod}")
            
            return True, rg_cod
            
        except Exception as e:
            print(f"OGR Error in _update_single_ogr_feature: {e}")
            return False, ''

