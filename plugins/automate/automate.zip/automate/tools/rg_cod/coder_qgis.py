# -*- coding: utf-8 -*-
"""
CoderQGIS - Interfaccia QGIS per CoderOGR.

Questa classe l'integrazione con QGIS e delega le operazioni
di aggiornamento effettive alla classe CoderOGR.
"""

# # 1. FUTURE IMPORTS
from __future__ import annotations

# # 2. STANDARD LIBRARY
import re
from pathlib import Path
from typing import List, Optional, Tuple

# # 3. THIRD-PARTY LIBRARIES
from qgis.core import QgsVectorLayer
from qgis.utils import iface

# # 5. LOCAL IMPORTS
from ...core.context import AutomateContext
from .coder_ogr import CoderOGR


class CoderQGIS:
    """
    Gestisce l'interfaccia QGIS per l'aggiornamento layer tramite CoderOGR.
    
    Questa classe si occupa di:
    - Integrazione con l'interfaccia QGIS
    - Gestione selezioni layer e feature
    - Estrazione informazioni OGR dai layer QGIS
    - Delega delle operazioni a CoderOGR
    """
    
    def __init__(self, context: AutomateContext):
        """
        Inizializza il CoderQGIS.
        
        Args:
            context: AutomateContext con i dati del progetto validati
        """
        self.context = context
 
    # A. Lista layer vettoriali validi selezionati in QGIS
    def get_selected_layers_safe(self) -> List[QgsVectorLayer]:
        """
        Ottiene i layer selezionati nel pannello QGIS in modo sicuro.
        NUOVO APPROCCIO: Evita completamente index2node che causa crash non gestibili.
        
        Returns:
            Lista dei layer selezionati o lista vuota se fallisce
        """
        try:
            if not iface:
                print("❌ QGIS interface non disponibile")
                return []
            
            # Ottieni i layer selezionati
            selected = iface.layerTreeView().selectedLayers()
            
            # Filtra solo i layer vettoriali
            vector_layers = []
            for layer in selected:
                if isinstance(layer, QgsVectorLayer) and layer.isValid():
                    vector_layers.append(layer)
                    print(f"✅ Layer selezionato: '{layer.name()}'")
            
            if vector_layers:
                print(f"🎯 Processando {len(vector_layers)} layer selezionati")
                return vector_layers
            else:
                print("📝 Nessun layer vettoriale selezionato")
                return []
                
        except Exception as e:
            print(f"   ❌ Errore nella selezione layer: {e}")
            return []


    def update_feature_by_fid(self, layer: QgsVectorLayer, fid: int) -> Tuple[bool, str]:
        """
        Trova le features QGIS selezionate e le aggiorna tramite OGR diretto.
        
        Returns:
            True se l'aggiornamento è riuscito, False altrimenti
        """
                
        # Ottieni informazioni sul layer per OGR
        layer_path, layer_name_ogr = self._extract_ogr_info_from_qgis_layer(layer)
        if not layer_path or not layer_name_ogr:
            print(f"❌ Impossibile accedere al layer attivo {layer.name()}")
            return False
                
        if not self.context.db.is_layer_rg_cod('', layer_name_ogr):
            print(f"QGIS Error: Il layer attivo '{layer.name()}' non è configurato per RG_COD")
            return False
        
        # Controlla che ci sia almeno una feature selezionata
        selected_features = layer.getFeature(fid)
        if not selected_features:
            print("QGIS Error: Nessuna feature selezionata nel layer attivo")
            return False
        
        # Parametri di contesto
        lotto_name = self.context.lotto_name
        field_univoco_feature = self.context.c.UNIVOCO_FEATURE
        field_univoco_lotto = self.context.c.UNIVOCO_LOTTO
        field_tripletta = self.context.c.TRIPLETTA
        cifre_max_nome_lotto = self.context.c.cifre_max_nome_lotto
        cifre_max_elementi_lotto = self.context.c.cifre_max_elementi_lotto        
        

        print(f"🔧 Preparando campi per layer {layer.name()} ({layer_name_ogr})...")
        required_fields = [field_univoco_feature, field_univoco_lotto, field_tripletta]
        if not self.ensure_required_fields(layer_path, layer_name_ogr, required_fields):
            print(f"❌ Impossibile preparare i campi per il layer {layer.name()} ({layer_name_ogr}), saltato")
            return False
        print(f"✅ Campi necessari per {layer.name()}({layer_name_ogr}) verificati/creati")
        
        # Calcola prefix/suffix per il layer e altri parametri
        print(f"Calcolando prefix/suffix per {layer.name()} ({layer_name_ogr})...")
        prefix, suffix = self._get_prefix_suffix_from_layer_name(layer_name_ogr)
        print(f"   → Prefix: '{prefix}' | Suffix: '{suffix}'")

        print(f"🔍 Aggiornamento features nel layer {layer.name()} ({layer_name_ogr})")
        result, rg_cod = CoderOGR.update_feature_by_fid(layer_path, layer_name_ogr, prefix, suffix, fid, lotto_name, field_univoco_feature, field_univoco_lotto, field_tripletta, cifre_max_nome_lotto, cifre_max_elementi_lotto)

        # Ricarica il layer in QGIS per riflettere le modifiche
        self.refresh_qgis_layer_safely(layer_path, layer_name_ogr)
        
        if result:
            print(f"✅ {layer.name()} feature {fid} aggiornata con successo {rg_cod}")
            return True, rg_cod
        else:
            print(f"❌ {layer.name()} errore nell'aggiornamento feature")
            return False, ''
        
    
    
    # B. Da feature QGIS selezionata -> OGR update
    def update_from_selected_qgis_features(self) -> bool:
        """
        Trova le features QGIS selezionate e le aggiorna tramite OGR diretto.
        
        Returns:
            True se l'aggiornamento è riuscito, False altrimenti
        """
        if not iface:
            print("QGIS Error: QGIS interface non disponibile")
            return False
        
        # Trova il layer attivo con feature selezionate
        active_layer = iface.activeLayer()
        if not active_layer or not isinstance(active_layer, QgsVectorLayer):
            print("QGIS Error: Nessun layer vettoriale attivo")
            return False
        
        # Ottieni informazioni sul layer per OGR
        layer_path, layer_name = self._extract_ogr_info_from_qgis_layer(active_layer)
        if not layer_path or not layer_name:
            print(f"❌ Impossibile accedere al layer attivo {active_layer.name()}")
            return False
                
        if not self.context.db.is_layer_rg_cod('', layer_name):
            print(f"QGIS Error: Il layer attivo '{active_layer.name()}' non è configurato per RG_COD")
            return False
        
        # Controlla che ci sia almeno una feature selezionata
        selected_features = active_layer.selectedFeatures()
        if not selected_features:
            print("QGIS Error: Nessuna feature selezionata nel layer attivo")
            return False
        
        # Parametri di contesto
        lotto_name = self.context.lotto_name
        field_univoco_feature = self.context.c.UNIVOCO_FEATURE
        field_univoco_lotto = self.context.c.UNIVOCO_LOTTO
        field_tripletta = self.context.c.TRIPLETTA
        cifre_max_nome_lotto = self.context.c.cifre_max_nome_lotto
        cifre_max_elementi_lotto = self.context.c.cifre_max_elementi_lotto        
        

        print(f"🔧 Preparando campi per layer '{layer_name}'...")
        required_fields = [field_univoco_feature, field_univoco_lotto, field_tripletta]
        if not self.ensure_required_fields(layer_path, layer_name, required_fields):
            print(f"❌ Impossibile preparare i campi per il layer '{layer_name}', saltato")
            return False
        print(f"✅ Campi necessari per '{layer_name}' verificati/creati")
        
        # Calcola prefix/suffix per il layer e altri parametri
        print(f"Calcolando prefix/suffix per '{layer_name}'...")
        prefix, suffix = self._get_prefix_suffix_from_layer_name(layer_name)
        print(f"   → Prefix: '{prefix}' | Suffix: '{suffix}'")

        print(f"🔍 Aggiornamento features  nel layer '{active_layer.name()}'")
        for feature in selected_features:
            result = CoderOGR.update_feature_by_fid(layer_path, layer_name, prefix, suffix, feature.id(), lotto_name, field_univoco_feature, field_univoco_lotto, field_tripletta, cifre_max_nome_lotto, cifre_max_elementi_lotto)

            if result:
                print(f"✅ {active_layer.name()} feature {feature.id()} aggiornata con successo")
            else:
                print(f"❌ {active_layer.name()} errore nell'aggiornamento feature")
        
        # Ricarica il layer in QGIS per riflettere le modifiche
        self.refresh_qgis_layer_safely(layer_path, layer_name)
        
        return True

    # C. Da layer QGIS selezionati -> OGR update
    def update_from_selected_qgis_layers(self) -> int:
        """
        Trova i layer QGIS selezionati e li aggiorna tramite OGR diretto.
        
        Returns:
            Numero totale di feature aggiornate con successo
        """
        if not iface:
            print("❌ QGIS interface non disponibile")
            return 0
        
        selected_layers = self.get_selected_layers_safe()
        
        if not selected_layers:
            print("🔄 Fallback al layer attivo")
            active_layer = iface.activeLayer()
            if not active_layer or not isinstance(active_layer, QgsVectorLayer):
                print("❌ Nessun layer vettoriale disponibile")
                return 0
            
            selected_layers = [active_layer]
            print(f"✅ Usando layer attivo: '{active_layer.name()}'")
        
        print(f"� Processando {len(selected_layers)} layer")
        
        # Usa il metodo helper per convertire e processare
        return self._convert_and_process_layers(selected_layers)

    # D. Da layer QGIS passati, fallback layer QGIS selezionati -> OGR update
    def update_from_qgis_layers(self, qgis_layers: Optional[List[QgsVectorLayer]] = None) -> int:
        """
        Aggiorna i layer QGIS specificati tramite OGR diretto.
        
        Args:
            qgis_layers: Lista di layer QGIS da aggiornare. Se None, usa rilevamento automatico.
            
        Returns:
            Numero totale di feature aggiornate con successo
        """
        if qgis_layers:
            print(f"📋 Processando {len(qgis_layers)} layer selezionati")
            selected_layers = [layer for layer in qgis_layers if isinstance(layer, QgsVectorLayer)]
            for i, layer in enumerate(selected_layers, 1):
                print(f"   {i}. '{layer.name()}' - Provider: {layer.dataProvider().name()}")
                
            # Processa la lista esplicita usando la logica esistente
            # Salta la rilevazione automatica e processa direttamente la lista
            print(f"� Analizzando {len(selected_layers)} layer")
            
            # Conversione QGIS → OGR (riutilizza logica esistente)
            return self._convert_and_process_layers(selected_layers)
        else:
            return self.update_from_selected_qgis_layers()

    
    # METODI debug/safe (non usati attualmente)

    def debug_layer_selection(self) -> List[QgsVectorLayer]:
        """
        Metodo di debug per mostrare tutti i layer disponibili e aiutare nella selezione.
        
        Returns:
            Lista di tutti i layer vettoriali del progetto
        """
        from qgis.core import QgsProject
        
        all_layers = []
        project = QgsProject.instance()
        
        print("� Layer disponibili nel progetto:")
        print(f"   → Totale layer nel progetto: {len(project.mapLayers())}")
        
        for layer_id, layer in project.mapLayers().items():
            if isinstance(layer, QgsVectorLayer):
                all_layers.append(layer)
                is_active = layer == iface.activeLayer() if iface else False
                print(f"   • '{layer.name()}' - Provider: {layer.dataProvider().name()}{' [ATTIVO]' if is_active else ''}")
        
        print(f"   → Layer vettoriali trovati: {len(all_layers)}")
        return all_layers 
    
    def safe_test(self) -> int:
        """
        Metodo di test ultra-sicuro per verificare che non ci siano crash.
        
        Returns:
            Numero di feature processate (sempre 0 per sicurezza in fase di test)
        """
        try:
            print("🧪 TEST SICURO: Inizio test senza modifiche effettive")
            
            if not iface:
                print("❌ TEST: QGIS interface non disponibile")
                return 0
            
            active_layer = iface.activeLayer()
            if not active_layer:
                print("❌ TEST: Nessun layer attivo")
                return 0
                
            if not isinstance(active_layer, QgsVectorLayer):
                print(f"❌ TEST: Layer attivo non è vettoriale: {type(active_layer)}")
                return 0
            
            print(f"✅ TEST: Layer attivo OK: '{active_layer.name()}'")
            print(f"   → Provider: {active_layer.dataProvider().name()}")
            print(f"   → Feature count: {active_layer.featureCount()}")
            print(f"   → È valido: {active_layer.isValid()}")
            
            # Test estrazione informazioni OGR (senza processare)
            layer_path, layer_name = self._extract_ogr_info_from_qgis_layer(active_layer)
            if layer_path and layer_name:
                print(f"✅ TEST: Estrazione OGR OK")
                print(f"   → Path: {layer_path}")
                print(f"   → Name: {layer_name}")
            else:
                print(f"❌ TEST: Estrazione OGR fallita")
                return 0
            
            print("🎉 TEST COMPLETATO: Nessun crash rilevato")
            return 0  # Restituisce 0 perché è solo un test
            
        except Exception as e:
            print(f"❌ Test non riuscito: {e}")
            # Error occurred, returning False
            return 0
    
    
    # METODI HELPER PRIVATI
    
    def _convert_and_process_layers(self, selected_layers: List[QgsVectorLayer]) -> int:
        """
        Helper per convertire layer QGIS in OGR e processarli.
        
        Args:
            selected_layers: Lista di layer QGIS da processare
            
        Returns:
            Numero totale di feature aggiornate
        """
        if not selected_layers:
            return 0
        
        total_updated = 0
        processed_files = set()  # Traccia i file modificati per il refresh finale
        
        # Calcola prefix/suffix per il layer e altri parametri
        lotto_name = self.context.lotto_name
        field_univoco_feature = self.context.c.UNIVOCO_FEATURE
        field_univoco_lotto = self.context.c.UNIVOCO_LOTTO
        field_tripletta = self.context.c.TRIPLETTA
        cifre_max_nome_lotto = self.context.c.cifre_max_nome_lotto
        cifre_max_elementi_lotto = self.context.c.cifre_max_elementi_lotto
        
        print(f"� Inizio aggiornamento di {len(selected_layers)} layer tramite OGR...")
        for qgs_layer in selected_layers:
            try:
                layer_path, layer_name = self._extract_ogr_info_from_qgis_layer(qgs_layer)
                
                if not layer_path or not layer_name:
                    print(f"❌ Impossibile accedere al layer '{qgs_layer.name()}', saltato")
                    continue
                
                if not self.context.db.is_layer_rg_cod('', layer_name):
                    print(f"❌ Il layer '{qgs_layer.name()}' non è configurato per RG_COD, saltato")
                    continue

                print(f"🔧 Preparando campi per layer '{layer_name}'...")
                required_fields = [field_univoco_feature, field_univoco_lotto, field_tripletta]
                if not self.ensure_required_fields(layer_path, layer_name, required_fields):
                    print(f"❌ Impossibile preparare i campi per il layer '{layer_name}', saltato")
                    continue
                print(f"✅ Campi necessari per '{layer_name}' verificati/creati")
                
                print(f"Calcolando prefix/suffix per '{layer_name}'...")
                prefix, suffix = self._get_prefix_suffix_from_layer_name(layer_name)
                print(f"   → Prefix: '{prefix}' | Suffix: '{suffix}'")
                
                print(f"OGR: Processando layer '{layer_name}' in '{layer_path}'...")
                result = CoderOGR.update_single_layer_ogr(layer_path, layer_name, prefix, suffix, lotto_name, field_univoco_feature, field_univoco_lotto, field_tripletta, cifre_max_nome_lotto, cifre_max_elementi_lotto)
                
                if result > 0:
                    print(f"✅ OGR: Layer '{layer_name}' aggiornato con successo - {result} feature modificate")
                    processed_files.add((layer_path, layer_name))  # Traccia per refresh finale
                else:
                    print(f"❌ OGR: Nessuna feature aggiornata per il layer '{layer_name}'")
                    
                total_updated += result
            except Exception as layer_error:
                print(f"❌ Errore processando '{qgs_layer.name()}': {layer_error}")
                continue

        # NUOVO: Refresh finale di tutti i layer modificati
        if processed_files:
            print(f"🔄 Refresh finale di {len(processed_files)} file modificati...")
            for layer_path, layer_name in processed_files:
                try:
                    self.refresh_qgis_layer_safely(layer_path, layer_name)
                except Exception as refresh_error:
                    print(f"⚠️ Errore refresh finale per '{layer_name}': {refresh_error}")

        print(f"🏁 Aggiornamento completato: {total_updated} feature aggiornate in totale")
        return total_updated
    
    def _extract_ogr_info_from_qgis_layer(self, qgs_layer: QgsVectorLayer) -> Tuple[Optional[str], Optional[str]]:
        """
        Estrae le informazioni necessarie per OGR da un layer QGIS.
        
        Args:
            qgs_layer: Layer QGIS da analizzare
            
        Returns:
            Tuple (layer_path, layer_name) o (None, None) se non riuscito
        """
        try:
            # Validazione del layer
            if qgs_layer is None or not qgs_layer.isValid():
                return None, None
            
            # Ottieni la sorgente del layer
            try:
                data_source = qgs_layer.source()
                if not data_source:
                    return None, None
                    
            except Exception:
                return None, None
            
            # Estrai il percorso del file (rimuovi parametri come |layername=xxx)
            match = re.match(r'^([^|]+)', data_source)
            if not match:
                return None, None
            
            layer_path = match.group(1)
            
            # Verifica che il file esista
            if not Path(layer_path).exists():
                return None, None
            
            # Estrai il nome del layer
            try:
                layer_name = self._get_layer_source_name(qgs_layer)
                if not layer_name:
                    return None, None
                    
            except Exception:
                return None, None
            return layer_path, layer_name
            
        except Exception:
            return None, None
    
    def _get_layer_source_name(self, layer: QgsVectorLayer) -> Optional[str]:
        """
        Ottiene il nome della sorgente del layer per OGR.
        
        Args:
            layer: Layer QGIS da analizzare
            
        Returns:
            Nome del layer per OGR o None se non determinabile
        """
        try:
            provider_type = layer.dataProvider().name()
            source = layer.source()
            
            if provider_type == "ogr":
                # Per provider OGR, cerca il parametro layername
                if "|layername=" in source:
                    layer_name = source.split("|layername=")[1].split("|")[0]
                    return layer_name
                else:
                    # Se non c'è layername, usa il nome del layer QGIS
                    return layer.name()
            else:
                # Per altri provider, usa il nome del layer
                return layer.name()
                
        except Exception as e:
            print(f"Error in _get_layer_source_name: {e}")
            return None
    
    def _get_prefix_suffix_from_layer_name(self, layer_name: str) -> Tuple[str, str]:
        """
        Determina prefix e suffix dal nome del layer.
        
        Args:
            layer_name: Nome del layer
            
        Returns:
            Tuple (prefix, suffix)
        """
        try:
            # Logica per determinare prefix/suffix dal nome del layer
            if hasattr(self.context, 'db') and self.context.db:
                prefix, suffix = self.context.db.get_layer_prefix_suffix('', layer_name)
                return prefix, suffix
            else:
                return '', ''  # Default sicuro
        except Exception as e:
            print(f"Error in _get_prefix_suffix_from_layer_name: {e}")
            return '', ''  # Default sicuro
    

    # Verifica e crea campi richiesti mancanti
    def ensure_required_fields(self, layer_path: str, layer_name: str, required_field_names: List[str]) -> bool:
        """
        Verifica e crea automaticamente i campi necessari nel layer.
        
        Utilizza CoderOGR.ensure_fields_exist per garantire che i campi
        specificati esistano nel layer con i tipi corretti.
        
        Args:
            layer_path: Percorso al file contenente il layer
            layer_name: Nome del layer all'interno del file
            required_field_names: Lista dei nomi dei campi da verificare/creare
            
        Returns:
            True se tutti i campi richiesti esistono o sono stati creati, False altrimenti
        """
        existing_fields, missing_fields = CoderOGR._check_existing_fields(layer_path, layer_name, required_field_names)
        
        print(f"🔧 Verificando {len(required_field_names)} campi richiesti per layer '{layer_name}':")
        for f in existing_fields:
            print(f"   • Campo esistente: '{f}'")
        
        if not missing_fields:
            print(f"⚠️ Nessun campo da verificare per il layer '{layer_name}'")
            return True
            
        # Prepara la lista di campi richiesti con i loro tipi
        required_fields = []
        
        for field_name in missing_fields:
            try:
                # Ottieni il tipo di campo dal database di configurazione
                db_field_type = self.context.db.get_field_type('', layer_name, field_name)
                
                # Converti il tipo dal database al tipo OGR
                ogr_type = self._convert_db_type_to_ogr(db_field_type)
                
                if ogr_type is None:
                    print(f"❌ Tipo di campo non riconosciuto per '{field_name}' nel layer '{layer_name}'")
                    return False
                
                # Calcola la larghezza del campo
                # field_width = self._get_field_width(db_field_type)
                
                # Aggiungi alla lista dei campi richiesti
                # required_fields.append((field_name, ogr_type, field_width))
                required_fields.append((field_name, ogr_type, 0))  # Usando 0 come larghezza di default
                
            except Exception as e:
                print(f"❌ Errore nell'ottenere le informazioni per il campo '{field_name}': {e}")
                return False
            
        if not required_fields:
            print(f"❌ Nessun campo valido da processare per il layer '{layer_name}'")
            return False
        
        for field_name, field_type, field_width in required_fields:
            type_name = CoderOGR._get_field_type_name(field_type)
            print(f"   • Campo mancante: '{field_name}' ({type_name}, larghezza: {field_width})")
        
        
        # Chiama il metodo ensure_fields_exist di CoderOGR
        success = CoderOGR.ensure_fields_exist(layer_path, layer_name, required_fields)
        
        if success:
            print(f"✅ Tutti i campi mancanti richiesti ({len(required_fields)}) sono pronti per il layer '{layer_name}'")
            
            # NUOVO: Ricarica automaticamente il layer in QGIS dopo modifiche OGR
            print(f"🔄 Ricaricando layer QGIS dopo modifiche OGR...")
            refresh_success = self.refresh_qgis_layer_safely(layer_path, layer_name)
            
            if refresh_success:
                print(f"✅ Layer QGIS ricaricato con successo")
            else:
                print(f"⚠️ Ricaricamento layer QGIS fallito (non critico per l'operazione)")
            
        else:
            print(f"❌ Impossibile garantire i campi richiesti per il layer '{layer_name}'")
        
        return success
            
    # Metodo di utilità per convertire tipi di campo DB in tipi OGR
    def _convert_db_type_to_ogr(self, db_field_type: str) -> Optional[int]:
        """
        Converte il tipo di campo dal database alla costante OGR corrispondente.
        
        Args:
            db_field_type: Tipo di campo come restituito da db.get_field_type
            
        Returns:
            Costante OGR corrispondente o None se non riconosciuto
        """
        from osgeo import ogr
        
        # Normalizza il tipo in lowercase per il confronto
        field_type_lower = str(db_field_type).lower()
        
        # Mapping dei tipi comuni
        type_mapping = {
            'string': ogr.OFTString,
            'text': ogr.OFTString,
            'varchar': ogr.OFTString,
            'char': ogr.OFTString,
            'integer': ogr.OFTInteger,
            'int': ogr.OFTInteger,
            'real': ogr.OFTReal,
            'float': ogr.OFTReal,
            'double': ogr.OFTReal,
            'date': ogr.OFTDate,
            'time': ogr.OFTTime,
            'datetime': ogr.OFTDateTime,
            'timestamp': ogr.OFTDateTime
        }
        
        # Cerca corrispondenza esatta o parziale
        for db_type, ogr_type in type_mapping.items():
            if db_type in field_type_lower:
                return ogr_type
        
        # Default per tipi non riconosciuti (assumiamo stringa)
        print(f"⚠️ Tipo campo '{db_field_type}' non riconosciuto, usando String come default")
        return ogr.OFTString

    # Metodo non usato attualmente, ma utile per future estensioni
    # usato 0 come larghezza di default per semplicità
    def _get_field_width(self, db_field_type: str) -> int:
        """
        Determina la larghezza del campo basata sul tipo.
        
        Args:
            db_field_type: Tipo di campo dal database
            
        Returns:
            Larghezza del campo (0 per tipi numerici, valore appropriato per stringhe)
        """
        field_type_lower = str(db_field_type).lower()
        
        # Per i campi stringa, imposta una larghezza ragionevole
        if any(string_type in field_type_lower for string_type in ['string', 'text', 'varchar', 'char']):
            # Controlla se c'è una specifica di lunghezza nel tipo (es: VARCHAR(50))
            import re
            match = re.search(r'\((\d+)\)', db_field_type)
            if match:
                return int(match.group(1))
            else:
                # Default per campi stringa senza specifica di lunghezza
                return 255
        
        # Per tutti gli altri tipi (numerici, date, etc.), larghezza 0
        return 0    
    
    # Metodo principale per ricaricare un layer QGIS in modo sicuro
    def refresh_qgis_layer_safely(self, layer_path: str, layer_name: str) -> bool:
        """
        Ricarica un layer QGIS dopo modifiche OGR per evitare crash e inconsistenze.
        
        Quando si modificano i campi di un layer tramite OGR direttamente sul file,
        QGIS non rileva automaticamente i cambiamenti. Questo metodo forza il
        ricaricamento del layer in modo sicuro.
        
        Args:
            layer_path: Percorso al file contenente il layer
            layer_name: Nome del layer all'interno del file
            
        Returns:
            True se il ricaricamento è riuscito, False altrimenti
        """
        try:
            if not iface:
                print("❌ QGIS interface non disponibile per il refresh")
                return False
            
            from qgis.core import QgsProject, QgsVectorLayer
            
            project = QgsProject.instance()
            layers_to_refresh = []
            
            # Trova tutti i layer QGIS che corrispondono al file modificato
            for layer_id, qgs_layer in project.mapLayers().items():
                if not isinstance(qgs_layer, QgsVectorLayer):
                    continue
                
                try:
                    # Verifica se questo layer corrisponde al file modificato
                    current_path, current_name = self._extract_ogr_info_from_qgis_layer(qgs_layer)
                    
                    if (current_path and current_name and 
                        Path(current_path).resolve() == Path(layer_path).resolve() and
                        current_name == layer_name):
                        layers_to_refresh.append(qgs_layer)
                        
                except Exception as e:
                    print(f"⚠️ Errore verificando layer '{qgs_layer.name()}': {e}")
                    continue
            
            if not layers_to_refresh:
                print(f"📝 Nessun layer QGIS trovato per '{layer_name}' in '{layer_path}'")
                return True  # Non è un errore, semplicemente non c'è nulla da ricaricare
            
            # Ricarica ogni layer trovato
            refresh_count = 0
            for qgs_layer in layers_to_refresh:
                try:
                    layer_display_name = qgs_layer.name()
                    print(f"🔄 Ricaricando layer QGIS '{layer_display_name}'...")
                    
                    # Metodo 1: Ricarica il data provider
                    if hasattr(qgs_layer, 'dataProvider') and qgs_layer.dataProvider():
                        qgs_layer.dataProvider().reloadData()
                        print(f"   ✅ Data provider ricaricato per '{layer_display_name}'")
                    
                    # Metodo 2: Ricarica la struttura dei campi
                    if hasattr(qgs_layer, 'updateFields'):
                        qgs_layer.updateFields()
                        print(f"   ✅ Struttura campi aggiornata per '{layer_display_name}'")
                    
                    # Metodo 3: Invalida cache e forza refresh
                    if hasattr(qgs_layer, 'triggerRepaint'):
                        qgs_layer.triggerRepaint()
                        print(f"   ✅ Repaint triggerato per '{layer_display_name}'")
                    
                    # Metodo 4: Notifica cambiamenti al progetto
                    if hasattr(qgs_layer, 'layerModified'):
                        qgs_layer.layerModified.emit()
                        print(f"   ✅ Segnale layerModified emesso per '{layer_display_name}'")
                    
                    # Aggiorna anche la vista della tabella attributi se aperta
                    if iface.activeLayer() == qgs_layer:
                        iface.mapCanvas().refresh()
                        print(f"   ✅ Canvas aggiornato per layer attivo '{layer_display_name}'")
                    
                    refresh_count += 1
                    print(f"✅ Layer '{layer_display_name}' ricaricato con successo")
                    
                except Exception as layer_error:
                    print(f"❌ Errore ricaricando layer '{qgs_layer.name()}': {layer_error}")
                    continue
            
            if refresh_count > 0:
                print(f"🎉 Ricaricamento completato: {refresh_count}/{len(layers_to_refresh)} layer aggiornati")
                
                # Refresh globale del progetto per sicurezza
                try:
                    if hasattr(project, 'layersWillBeRemoved'):
                        # Trigger un refresh globale leggero
                        iface.mapCanvas().refreshAllLayers()
                        print("   ✅ Refresh globale dei layer completato")
                except Exception as global_error:
                    print(f"   ⚠️ Refresh globale fallito (non critico): {global_error}")
                
                return True
            else:
                print(f"❌ Nessun layer ricaricato con successo")
                return False
                
        except Exception as e:
            print(f"❌ Errore critico in refresh_qgis_layer_safely: {e}")
            return False

    # Metodo aggiuntivo per ricaricare tutti i layer del progetto
    # utile dopo operazioni massive OGR
    # non usato attualmente
    def refresh_all_project_layers_safely(self) -> int:
        """
        Ricarica tutti i layer del progetto QGIS in modo sicuro.
        
        Utile dopo operazioni OGR massive che potrebbero aver modificato
        più file contemporaneamente.
        
        Returns:
            Numero di layer ricaricati con successo
        """
        try:
            if not iface:
                print("❌ QGIS interface non disponibile per il refresh globale")
                return 0
            
            from qgis.core import QgsProject, QgsVectorLayer
            
            project = QgsProject.instance()
            refresh_count = 0
            
            print("🔄 Ricaricamento globale di tutti i layer vettoriali del progetto...")
            
            for layer_id, qgs_layer in project.mapLayers().items():
                if not isinstance(qgs_layer, QgsVectorLayer):
                    continue
                
                try:
                    layer_display_name = qgs_layer.name()
                    
                    # Ricarica sicura del layer
                    if (hasattr(qgs_layer, 'dataProvider') and qgs_layer.dataProvider() and
                        hasattr(qgs_layer.dataProvider(), 'reloadData')):
                        qgs_layer.dataProvider().reloadData()
                    
                    if hasattr(qgs_layer, 'updateFields'):
                        qgs_layer.updateFields()
                    
                    if hasattr(qgs_layer, 'triggerRepaint'):
                        qgs_layer.triggerRepaint()
                    
                    refresh_count += 1
                    print(f"   ✅ '{layer_display_name}' ricaricato")
                    
                except Exception as layer_error:
                    print(f"   ❌ Errore ricaricando '{qgs_layer.name()}': {layer_error}")
                    continue
            
            # Refresh finale del canvas
            try:
                iface.mapCanvas().refreshAllLayers()
                print("✅ Canvas globale aggiornato")
            except Exception as canvas_error:
                print(f"⚠️ Errore refresh canvas (non critico): {canvas_error}")
            
            print(f"🎉 Ricaricamento globale completato: {refresh_count} layer aggiornati")
            return refresh_count
            
        except Exception as e:
            print(f"❌ Errore critico in refresh_all_project_layers_safely: {e}")
            return 0