# -*- coding: utf-8 -*-
"""
RG_COD module for AUTOMATE plugin v2.0
Contains RG_COD calculation, layer updating, and signal management.
"""

from .coder_manager import CoderManager
from .switch import Switch

__all__ = ['CoderManager', 'Switch']
