# -*- coding: utf-8 -*-
"""
/***************************************************************************
 SignalManager
                                 A QGIS plugin
 The AUTOMATE plug-in
                             -------------------
        begin                : 2024-09-23
        copyright            : (C) 2024 by Ing. Antonio Attadia
        email                : info.antatta@gmail.com
        git sha              : $Format:%H$
 ***************************************************************************/
 Class for Qt signal management
"""

from qgis.core import QgsVectorLayer
from qgis.PyQt.QtCore import pyqtBoundSignal, QMetaObject
from .layer_updater import LayerUpdater


class SignalManager:
    """Gestisce la connessione e disconnessione dei segnali dei layer"""
    def __init__(self, updater: LayerUpdater):
        self.updater = updater
        self.connected_signals: dict[str, list[tuple[pyqtBoundSignal, QMetaObject.Connection]]] = {}

    def connect_layer_signals(self, layer: QgsVectorLayer):
        if layer.id() not in self.connected_signals:
            self.connected_signals[layer.id()] = []
            
        value_changed = layer.attributeValueChanged.connect(
            lambda fid: self.updater.update_feature('change', layer, fid)
        )
        self.connected_signals[layer.id()].append((layer.attributeValueChanged, value_changed))
        
        feature_added = layer.featureAdded.connect(
            lambda fid: self.updater.update_feature('added', layer, fid, True)
        )
        self.connected_signals[layer.id()].append((layer.featureAdded, feature_added))
        
        print(f"connect_layer_signals -> Connesso segnale a: {layer.name()=}")

    def disconnect_layer_signals(self, layer: QgsVectorLayer):
        layer_id = layer.id()
        if layer_id in self.connected_signals:
            for signal, connection in self.connected_signals[layer_id]:
                try:
                    signal.disconnect(connection)
                    print(f"disconnect_layer_signals -> Disconnesso segnale: {signal.signal} da {layer.name()=}")
                except Exception as e:
                    print(f"disconnect_layer_signals -> Errore durante la disconnessione: {e}")
            del self.connected_signals[layer_id]
