# -*- coding: utf-8 -*-
"""
/***************************************************************************
 Switch
                                 A QGIS plugin
 The AUTOMATE plug-in
                             -------------------
        begin                : 2024-09-23
        copyright            : (C) 2024 by Ing. Antonio Attadia
        email                : info.antatta@gmail.com
        git sha              : $Format:%H$
 ***************************************************************************/
 Enhanced Switch Button Component

 Features:
 - Smooth animations with customizable duration
 - Theme support (success, danger, warning, info, primary, default)  
 - Scalable dimensions maintaining proportions
 - Dynamic tooltips for on/off states
 - GitLab and Android UI styles support
 - Professional color schemes with Bootstrap compatibility
 - Accessibility features (cursor, opacity states)
 - Shake effect for feedback on rejection
"""
from PyQt5.QtCore import QPropertyAnimation, QRectF, QSize, Qt, pyqtProperty
from PyQt5.QtGui import QPainter, QColor
from PyQt5.QtWidgets import (
    QAbstractButton,
    QApplication,
    QHBoxLayout,
    QSizePolicy,
    QWidget,
)


class Switch(QAbstractButton):
    def __init__(self, parent=None, track_radius=10, thumb_radius=8):
        super().__init__(parent=parent)
        self.setCheckable(True)
        self.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)

        self._track_radius = track_radius
        self._thumb_radius = thumb_radius

        self._margin = max(0, self._thumb_radius - self._track_radius)
        self._base_offset = max(self._thumb_radius, self._track_radius)
        self._end_offset = {
            True: lambda: self.width() - self._base_offset,
            False: lambda: self._base_offset,
        }
        self._offset = self._base_offset
        
        # Inizializzazione nuove proprietà
        self._animation_duration = 120
        self._tooltip_on = "Attivo"
        self._tooltip_off = "Disattivo"

        palette = self.palette()
        if self._thumb_radius > self._track_radius:
            self._thumb_color = {
                True: palette.highlight(),
                False: palette.light(),
            }
            self._track_color = {
                True: palette.highlight(),
                False: palette.dark(),
            }
            self._text_color = {
                True: palette.highlightedText().color(),
                False: palette.dark().color(),
            }
            self._thumb_text = {
                True: '',
                False: '',
            }
            self._track_opacity = 0.5
        else:
            self._thumb_color = {
                True: palette.highlightedText(),
                False: palette.light(),
            }
            self._track_color = {
                True: palette.highlight(),
                False: palette.dark(),
            }
            self._text_color = {
                True: palette.highlight().color(),
                False: palette.dark().color(),
            }
            self._thumb_text = {
                True: '✔',
                False: '✕',
            }
            self._track_opacity = 1

    def set_active_track_color(self, color):
        """Imposta il colore del track per lo stato attivo (True)"""
        #color:QColor
        if isinstance(color, QColor):
            self._track_color[True] = color
            self.update()  # Forza il ridisegno dello switch
    
    def set_active_thumb_color(self, color):
        """Imposta il colore del track per lo stato attivo (True)"""
        #color:QColor
        if isinstance(color, QColor):
            self._thumb_color[True] = color.darker(150)
            self.update()  # Forza il ridisegno dello switch
    
    def set_tooltip_text(self, on_text="Attivo", off_text="Disattivo"):
        """
        Imposta tooltip personalizzabili per gli stati on/off.
        
        Args:
            on_text (str): Testo tooltip quando lo switch è attivo
            off_text (str): Testo tooltip quando lo switch è disattivo
        """
        self._tooltip_on = on_text
        self._tooltip_off = off_text
        self._update_tooltip()
    
    def _update_tooltip(self):
        """Aggiorna il tooltip basato sullo stato corrente"""
        if hasattr(self, '_tooltip_on') and hasattr(self, '_tooltip_off'):
            tooltip = self._tooltip_on if self.isChecked() else self._tooltip_off
            self.setToolTip(tooltip)
    
    def setScale(self, scale_factor=1.0):
        """
        Scala lo switch mantenendo le proporzioni.
        
        Args:
            scale_factor (float): Fattore di scala (1.0 = dimensione normale)
        """
        self._track_radius = int(10 * scale_factor)
        self._thumb_radius = int(8 * scale_factor)
        
        # Ricalcola offset e margini
        self._margin = max(0, self._thumb_radius - self._track_radius)
        self._base_offset = max(self._thumb_radius, self._track_radius)
        self._end_offset = {
            True: lambda: self.width() - self._base_offset,
            False: lambda: self._base_offset,
        }
        
        # Aggiorna le dimensioni
        self.updateGeometry()
        self.update()
    
    def apply_theme(self, theme="default"):
        """
        Applica un tema predefinito al componente.
        
        Args:
            theme (str): Tema da applicare ("success", "danger", "warning", "info", "default")
        """
        themes = {
            "success": {
                "track": QColor(40, 167, 69),    # Verde Bootstrap
                "thumb": QColor(33, 136, 56)     # Verde più scuro
            },
            "danger": {
                "track": QColor(220, 53, 69),    # Rosso Bootstrap
                "thumb": QColor(176, 42, 55)     # Rosso più scuro
            },
            "warning": {
                "track": QColor(255, 193, 7),    # Giallo Bootstrap
                "thumb": QColor(204, 154, 5)     # Giallo più scuro
            },
            "info": {
                "track": QColor(23, 162, 184),   # Ciano Bootstrap
                "thumb": QColor(18, 130, 147)    # Ciano più scuro
            },
            "primary": {
                "track": QColor(0, 123, 255),    # Blu Bootstrap
                "thumb": QColor(0, 98, 204)      # Blu più scuro
            },
            "default": None  # Usa i colori di sistema
        }
        
        if theme in themes and themes[theme] is not None:
            colors = themes[theme]
            self.set_active_track_color(colors["track"])
            self.set_active_thumb_color(colors["thumb"])
        elif theme == "default":
            # Ripristina colori di sistema
            palette = self.palette()
            self._track_color[True] = palette.highlight()
            self._thumb_color[True] = palette.highlightedText()
            self.update()
    
    def set_animation_duration(self, duration_ms=120):
        """
        Imposta la durata dell'animazione di transizione.
        
        Args:
            duration_ms (int): Durata in millisecondi (default: 120)
        """
        self._animation_duration = max(50, min(duration_ms, 1000))  # Clamp tra 50-1000ms
            
    @pyqtProperty(int)  # pylint: disable=invalid-name
    def offset(self):
        return self._offset

    @offset.setter
    def offset(self, value):
        self._offset = value
        self.update()

    def sizeHint(self):  # pylint: disable=invalid-name
        return QSize(
            4 * self._track_radius + 2 * self._margin,
            2 * self._track_radius + 2 * self._margin,
        )

    def setChecked(self, checked):
        super().setChecked(checked)
        self.offset = self._end_offset[checked]()
        self._update_tooltip()  # Aggiorna tooltip quando cambia stato

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self.offset = self._end_offset[self.isChecked()]()

    def paintEvent(self, event):  # pylint: disable=invalid-name, unused-argument
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        p.setPen(Qt.NoPen)
        track_opacity = self._track_opacity
        thumb_opacity = 1.0
        text_opacity = 1.0
        if self.isEnabled():
            track_brush = self._track_color[self.isChecked()]
            thumb_brush = self._thumb_color[self.isChecked()]
            text_color = self._text_color[self.isChecked()]
        else:
            track_opacity *= 0.8
            track_brush = self.palette().shadow()
            thumb_brush = self.palette().mid()
            text_color = self.palette().shadow().color()

        p.setBrush(track_brush)
        p.setOpacity(track_opacity)
        p.drawRoundedRect(
            self._margin,
            self._margin,
            self.width() - 2 * self._margin,
            self.height() - 2 * self._margin,
            self._track_radius,
            self._track_radius,
        )
        p.setBrush(thumb_brush)
        p.setOpacity(thumb_opacity)
        p.drawEllipse(
            self.offset - self._thumb_radius,
            self._base_offset - self._thumb_radius,
            2 * self._thumb_radius,
            2 * self._thumb_radius,
        )
        p.setPen(text_color)
        p.setOpacity(text_opacity)
        font = p.font()
        font.setPixelSize(int(1.5 * self._thumb_radius))
        p.setFont(font)
        p.drawText(
            QRectF(
                self.offset - self._thumb_radius,
                self._base_offset - self._thumb_radius,
                2 * self._thumb_radius,
                2 * self._thumb_radius,
            ),
            Qt.AlignCenter,
            self._thumb_text[self.isChecked()],
        )

    def mouseReleaseEvent(self, event):  # pylint: disable=invalid-name
        super().mouseReleaseEvent(event)
        if event.button() == Qt.LeftButton:
            anim = QPropertyAnimation(self, b'offset', self)
            duration = getattr(self, '_animation_duration', 120)  # Usa durata personalizzata o default
            anim.setDuration(duration)
            anim.setStartValue(self.offset)
            anim.setEndValue(self._end_offset[self.isChecked()]())
            anim.start()
            self._update_tooltip()  # Aggiorna tooltip dopo l'animazione

    def enterEvent(self, event):  # pylint: disable=invalid-name
        self.setCursor(Qt.PointingHandCursor)
        super().enterEvent(event)

    def showRejectionFeedback(self, duration_ms=400, with_shake=False):
        """
        Mostra un feedback visivo quando lo switch viene rifiutato.
        
        Args:
            duration_ms: Durata del feedback in millisecondi
            with_shake: Se True, aggiunge un effetto shake
        """
        from PyQt5.QtCore import QTimer, QPropertyAnimation, QRect, QEasingCurve
        from PyQt5.QtGui import QColor
        
        if not self.isChecked():
            return
        
        # Salva colore originale
        original_color = self._track_color[True]
        error_color = QColor(220, 53, 69)
        
        # Cambia colore
        self.set_active_track_color(error_color)
        
        # Effetto shake opzionale
        if with_shake:
            self._shake_effect(duration_ms - int(duration_ms/10))  # Finisce 50ms prima del reset
        
        # Reset programmato
        def reset_switch():
            self.set_active_track_color(original_color)
            self.blockSignals(True)
            self.setChecked(False)
            self.blockSignals(False)
        
        QTimer.singleShot(duration_ms, reset_switch)

    def _shake_effect(self, total_duration_ms=300):
        """Effetto shake per feedback negativo"""
        from PyQt5.QtCore import QPropertyAnimation, QRect, QEasingCurve
        
        original_rect = self.geometry()
        
        # Calcola durata per singolo shake per riempire il tempo totale
        single_shake_duration = min(150, total_duration_ms // 3)  # Max 150ms per shake
        loop_count = max(2, total_duration_ms // single_shake_duration)
        
        self.shake_animation = QPropertyAnimation(self, b"geometry")
        self.shake_animation.setDuration(single_shake_duration)
        self.shake_animation.setLoopCount(loop_count)
        
        # Movimento di 2px a destra e sinistra
        shake_rect = QRect(original_rect.x() + 10, original_rect.y(), 
                        original_rect.width(), original_rect.height())
        
        self.shake_animation.setStartValue(original_rect)
        self.shake_animation.setKeyValueAt(0.5, shake_rect)
        self.shake_animation.setEndValue(original_rect)
        self.shake_animation.setEasingCurve(QEasingCurve.InOutQuad)
        self.shake_animation.start()


def main():
    app = QApplication([])
    
    # Switch base (Gitlab style)
    s0 = Switch()
    s0.set_tooltip_text("RG_COD Attivo", "RG_COD Disattivo")
    s0.toggled.connect(lambda c: print('Switch base toggled:', c))

    # Switch con tema "danger"
    s1 = Switch()
    s1.apply_theme("danger")
    s1.set_tooltip_text("Modalità Debug ON", "Modalità Debug OFF")
    s1.toggled.connect(lambda c: print('Debug mode:', c))
    
    # Switch disabilitato
    s2 = Switch()
    s2.setEnabled(False)
    s2.setToolTip("Switch disabilitato")
    

    # Switch Android style con tema "success"
    s3 = Switch(thumb_radius=11, track_radius=8)
    s3.apply_theme("success")
    s3.set_tooltip_text("Auto-save ON", "Auto-save OFF")
    s3.set_animation_duration(200)  # Animazione più lenta
    
    # Switch scalato e con tema "warning"
    s4 = Switch(thumb_radius=11, track_radius=8)
    s4.apply_theme("warning")
    s4.setScale(1.2)  # 20% più grande
    s4.set_tooltip_text("Modalità Test", "Modalità Normale")
    
    # Switch con tema "info"
    s5 = Switch(thumb_radius=11, track_radius=8)
    s5.apply_theme("info")
    s5.set_animation_duration(50)  # Animazione veloce
    s5.setEnabled(False)

    # Switch con tema "primary"
    s6 = Switch()
    s6.apply_theme("primary")
    s6.set_tooltip_text("Connessione Attiva", "Connessione Inattiva")

    l = QHBoxLayout()
    l.addWidget(s0)
    l.addWidget(s1)
    l.addWidget(s2)
    l.addWidget(s3)
    l.addWidget(s4)
    l.addWidget(s5)
    l.addWidget(s6)
    w = QWidget()
    w.setLayout(l)
    w.setWindowTitle("Switch Component - Improved Version")
    w.show()

    app.exec()


if __name__ == '__main__':
    main()