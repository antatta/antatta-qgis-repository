# -*- coding: utf-8 -*-
"""
/***************************************************************************
 CodeManager
                                 A QGIS plugin
 The AUTOMATE plug-in
                             -------------------
        begin                : 2024-09-23
        copyright            : (C) 2024 by Ing. Antonio Attadia
        email                : info.antatta@gmail.com
        git sha              : $Format:%H$
 ***************************************************************************/
 Class for coordinating RG_COD management classes
"""
# # 1. FUTURE IMPORTS
from __future__ import annotations  # SEMPRE in cima!

# # 2. STANDARD LIBRARY
from typing import Tuple

# # 3. THIRD-PARTY LIBRARIES
from qgis.core import QgsVectorLayer, QgsProject
from qgis.utils import iface

# # 5. LOCAL IMPORTS
from ...core import AutomateContext
from .coder_qgis import CoderQGIS
from .signal_coder_qgis import SignalCoderQGIS


class CoderManager:
    """Coordina le tre classi principali"""
    def __init__(self, context:AutomateContext, callback=None):
        self.context = context
        self.callback = callback

        self.qgis_updater = CoderQGIS(context)  # Nuovo updater per integrazione QGIS
        self.signal_manager_qgis = SignalCoderQGIS(self.qgis_updater)  # Gestore segnali per CoderQGIS

    def run(self):
        """
        Avvia la gestione automatica dei segnali RG_COD per tutti i layer configurati.
        
        Semplicemente connette i segnali tramite SignalManagerQGIS.
        """
        assert self.context is not None, "Context must be provided"
        assert self.context.db is not None, "Database connection must be available in context"
        
        print("🚀 Avvio CodeManager con SignalManagerQGIS...")
        
        # Disconnetti il segnale layersAdded precedente se esiste
        if hasattr(self, 'layers_added_connection'):
            try:
                QgsProject.instance().layersAdded.disconnect(self.layers_added_connection)
                print("🔌 Disconnesso segnale layersAdded precedente")
            except:
                pass
        
        # Connetti il segnale layersAdded per gestire automaticamente nuovi layer
        self.layers_added_connection = QgsProject.instance().layersAdded.connect(
            lambda layers: self._on_layers_added(layers)
        )
        print("🔗 Connesso segnale layersAdded per gestione automatica nuovi layer")
        
        # Connetti segnali per tutti i layer RG_COD attualmente nel progetto
        connected_count = 0
        for layer in QgsProject.instance().mapLayers().values():
            if isinstance(layer, QgsVectorLayer):
                if self.signal_manager_qgis.connect_layer_signals(layer):
                    connected_count += 1
        
        print(f"🎉 CodeManager avviato: {connected_count} layer connessi con SignalManagerQGIS")
    
    def _on_layers_added(self, layers):
        """
        Gestore per il segnale layersAdded - connette automaticamente nuovi layer RG_COD.
        
        Args:
            layers: Lista di layer aggiunti al progetto
        """
        try:
            print(f"➕ Aggiunti {len(layers)} nuovi layer al progetto")
            
            for layer in layers:
                if isinstance(layer, QgsVectorLayer):
                    self.signal_manager_qgis.connect_layer_signals(layer)
                    
        except Exception as e:
            print(f"❌ Errore in _on_layers_added: {e}")

    def stop(self):
        """
        Ferma la gestione automatica dei segnali RG_COD e disconnette tutti i layer.
        """
        print("🛑 Fermando CodeManager...")
        
        # Disconnetti il segnale layersAdded
        if hasattr(self, 'layers_added_connection'):
            try:
                QgsProject.instance().layersAdded.disconnect(self.layers_added_connection)
                delattr(self, 'layers_added_connection')
                print("🔌 Disconnesso segnale layersAdded")
            except Exception as e:
                print(f"❌ Errore disconnettendo segnale layersAdded: {e}")

        # Disconnetti tutti i segnali dai layer tramite SignalManagerQGIS
        disconnected_count = self.signal_manager_qgis.disconnect_all_signals()
        print(f"🔌 Disconnessi segnali da {disconnected_count} layer")
        
        print("✅ CodeManager fermato con successo")
        if self.callback:
            self.callback(True)
        
        
    def run_on_selected_layers(self):        
        """
        Aggiorna i codici RG_COD per uno o più layer selezionati in QGIS.
        
        Utilizza CoderQGIS che:
        - Rileva layer selezionati nel pannello QGIS
        - Se nessuna selezione, usa il layer attivo
        - Delega l'aggiornamento a CoderOGR per prestazioni ottimali
        """
        try:
            
            print("✅ Procedendo con aggiornamento...")
            # Usa CoderQGIS per gestire layer selezionati
            updated_count = self.qgis_updater.update_from_selected_qgis_layers()
            
        except Exception as e:
            print(f"❌ Errore inaspettato: {e}")
            if self.callback:
                self.callback(False)

        if updated_count > 0:
            print(f"CodeManager: Aggiornate {updated_count} feature tramite CoderQGIS")
            if self.callback:
                self.callback(True)
        else:
            print("CodeManager: Nessuna feature aggiornata - verificare selezione layer e configurazione DB")
            if self.callback:
                self.callback(False)
                
    def run_on_selected_features(self):        
        """
        Aggiorna i codici RG_COD per una singola feature selezionata.
        
        Utilizza CoderQGIS per gestire la feature corrente nel layer attivo.
        """
        try:
            # Usa CoderQGIS per gestire la feature selezionata
            success = self.qgis_updater.update_from_selected_qgis_features()
            
            if success:
                print(f"CodeManager: Feature aggiornata tramite CoderQGIS")
                if self.callback:
                    self.callback(True)
            else:
                print(f"CodeManager: Impossibile aggiornare feature")
                if self.callback:
                    self.callback(False)

        except Exception as e:
            print(f"CodeManager Error in run_on_features: {e}")
            if self.callback:
                self.callback(False)

    def run_on_feature_by_fid(self, layer: QgsVectorLayer, fid: int) -> Tuple[bool, str]:
        """
        Aggiorna il codice RG_COD per una singola feature identificata dal suo FID.
        
        Args:
            layer: Il layer contenente la feature da aggiornare
            fid: ID della feature da aggiornare
        """
        try:
            print(f"✅ Procedendo con aggiornamento feature FID {fid} in {layer.name()}...")
            # Usa CoderQGIS per gestire l'aggiornamento della feature specifica
            success, rg_cod = self.qgis_updater.update_feature_by_fid(layer, fid)
            
            if success:
                print(f"CodeManager: Feature FID {fid} aggiornata tramite CoderQGIS")
                if self.callback:
                    self.callback(True)
                return True, rg_cod
            else:
                print(f"CodeManager: Impossibile aggiornare feature FID {fid}")
                if self.callback:
                    self.callback(False)
                return False, ''
        except Exception as e:
            print(f"CodeManager Error in run_on_feature_by_fid: {e}")
            if self.callback:
                self.callback(False)
            return False, ''