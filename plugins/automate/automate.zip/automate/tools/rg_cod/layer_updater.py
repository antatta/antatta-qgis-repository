# -*- coding: utf-8 -*-
"""
/***************************************************************************
 LayerUpdater
                                 A QGIS plugin
 The AUTOMATE plug-in
                             -------------------
        begin                : 2024-09-23
        copyright            : (C) 2024 by Ing. Antonio Attadia
        email                : info.antatta@gmail.com
        git sha              : $Format:%H$
 ***************************************************************************/
 Class for layer attribute updating
"""

from qgis.utils import iface
from qgis.core import Qgis, QgsVectorLayer, QgsField
from qgis.PyQt.QtCore import QVariant, QTimer
from .code_calculator import CodeCalculator


class LayerUpdater:
    """Gestisce la modifica del layer per aggiornare gli attributi"""
    def __init__(self, calculator: CodeCalculator):
        # limite elementi lotto
        self.cifre_max_elementi_lotto = 4
        self.cifre_max_nome_lotto = 4
        
        self.calculator = calculator
        self.UNIVOCO_FEATURE = "RG_COD"
        self.UNIVOCO_LOTTO = "ID_SUBLOTTO"
        self.is_processing = False

    def update_feature(self, who: str, layer: QgsVectorLayer, fid: int, commit: bool = False) -> bool:
        print(f"{who} -> {layer.name()=} {fid=}")
        if fid < 0 or self.is_processing:
            return False
        
        try:
            self.is_processing = True
            UNIVOCO_FEATURE_index = layer.fields().indexFromName(self.UNIVOCO_FEATURE)
            UNIVOCO_LOTTO_index = layer.fields().indexFromName(self.UNIVOCO_LOTTO)
            
            feature = layer.getFeature(fid)
            RG_COD = self.calculator.calculate_rg_cod(layer, feature)
            lotto = self.calculator.lotto
            
            layer.blockSignals(True)
            if not layer.isEditable():
                layer.startEditing()
            
            layer.changeAttributeValue(fid, UNIVOCO_FEATURE_index, RG_COD)
            if fid < 10**self.cifre_max_elementi_lotto:
                layer.changeAttributeValue(fid, UNIVOCO_LOTTO_index, lotto)
            else:
                lotto = str(int(fid/10**self.cifre_max_elementi_lotto))
                layer.changeAttributeValue(fid, UNIVOCO_LOTTO_index, lotto)
            
            lotto = feature[self.UNIVOCO_LOTTO]
            msg = f"{who} -> ID: {fid} - {self.UNIVOCO_LOTTO}: {lotto} - {self.UNIVOCO_FEATURE}: {RG_COD}"
            print(msg)
            
            if commit:
                QTimer.singleShot(0, lambda: self.commit_changes(layer))
            return True
        except Exception as e:
            layer.rollBack()
            msg = f"Errore durante la modifica della feature. {e}"
            print(msg)
            iface.messageBar().pushMessage(u'update_feature', msg, level=Qgis.Critical)
            return False
        finally:
            self.is_processing = False
            layer.blockSignals(False)

    def commit_changes(self, layer: QgsVectorLayer) -> bool:
        if layer.commitChanges(stopEditing=True):
            msg = f"Campi automatici layer '{layer.name()}' aggiornati"
            print(msg)
            iface.messageBar().pushMessage(u'commit_changes', msg, level=Qgis.Success)
            return True
        else:
            msg = f"Campi automatici layer '{layer.name()}' non aggiornati"
            print(msg)
            iface.messageBar().pushMessage(u'commit_changes', msg, level=Qgis.Critical)
            return False

    def ensure_fields(self, layer: QgsVectorLayer) -> bool:
        layer_name = self.calculator.get_layer_source_name(layer)
        expected_fields = self.calculator.connect_db.get_layer_fields_type('', layer_name)
        
        tipo_map = {
            'Integer': QVariant.Int,
            'String': QVariant.String,
            'Real': QVariant.Double,
            'bool': QVariant.Bool,
            'date': QVariant.Date,
            'datetime': QVariant.DateTime
        }
        
        for field, type_name in expected_fields:
            if layer.fields().indexFromName(field) == -1:
                if not layer.isEditable():
                    layer.startEditing()
                
                field_type = tipo_map.get(type_name, QVariant.String)
                new_field = QgsField(field, field_type)
                
                if not layer.addAttribute(new_field):
                    msg = f"Errore durante l'aggiunta del campo '{field}' al layer '{layer.name()}'."
                    print(msg)
                    iface.messageBar().pushMessage(u'ensure_fields', msg, level=Qgis.Critical)
                    return False
        
        return layer.commitChanges() if layer.isEditable() else True
