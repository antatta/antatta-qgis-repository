# 🚀 AUTOMATE Plugin v2.0
*Toolbar per interazione progettazione SDI in GIS*

[![QGIS Plugin](https://img.shields.io/badge/QGIS-Plugin-green.svg)](https://qgis.org/)
[![Python](https://img.shields.io/badge/Python-3.9+-blue.svg)](https://python.org)
[![PyQt](https://img.shields.io/badge/PyQt-5.0+-orange.svg)](https://www.riverbankcomputing.com/software/pyqt/)

Il plugin **AUTOMATE** per QGIS è uno strumento specializzato per la progettazione GIS secondo le specifiche fornite dalla Committente.

## ✨ Funzionalità Principali

### 🔢 **Gestione RG_COD**
- **Generazione Manuale**: Calcola e assegna RG_COD a tutti gli elementi del layer selezionato
- **Automazione**: Switch on/off per abilitare/disabilitare la generazione automatica di RG_COD per nuovi elementi

### 📸 **PhotoEditor** *(ex plugin PhotoEditor v2.0)*
- Creazione di documentazione fotografica collegata al progetto "Lotto" in corso
- Integrazione con Google Street View API per acquisizione automatica immagini
- Editor avanzato per annotazioni e modifiche foto

### 📎 **Gestione Allegati** *(ex plugin Uploader v2.0)*
- Apertura rapida dei file allegati associati agli elementi selezionati
- Salvataggio e gestione degli attachment
- Eliminazione selettiva di allegati o oggetti completi

### 🔍 **Controllo Layer**
- Dialog di verifica e validazione dei layer di progetto
- Controlli di qualità secondo criteri specifici (pre-consegna)
- Validazione automatica della struttura dati

### 📦 **Zip Progetto**
- Creazione automatica dello zip per la consegna
- Salvataggio in `./Desktop/project/` secondo specifiche richieste
- Verifica integrità e completezza del pacchetto

## 🏗️ Architettura Modulare v2.0

Il plugin è stato completamente ristrutturato con un'architettura modulare pulita:

### 🔧 **Moduli Core**
- **core/**: Funzionalità base, costanti e utilità condivise
- **database/**: Gestione connessioni e configurazioni database
- **ui/**: Interfacce utente e dialog

### 🛠️ **Strumenti Funzionali**
- **tools/rg_cod/**: Sistema di generazione codici RG con controllo automazione
- **tools/photo/**: Gestione foto con integrazione Google Street View e editor avanzato
- **tools/attachments/**: Sistema di gestione allegati e cestino
- **tools/controller/**: Controlli di qualità con validatori specifici e reporting errori
- **tools/settings/**: Dialog di configurazione e preferenze
- **tools/zip/**: Compressione progetti con monitoraggio progresso

### 📦 **Risorse e Supporto**
- **resources/**: Database template e risorse grafiche
- **Dipendenze runtime**: Gestione automatica pacchetti (SQLAlchemy, ecc.)

### 🌳 Struttura ad albero
```
📁 automate/ (Package finale)
├── 🔌 automate.py              # Classe principale plugin
├── 📋 __init__.py              # Entry point QGIS
├── 📄 metadata.txt             # Metadati plugin
├── ⚙️ settings.ini             # Configurazione
├── 🖼️ icon.png                # Icona plugin
├── 📚 README_USER.md          # Documentazione utenti
├── 📄 requirements.txt        # Dipendenze Python
├── 🔧 controller_cli.py       # Controller CLI
├── 📦 resources.py            # Risorse Qt compilate
├── 📂 core/                   # Funzionalità base
│   ├── __init__.py 
│   ├── constant.py           # Costanti condivise
│   ├── constant.yaml         # Configurazioni costanti
│   ├── package_manager.py    # Gestione pacchetti
│   └── utils.py              # Utilità condivise
├── 📂 database/               # Gestione database
│   ├── __init__.py
│   ├── config.py             # Configurazione DB
│   └── database_connect.py   # Connessioni DB
├── 📂 tools/                  # Strumenti funzionali
│   ├── __init__.py
│   ├── 🔢 rg_cod/            # Generazione codici RG
│   │   ├── __init__.py      
│   │   ├── code_calculator.py
│   │   ├── layer_updater.py
│   │   ├── signal_manager.py
│   │   ├── code_manager.py
│   │   └── switch.py
│   ├── 📸 photo/             # Gestione foto
│   │   ├── __init__.py
│   │   ├── PhotoEditorWindow.ui
│   │   ├── resources.py
│   │   ├── photo_manager.py
│   │   ├── photo_downloader.py
│   │   ├── photo_editor_window.py
│   │   ├── point_tool.py
│   ├── 📎 attachments/       # Gestione allegati
│   │   ├── __init__.py
│   │   ├── attach_manager.py
│   │   └── trash_manager.py
│   ├── 🔍 controller/        # Controlli qualità
│   │   ├── __init__.py
│   │   ├── ControllerDialog.ui
│   │   ├── controller.py
│   │   ├── controller_dialog.py
│   │   ├── controller_cli.py  # CLI controller
│   │   ├── error_reporter.py
│   │   ├── error_types.py
│   │   └── validators/        # Validatori specifici
│   ├── ⚙️ settings/          # Configurazioni
│   │   ├── __init__.py
│   │   ├── settings.ui       # UI dialog settings
│   │   └── settings_dialog.py
│   └── 📦 zip/              # Compressione progetti
│       ├── __init__.py
│       ├── ProgressBarDialog.ui
│       ├── zip_manager.py
│       ├── zip_project_thread.py
│       └── progress_bar_dialog.py
└── 📂 resources/             # Risorse statiche
    ├── __init__.py
    ├── db/                  # Database
    └── icon/                # Icone e risorse grafiche
```
## 🎯 **Caratteristiche v2.0**

### ✨ **Miglioramenti Architetturali**
- Organizzazione modulare per miglior manutenibilità
- Separazione chiara delle responsabilità
- Struttura scalabile per sviluppi futuri
- Importazioni pulite con dipendenze chiare

### 📈 **Prestazioni e Affidabilità**
- Gestione errori migliorata
- Feedback utente ottimizzato
- Performance migliorate attraverso codice ottimizzato
- UI/UX migliorata con organizzazione componenti

### 🔄 **Compatibilità**
- Aggiornamento senza modifiche configurazione
- Piena compatibilità con progetti e impostazioni esistenti
- Caricamento plugin migliorato
- Migliore integrazione con ambiente QGIS

---
Il plugin si integra perfettamente nell'interfaccia QGIS, aggiungendo una toolbar dedicata per l'accesso rapido a tutte le funzionalità.
