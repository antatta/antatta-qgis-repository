# -*- coding: utf-8 -*-
import re
from datetime import datetime
from pathlib import Path

def last_file(dir_path: Path, prefix: str, suffix: str):
    """Individua in dir_path il file che inizia per prefix con estensione suffix più recente o solo prefix.suffix.
    
    Formati validi dei file:
    - prefix_aaaa.mm.gg.suffix
    - prefix_aaaammgg.suffix
    - prefix_aaaa_mm_gg.suffix
    - prefix.suffix
    
    Args:
        dir_path (Path): path contenente i file
        prefix (str): prefisso nome file
        suffix (str): estensione del file

    Returns:
        Path: path del file individuato
    """
    # Pattern regex per estrarre la data dal nome del file (considera . - e _ come separatori)
    if prefix == '0000':
        prefix = '0000_UNITO'
    date_pattern = re.compile(rf'{prefix}[\.\-_]?(\d{{4}})?[\.\-_]?(\d{{2}})?[\.\-_]?(\d{{2}})?\.' + re.escape(suffix))

    # Inizializzare la variabile per il file con la data più recente
    latest_file: Path = None
    latest_date = None

    for file in dir_path.glob(f'{prefix}*{suffix}'):
        # Estrae la data dal nome del file
        match = date_pattern.search(file.name)
        if match:
            if match.group() != file.name:
                # Unisce i gruppi estratti in formato aaaa mm gg
                numbers = ''.join(match.groups())
                file_date = datetime.strptime(numbers, '%Y%m%d')
                # Confronta con la data più recente trovata finora
                if latest_date is None or file_date > latest_date:
                    latest_date = file_date
                    latest_file = file
        if not latest_file:
            latest_file = file

    # Stampa o restituisce il nome del file con la data più recente
    if latest_file:
        msg = f"last_file -> File più recente trovato: {latest_file.name}"
    else:
        msg = f"last_file -> Nessun file trovato"    
    print(msg)
    return latest_file


def main():
    dir_path = Path("/Users/IG56001/Desktop/Sviluppo Software/automate_versioni/Pavimentazione/1002/")
    prefix = "1002"
    suffix = "gpkg"
    print(last_file(dir_path, prefix, suffix))
    


if __name__ == "__main__":
    main()