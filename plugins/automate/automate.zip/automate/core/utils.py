# -*- coding: utf-8 -*-
import re
import configparser
from datetime import datetime
from pathlib import Path
from typing import Optional
from qgis.core import QgsProject, QgsVectorLayer
from qgis.utils import iface

# Import del contesto dal modulo dedicato
from .context import AutomateContext

def last_file(dir_path: Path, prefix: str, suffix: str):
    """Individua in dir_path il file che inizia per prefix con estensione suffix più recente o solo prefix.suffix.
    
    Formati validi dei file:
    - prefix_aaaa.mm.gg.suffix
    - prefix_aaaammgg.suffix
    - prefix_aaaa_mm_gg.suffix
    - prefix.suffix
    
    Args:
        dir_path (Path): path contenente i file
        prefix (str): prefisso nome file
        suffix (str): estensione del file

    Returns:
        Path: path del file individuato
    """
    # Pattern regex per estrarre la data dal nome del file (considera . - e _ come separatori)
    if prefix == '0000':
        prefix = '0000_UNITO'
    date_pattern = re.compile(rf'{prefix}[\.\-_]?(\d{{4}})?[\.\-_]?(\d{{2}})?[\.\-_]?(\d{{2}})?\.' + re.escape(suffix))

    # Inizializzare la variabile per il file con la data più recente
    latest_file: Optional[Path] = None
    latest_date = None

    for file in dir_path.glob(f'{prefix}*{suffix}'):
        # Estrae la data dal nome del file
        match = date_pattern.search(file.name)
        if match:
            if match.group() != file.name:
                # Unisce i gruppi estratti in formato aaaa mm gg
                numbers = ''.join(match.groups())
                file_date = datetime.strptime(numbers, '%Y%m%d')
                # Confronta con la data più recente trovata finora
                if latest_date is None or file_date > latest_date:
                    latest_date = file_date
                    latest_file = file
        if not latest_file:
            latest_file = file

    # Stampa o restituisce il nome del file con la data più recente
    if latest_file:
        msg = f"DEBUG: last_file -> File più recente trovato: {latest_file.name}"
    else:
        msg = f"DEBUG: last_file -> Nessun file trovato"
    print(msg)
    return latest_file


def create_automate_context(project=None, force_db=True) -> Optional[AutomateContext]:
    """
    Crea un AutomateContext dal progetto QGIS corrente utilizzando la nuova struttura.
    Questo è l'unico modo raccomandato per creare il contesto.
    
    Args:
        project: Progetto QGIS (opzionale, usa quello corrente se None)
        force_db: Se True, crea sempre la connessione DB (default: True)
        
    Returns:
        AutomateContext se il progetto è valido e tutti i controlli passano, None altrimenti
        
    Example:
        # Uso base - crea contesto con validazioni complete
        context = create_automate_context()
        if context:
            print(f"Working on lotto: {context.lotto_name}")
            print(f"Project: {context.project_file_path}")
            print(f"GPKG: {context.lotto_gpkg_path}")
    """
    if project is None:
        project = QgsProject.instance()
        
    try:
        if not project.fileName():
            raise ValueError("❌ Nessun progetto attivo trovato. Salva il progetto prima di procedere.")

        # Estrae informazioni base dal progetto QGIS
        project_base_name = project.baseName()
        project_file_path = Path(project.fileName())
        project_home_path = Path(project.homePath())
        
        # Estrae il nome del lotto dal nome del progetto usando le costanti
        from .constant import CONST
        if not CONST:
            raise ValueError("❌ Costanti non caricate. Assicurati che il plugin sia inizializzato correttamente.")
            
        # Estrae il nome del lotto secondo le regole delle costanti
        cifre_max = CONST.cifre_max_nome_lotto  # Valore 4 dal YAML
        lotto_name = project_base_name[:cifre_max]
        
        if not lotto_name:
            raise ValueError("❌ Impossibile estrarre nome lotto dal progetto")
        
        # Verifica se lotto_name è un numero valido
        if not lotto_name.isdigit():
            raise ValueError(f"❌ Il nome lotto '{lotto_name}' non è un numero valido")
        
        # Costruisce i paths secondo la nuova struttura
        lotto_dir_path = project_home_path / lotto_name
        lotto_gpkg_path = last_file(lotto_dir_path, lotto_name, 'gpkg')
        if not lotto_gpkg_path or not lotto_gpkg_path.exists():
            raise FileNotFoundError(f"❌ File GPKG non trovato per il lotto '{lotto_name}' in {lotto_dir_path}")
        
        
        # Imposta il path del file delle impostazioni
        settings_file = Path( __file__ ).parent.parent / 'settings.ini'
        apikey = load_settings(settings_file)
        if not apikey:
            raise ValueError("APIKEY non impostata")

        # Connessione database (opzionale ma di default attiva)
        db = None
        if force_db:
            try:
                from ..database.database_connect import DatabaseConnect
                db = DatabaseConnect()
                print(f"DEBUG create_automate_context: ✅ Database connesso per lotto {lotto_name}")
            except Exception as db_error:
                raise ConnectionError(f"⚠️ Errore connessione database: {db_error}")
        
        # Crea il contesto - le validazioni sono gestite da __post_init__
        context = AutomateContext(
            project_file_path=project_file_path,
            project_home_path=project_home_path,
            lotto_name=lotto_name,
            lotto_dir_path=lotto_dir_path,
            lotto_gpkg_path=lotto_gpkg_path,
            db=db,
            settings_file=settings_file,
            apikey=apikey,
            const=CONST  # Passa le costanti caricate
        )
        
        print(f"DEBUG create_automate_context: ✅ Contesto creato e validato per lotto: {lotto_name}")
        print(f"DEBUG create_automate_context:    📁 Project home: {project_home_path}")
        print(f"DEBUG create_automate_context:    📂 Lotto directory: {lotto_dir_path}")
        print(f"DEBUG create_automate_context:    🗄️ GPKG: {lotto_gpkg_path} ({'✅' if context.gpkg_exists else '❌'})")
        print(f"DEBUG create_automate_context:    🔗 Database: {'✅' if db else '❌'}")
        
        return context
        
    except Exception as e:
        print(f"DEBUG create_automate_context: ❌ Errore creazione contesto automate: {e}")
        import traceback
        print(f"DEBUG create_automate_context:    Traceback: {traceback.format_exc()}")
        return None

def load_settings(settings_file: Path) -> Optional[str]:
    # Carica le impostazioni dal file settings.ini
    config = configparser.ConfigParser()
    config.read(settings_file)
    if config is None:
        raise ValueError("Impossibile leggere il file di configurazione")

    # Carica  la sezione 'Settings'
    if config.has_option('Settings', 'APIKEY'):
        return config.get('Settings', 'APIKEY')

def ensure_project_context() -> Optional[AutomateContext]:
    """
    Versione semplificata che assicura sempre un contesto valido o fallisce.
    Usa create_automate_context con impostazioni predefinite sicure.
    
    Returns:
        AutomateContext valido o None se impossibile crearlo
        
    Example:
        context = ensure_project_context()
        if not context:
            return  # Exit early se no context
        
        # Procedi con logica che usa il contesto
        print(f"Processing {context.lotto}")
    """
    return create_automate_context(force_db=True)

# Metodo principale per ricaricare un layer QGIS in modo sicuro
def refresh_qgis_layer_safely(layer: QgsVectorLayer) -> bool:
    """
    Ricarica un layer QGIS dopo modifiche OGR per evitare crash e inconsistenze.
    
    Quando si modificano i campi di un layer tramite OGR direttamente sul file,
    QGIS non rileva automaticamente i cambiamenti. Questo metodo forza il
    ricaricamento del layer in modo sicuro.
    
    Args:
        layer (QgsVectorLayer): Il layer QGIS da ricaricare
        
    Returns:
        True se il ricaricamento è riuscito, False altrimenti
    """
    try:

        layer_display_name = layer.name()
        print(f"🔄 Ricaricando layer QGIS '{layer_display_name}'...")
        
        # Metodo 1: Ricarica il data provider
        if hasattr(layer, 'dataProvider') and layer.dataProvider():
            layer.dataProvider().reloadData()
            print(f"   ✅ Data provider ricaricato per '{layer_display_name}'")
        
        # Metodo 2: Ricarica la struttura dei campi
        if hasattr(layer, 'updateFields'):
            layer.updateFields()
            print(f"   ✅ Struttura campi aggiornata per '{layer_display_name}'")
        
        # Metodo 3: Invalida cache e forza refresh
        if hasattr(layer, 'triggerRepaint'):
            layer.triggerRepaint()
            print(f"   ✅ Repaint triggerato per '{layer_display_name}'")
        
        # Metodo 4: Notifica cambiamenti al progetto
        if hasattr(layer, 'layerModified'):
            layer.layerModified.emit()
            print(f"   ✅ Segnale layerModified emesso per '{layer_display_name}'")
        
        # Aggiorna anche la vista della tabella attributi se aperta
        if iface.activeLayer() == layer:
            iface.mapCanvas().refresh()
            print(f"   ✅ Canvas aggiornato per layer attivo '{layer_display_name}'")
        
        print(f"✅ Layer '{layer_display_name}' ricaricato con successo")
        
        return True
    
    except Exception as e:
        print(f"❌ Errore critico in refresh_qgis_layer_safely: {e}")
        return False
