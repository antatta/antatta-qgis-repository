# -*- coding: utf-8 -*-
"""
Core module for AUTOMATE plugin v2.0
Contains core functionality, configuration, and utilities.
"""

from .constant import CONST

# Context management system (nuovo in v2.4+)
from .context import AutomateContext, ContextError, validate_context
from .utils import (
    create_automate_context,
    ensure_project_context,
    last_file,
    refresh_qgis_layer_safely
)

__all__ = [
    # Constants (legacy)
    'CONST',
    
    # Context management (v2.4+)
    'AutomateContext',
    'ContextError', 
    'validate_context',
    
    # Utility functions
    'create_automate_context',
    'ensure_project_context',
    'last_file',
    'refresh_qgis_layer_safely'
]