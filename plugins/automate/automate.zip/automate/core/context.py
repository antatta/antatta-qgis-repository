# -*- coding: utf-8 -*-
"""
AutomateContext - Contesto condiviso per il plugin AUTOMATE.

Questo modulo definisce la struttura dati che viene passata a tutte le classi
chiamate dai pulsanti del plugin automate, fornendo informazioni consistenti
su lotto, database e percorsi.
"""
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Dict, Any, TYPE_CHECKING, Union

from .constant import CONST, LazyConfigLoader

# Import condizionale per evitare circular imports
if TYPE_CHECKING:
    from ..database.database_connect import DatabaseConnect


@dataclass
class AutomateContext:
    """
    Contesto condiviso per tutte le classi chiamate dai pulsanti di automate.
    Fornisce informazioni sul lotto corrente e connessioni al database.
    
    Attributes:
        project_file_path (Path): Path al file di progetto QGIS (.qgz o .qgs)
        project_home_path (Path): Path alla directory del progetto del lotto
        lotto_name (str): Nome del lotto corrente (estratto dal nome del file di progetto)
        lotto_dir_path (Path): Path alla directory dei file del lotto
        lotto_gpkg_path (Path): Path completo al file GPKG del lotto
        db (Optional[DatabaseConnect]): Connessione al database master già inizializzata
        cost (Optional[Dict]): Dizionario delle costanti di configurazione (CONST)
    
    Example:
        context = create_automate_context()
        if context:
            print(f"Processing lotto: {context.lotto_name}")
            # Use context.db for database operations
            # Use context.lotto_gpkg_path for GPKG operations
    """
    project_file_path: Path
    project_home_path: Path
    
    lotto_name: str
    lotto_dir_path: Path
    lotto_gpkg_path: Path
    
    db: Optional['DatabaseConnect']
    settings_file: Path
    apikey: Optional[str] = None
    const: Optional[Union[Dict[str, Any], LazyConfigLoader]] = None
    
    def __post_init__(self):
        """Validazione post-inizializzazione del contesto"""
        
        # Imposta le costanti se non già fornite
        if not self.const:
            self.const = CONST
            
        if not self.const:
            raise ValueError("Le costanti di configurazione non sono state caricate correttamente")
        
        # Validazione campi obbligatori
        if not self.lotto_name:
            raise ValueError("Il nome del lotto non può essere vuoto")
        
        # Validazione che il lotto sia numerico (se richiesto dalle costanti)
        # Supporta sia LazyConfigLoader che dict
        if isinstance(self.const, LazyConfigLoader):
            max_cifre = self.const.cifre_max_nome_lotto
        elif 'cifre_max_nome_lotto' in self.const:
            max_cifre = self.const['cifre_max_nome_lotto']
        else:
            max_cifre = None
        
        if max_cifre:
            if len(self.lotto_name) < max_cifre:
                raise ValueError(f"Il nome del lotto '{self.lotto_name}' deve avere almeno {max_cifre} caratteri")

            try:
                int(self.lotto_name)  # Verifica che sia numerico
            except ValueError:
                raise ValueError(f"Il nome del lotto deve essere numerico: {self.lotto_name}")
        
        # Validazione esistenza paths
        if not self.project_home_path.exists():
            raise ValueError(f"La directory del progetto non esiste: {self.project_home_path}")
            
        if not self.lotto_dir_path.exists():
            raise ValueError(f"La directory del lotto non esiste: {self.lotto_dir_path}")
        
        if not self.lotto_gpkg_path.exists():
            raise ValueError(f"Il file GPKG del lotto non esiste: {self.lotto_gpkg_path}")
        
    
    @property
    def gpkg_exists(self) -> bool:
        """True se il file GPKG del lotto esiste"""
        return self.lotto_gpkg_path.exists()
    
    # def get_constant(self, key: str):
    #     """
    #     Accesso sicuro e unificato alle costanti che supporta sia LazyConfigLoader che Dict.
    #     Questo è il metodo raccomandato per accedere alle costanti da tutto il codebase.
        
    #     Args:
    #         key: Nome della costante da recuperare
            
    #     Returns:
    #         Il valore della costante
            
    #     Raises:
    #         ValueError: Se le costanti non sono disponibili
    #         KeyError/AttributeError: Se la chiave non esiste
            
    #     Example:
    #         # Invece di context.cost.TRIPLETTA o context.cost['TRIPLETTA']
    #         tripletta_field = context.get_constant('TRIPLETTA')
    #         max_cifre = context.get_constant('cifre_max_nome_lotto')
    #     """
    #     if not self.cost:
    #         raise ValueError("Le costanti non sono disponibili nel context")
        
    #     if isinstance(self.cost, LazyConfigLoader):
    #         return getattr(self.cost, key)  # Dot notation per LazyConfigLoader
    #     else:
    #         return self.cost[key]           # Dict notation per dizionari normali

    @property
    def c(self):
        """
        Proxy intelligente per accesso sicuro alle costanti con dot notation.
        Combina la sicurezza del controllo con la sintassi pulita della dot notation.
        
        Returns:
            Un wrapper che supporta la dot notation con controlli di sicurezza
            
        Raises:
            ValueError: Se le costanti non sono disponibili nel context
            
        Example:
            # Dot notation sicura e pulita!
            tripletta_field = context.c.TRIPLETTA
            max_cifre = context.c.cifre_max_nome_lotto
            pavimentazione = context.c.value_pavimentazione_bitumata
            
            # Equivale a context.get_constant() ma con sintassi più pulita
        """
        if not self.const:
            raise ValueError("Le costanti non sono disponibili nel context")
        
        # Se è già un LazyConfigLoader, restituisciamo direttamente (ha già la dot notation)
        if isinstance(self.const, LazyConfigLoader):
            return self.const
        else:
            # Se è un dict, creiamo un wrapper che supporta la dot notation
            return _DictDotNotationWrapper(self.const)
    
    def get_lotto_file(self, filename: str) -> Path:
        """
        Costruisce il path per un file nella directory del lotto.
        
        Args:
            filename: Nome del file (con o senza estensione)
            
        Returns:
            Path completo del file nella directory del lotto
            
        Example:
            pdf_path = context.get_lotto_file("report.pdf")
            settings_path = context.get_lotto_file("config.ini")
        """
        return self.lotto_dir_path / filename
    
    def ensure_lotto_subdir(self, subdir_name: str) -> Path:
        """
        Crea e ritorna il path per una sottodirectory del lotto.
        
        Args:
            subdir_name: Nome della sottodirectory da creare
            
        Returns:
            Path della sottodirectory (creata se non esisteva)
            
        Example:
            photos_dir = context.ensure_lotto_subdir("photos")
            attachments_dir = context.ensure_lotto_subdir("attachments")
        """
        subdir_path = self.lotto_dir_path / subdir_name
        subdir_path.mkdir(parents=True, exist_ok=True)
        return subdir_path
    
    def ensure_project_subdir(self, subdir_name: str) -> Path:
        """
        Crea e ritorna il path per una sottodirectory nella home del progetto.
        
        Args:
            subdir_name: Nome della sottodirectory da creare
        Returns:
            Path della sottodirectory (creata se non esisteva)
        """
        subdir_path = self.project_home_path / subdir_name
        subdir_path.mkdir(parents=True, exist_ok=True)
        return subdir_path
        
    def __repr__(self) -> str:
        """Rappresentazione string per debugging"""
        return (f"AutomateContext(lotto='{self.lotto_name}', "
                f"dir={self.lotto_dir_path}, "
                f"gpkg_exists={self.gpkg_exists}), "
                f"db_connected={'Yes' if self.db else 'No'}")

class ContextError(Exception):
    """Eccezione specifica per errori nel contesto automate"""
    pass

class _DictDotNotationWrapper:
    """
    Wrapper che aggiunge la dot notation a un dizionario normale.
    Usato internamente da AutomateContext per fornire accesso uniforme alle costanti.
    """
    def __init__(self, data: Dict[str, Any]):
        self._data = data
    
    def __getattr__(self, name: str) -> Any:
        if name in self._data:
            return self._data[name]
        raise AttributeError(f"Costante '{name}' non trovata")
    
    def __getitem__(self, key: str) -> Any:
        return self._data[key]
    
    def __contains__(self, key: str) -> bool:
        return key in self._data


def validate_context(context: AutomateContext) -> bool:
    """
    Valida che il contesto sia corretto e utilizzabile.
    
    Args:
        context: Il contesto da validare
        
    Returns:
        True se il contesto è valido
        
    Raises:
        ContextError: Se il contesto non è valido
    """
    if not isinstance(context, AutomateContext):
        raise ContextError("Il contesto deve essere un'istanza di AutomateContext")
    
    if not context.const:
        raise ContextError("Le costanti di configurazione non sono state caricate correttamente")
    
    if not context.lotto_dir_path.exists():
        raise ContextError(f"La directory del lotto non esiste: {context.lotto_dir_path}")
    
    if not context.lotto_gpkg_path.exists():
        raise ContextError(f"Il file GPKG del lotto non esiste: {context.lotto_gpkg_path}")
    
    if context.db is None:
        raise ContextError("La connessione al database non è inizializzata")
    
    return True